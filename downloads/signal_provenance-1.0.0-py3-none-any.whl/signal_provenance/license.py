"""License validation for Signal Provenance.

Ed25519-signed license files. Public key ships with the CLI.
Private key stays in ops (never distributed). No network call. Ever.

License file format:
    -----BEGIN SIGNAL PROVENANCE LICENSE-----
    <base64url(json_payload + 64-byte Ed25519 signature)>
    -----END SIGNAL PROVENANCE LICENSE-----

Requires: cryptography (one external dep)
"""

import base64
import json
import logging
import sys
from datetime import date, datetime
from pathlib import Path

log = logging.getLogger("signal_provenance.license")

# Where the license file lives after activation
LICENSE_DIR = Path.home() / ".config" / "signal-provenance"
LICENSE_FILE = LICENSE_DIR / "license.lic"

# Ed25519 public key (base64-encoded). Generated once, ships with CLI.
PUBLIC_KEY_B64 = "stabVge7MrNUaKTX68MGsmsL0GIIEfwOfsedqCI0LEw="

# Signature is 64 bytes for Ed25519
ED25519_SIG_LENGTH = 64

HEADER = "-----BEGIN SIGNAL PROVENANCE LICENSE-----"
FOOTER = "-----END SIGNAL PROVENANCE LICENSE-----"


class LicenseError(Exception):
    """License validation failure."""


class License:
    """Validated license payload."""

    __slots__ = ("version", "cid", "email", "product", "tier",
                 "issued", "expires", "raw")

    def __init__(self, payload: dict):
        self.version = payload.get("v", 1)
        self.cid = payload["cid"]
        self.email = payload["email"]
        self.product = payload["product"]
        self.tier = payload["tier"]
        self.issued = payload["issued"]
        self.expires = payload["expires"]
        self.raw = payload

    @property
    def is_expired(self) -> bool:
        try:
            exp = date.fromisoformat(self.expires)
            return date.today() > exp
        except (ValueError, TypeError):
            return True

    def __repr__(self) -> str:
        return (f"License(cid={self.cid!r}, email={self.email!r}, "
                f"tier={self.tier!r}, expires={self.expires!r})")


def _load_public_key():
    """Load the Ed25519 public key from the embedded constant."""
    if not PUBLIC_KEY_B64:
        raise LicenseError(
            "No public key configured. This build is not license-ready."
        )
    from cryptography.hazmat.primitives.asymmetric.ed25519 import (
        Ed25519PublicKey,
    )
    key_bytes = base64.b64decode(PUBLIC_KEY_B64)
    return Ed25519PublicKey.from_public_bytes(key_bytes)


def parse_license_file(content: str) -> tuple[bytes, bytes]:
    """Parse a .lic file into (json_bytes, signature_bytes)."""
    lines = content.strip().splitlines()
    if not lines or lines[0].strip() != HEADER:
        raise LicenseError("Invalid license file: missing header")
    if lines[-1].strip() != FOOTER:
        raise LicenseError("Invalid license file: missing footer")

    b64_data = "".join(line.strip() for line in lines[1:-1])
    try:
        raw = base64.urlsafe_b64decode(b64_data)
    except Exception:
        raise LicenseError("Invalid license file: bad encoding")

    if len(raw) <= ED25519_SIG_LENGTH:
        raise LicenseError("Invalid license file: too short")

    json_bytes = raw[:-ED25519_SIG_LENGTH]
    sig_bytes = raw[-ED25519_SIG_LENGTH:]
    return json_bytes, sig_bytes


def validate_license(content: str) -> License:
    """Validate a license file string. Returns License on success.

    Raises LicenseError on any validation failure.
    """
    json_bytes, sig_bytes = parse_license_file(content)

    # Verify signature
    from cryptography.exceptions import InvalidSignature

    public_key = _load_public_key()
    try:
        public_key.verify(sig_bytes, json_bytes)
    except InvalidSignature:
        raise LicenseError("Invalid license: signature verification failed")

    # Parse payload
    try:
        payload = json.loads(json_bytes.decode("utf-8"))
    except (json.JSONDecodeError, UnicodeDecodeError):
        raise LicenseError("Invalid license: corrupt payload")

    # Required fields
    for field in ("cid", "email", "product", "tier", "issued", "expires"):
        if field not in payload:
            raise LicenseError(f"Invalid license: missing field '{field}'")

    if payload["product"] != "signal-provenance":
        raise LicenseError("Invalid license: wrong product")

    return License(payload)


def activate(license_path: str | Path) -> License:
    """Activate a license by copying it to the config directory.

    Returns the validated License.
    """
    source = Path(license_path)
    if not source.exists():
        raise LicenseError(f"License file not found: {source}")

    content = source.read_text(encoding="utf-8")
    lic = validate_license(content)

    if lic.is_expired:
        raise LicenseError(
            f"License expired on {lic.expires}. Contact kyle@echology.io."
        )

    LICENSE_DIR.mkdir(parents=True, exist_ok=True)
    LICENSE_FILE.write_text(content, encoding="utf-8")
    return lic


def check_license() -> License | None:
    """Check for a valid, non-expired license. Returns License or None.

    Does not raise -- returns None for any failure (free tier behavior).
    """
    if not LICENSE_FILE.exists():
        return None
    try:
        content = LICENSE_FILE.read_text(encoding="utf-8")
        lic = validate_license(content)
        if lic.is_expired:
            return None
        return lic
    except (LicenseError, Exception):
        return None


def require_license(tier: str | None = None) -> License:
    """Require a valid license. Exits with message if not found.

    Args:
        tier: If specified, require this specific tier (e.g. "pro").
    """
    lic = check_license()
    if lic is None:
        print("This feature requires a Signal Provenance license.")
        print(f"  License file: {LICENSE_FILE}")
        print("  Purchase: https://echology.io/provenance")
        print("\nActivate: signal-provenance activate <license.lic>")
        sys.exit(1)
    if tier and lic.tier != tier:
        print(f"This feature requires the '{tier}' tier.")
        print(f"  Current tier: {lic.tier}")
        print("  Upgrade: https://echology.io/provenance")
        sys.exit(1)
    return lic
