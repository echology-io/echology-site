"""Compliance export -- PDF + JSON audit artifacts.

JSON: always available (stdlib).
PDF: requires weasyprint (optional dependency).

Covers: FDA 21 CFR Part 11, SOX 404, CMMC/NIST 800-171,
        ISO 27001/SOC 2, EU AI Act, HIPAA/HITECH.
"""

import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

from signal_provenance import __version__
from signal_provenance.db import (
    ALETHEIA_GENESIS_HASH,
    get_ledger_path,
    verify_chain,
)


# -- Compliance mapping ----------------------------------------------------

COMPLIANCE_MAPPING = {
    "fda_21cfr11": {
        "sections": ["11.10(e)", "11.10(b)"],
        "description": "Audit trails for electronic records",
    },
    "sox_404": {
        "sections": ["Record integrity", "7-year retention"],
        "description": "Internal controls over financial reporting",
    },
    "cmmc_nist171": {
        "sections": ["AU-2", "AU-3", "AU-6", "AU-9", "AU-12"],
        "description": "Audit and accountability controls",
    },
    "iso27001_soc2": {
        "sections": ["A.8.15", "A.5.33"],
        "description": "Logging and monitoring controls",
    },
    "hipaa": {
        "sections": ["164.312(b)", "164.312(c)"],
        "description": "Audit controls and integrity controls",
    },
    "eu_ai_act": {
        "sections": ["Art. 12 Record-keeping", "Annex IV Sec. 2 Data provenance",
                      "Art. 11 Technical documentation", "Art. 17(1)(f) QMS data management",
                      "Art. 9 Risk management"],
        "description": "AI system logging, training data provenance, and documentation integrity",
    },
}


# -- Data collection -------------------------------------------------------

def _collect_report_data(
    conn: sqlite3.Connection,
    target_dir: Path,
    start: str | None = None,
    end: str | None = None,
) -> dict:
    """Collect all data needed for a compliance report."""
    chain = verify_chain(target_dir)

    # Ledger events
    ledger_path = get_ledger_path(target_dir)
    events = []
    if ledger_path.exists():
        lconn = sqlite3.connect(str(ledger_path))
        lconn.row_factory = sqlite3.Row

        query = (
            "SELECT seq, entry_id, timestamp, event_type, source, "
            "content_hash, result_hash, prev_hash, chain_hash, summary "
            "FROM ledger"
        )
        params = []
        conditions = []
        if start:
            conditions.append("timestamp >= ?")
            params.append(start)
        if end:
            conditions.append("timestamp <= ?")
            params.append(end)
        if conditions:
            query += " WHERE " + " AND ".join(conditions)
        query += " ORDER BY seq"

        for row in lconn.execute(query, params).fetchall():
            summary = json.loads(row["summary"]) if row["summary"] else {}
            events.append({
                "sequence": row["seq"],
                "timestamp": row["timestamp"],
                "event_type": row["event_type"],
                "source": row["source"],
                "file_path": summary.get("file_path"),
                "content_hash_before": summary.get("prior_hash"),
                "content_hash_after": summary.get("content_hash"),
                "actor": summary.get("change_actor", row["source"]),
                "chain_hash": row["chain_hash"],
            })

        genesis = lconn.execute(
            "SELECT chain_hash FROM ledger ORDER BY seq ASC LIMIT 1"
        ).fetchone()
        terminal = lconn.execute(
            "SELECT chain_hash FROM ledger ORDER BY seq DESC LIMIT 1"
        ).fetchone()
        total_links = lconn.execute(
            "SELECT COUNT(*) FROM ledger"
        ).fetchone()[0]
        lconn.close()
    else:
        genesis = terminal = None
        total_links = 0

    # File inventory
    files = []
    for row in conn.execute(
        "SELECT file_path, content_hash, size_bytes, last_modified, role "
        "FROM file_metadata ORDER BY file_path"
    ).fetchall():
        files.append(dict(row))

    return {
        "chain": chain,
        "events": events,
        "files": files,
        "genesis_hash": genesis["chain_hash"] if genesis else None,
        "terminal_hash": terminal["chain_hash"] if terminal else None,
        "total_links": total_links,
        "target_dir": str(target_dir),
        "start": start,
        "end": end,
    }


# -- JSON export -----------------------------------------------------------

def export_json(
    conn: sqlite3.Connection,
    target_dir: Path,
    output_path: Path,
    start: str | None = None,
    end: str | None = None,
) -> Path:
    """Export compliance report as JSON."""
    data = _collect_report_data(conn, target_dir, start, end)
    now = datetime.now(timezone.utc).isoformat()

    report = {
        "report_metadata": {
            "tool": "signal-provenance",
            "version": __version__,
            "generated_at": now,
            "reporting_period": {
                "start": data["start"] or data["chain"].get("first", {}).get("timestamp"),
                "end": data["end"] or data["chain"].get("last", {}).get("timestamp"),
            },
            "chain_status": "VALID" if data["chain"].get("valid") else "BROKEN",
            "total_events": len(data["events"]),
            "hash_algorithm": "SHA-256",
            "monitored_directory": data["target_dir"],
        },
        "chain_verification": {
            "genesis_hash": data["genesis_hash"],
            "terminal_hash": data["terminal_hash"],
            "total_links": data["total_links"],
            "verified": data["chain"].get("valid", False),
            "breaks": data["chain"].get("breaks", []),
        },
        "events": data["events"],
        "file_inventory": data["files"],
        "compliance_mapping": {
            k: v["sections"] for k, v in COMPLIANCE_MAPPING.items()
        },
    }

    output_path.write_text(
        json.dumps(report, indent=2, default=str),
        encoding="utf-8",
    )
    return output_path


# -- PDF export ------------------------------------------------------------

_PDF_TEMPLATE = """<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<style>
@page {{
    size: letter;
    margin: 1in 0.75in;
    @bottom-right {{ content: "Page " counter(page) " of " counter(pages); font-size: 9px; color: #666; }}
}}
body {{ font-family: "Helvetica Neue", Helvetica, Arial, sans-serif; font-size: 11px; color: #222; line-height: 1.5; }}
h1 {{ font-size: 22px; color: #111; border-bottom: 2px solid #111; padding-bottom: 8px; margin-top: 0; }}
h2 {{ font-size: 16px; color: #333; border-bottom: 1px solid #ccc; padding-bottom: 4px; margin-top: 28px; }}
h3 {{ font-size: 13px; color: #444; margin-top: 20px; }}
table {{ border-collapse: collapse; width: 100%; margin: 12px 0; font-size: 10px; }}
th {{ background: #f5f5f5; text-align: left; padding: 6px 8px; border: 1px solid #ddd; font-weight: 600; }}
td {{ padding: 5px 8px; border: 1px solid #ddd; vertical-align: top; }}
tr:nth-child(even) td {{ background: #fafafa; }}
.status-valid {{ color: #1a7a2e; font-weight: bold; font-size: 14px; }}
.status-broken {{ color: #c0392b; font-weight: bold; font-size: 14px; }}
.cover {{ text-align: center; padding-top: 2in; page-break-after: always; }}
.cover h1 {{ font-size: 32px; border: none; }}
.cover .subtitle {{ font-size: 16px; color: #666; margin-top: 8px; }}
.cover .meta {{ font-size: 12px; color: #888; margin-top: 40px; }}
.hash {{ font-family: "Courier New", monospace; font-size: 9px; word-break: break-all; }}
.methodology {{ background: #f9f9f9; padding: 16px; border-left: 3px solid #333; margin: 12px 0; }}
.attestation {{ border: 2px solid #333; padding: 20px; margin-top: 30px; text-align: center; }}
</style>
</head>
<body>

<!-- Cover -->
<div class="cover">
    <h1>Signal Provenance</h1>
    <div class="subtitle">Compliance Audit Report</div>
    <div class="meta">
        <p><strong>Monitored Directory:</strong> {target_dir}</p>
        <p><strong>Reporting Period:</strong> {period_start} to {period_end}</p>
        <p><strong>Generated:</strong> {generated_at}</p>
        <p class="{status_class}">Chain Status: {chain_status}</p>
    </div>
</div>

<!-- Executive Summary -->
<h2>Executive Summary</h2>
<table>
    <tr><td><strong>Files Monitored</strong></td><td>{file_count}</td></tr>
    <tr><td><strong>Total Events</strong></td><td>{event_count}</td></tr>
    <tr><td><strong>Chain Status</strong></td><td class="{status_class}">{chain_status}</td></tr>
    <tr><td><strong>Chain Links</strong></td><td>{total_links}</td></tr>
    <tr><td><strong>Hash Algorithm</strong></td><td>SHA-256</td></tr>
    <tr><td><strong>Chain Breaks</strong></td><td>{break_count}</td></tr>
</table>

<!-- Compliance Mapping -->
<h2>Compliance Mapping</h2>
<p>This report satisfies the following regulatory audit trail requirements:</p>
<table>
    <tr><th>Regulation</th><th>Controls Addressed</th><th>Description</th></tr>
    {compliance_rows}
</table>

<!-- Methodology -->
<h2>Methodology</h2>
<div class="methodology">
    <p><strong>Hash Chaining:</strong> Every event is recorded with a SHA-256 hash that incorporates
    the previous event's hash, creating a tamper-evident chain. Any modification to any entry
    invalidates all subsequent hashes.</p>
    <p><strong>Chain Verification:</strong> The <code>verify</code> command recomputes every hash
    from genesis and compares against stored values. A VALID result means zero tampering detected.
    A BROKEN result identifies the exact sequence number where the chain diverges.</p>
    <p><strong>File Perception:</strong> File state is perceived via filesystem metadata (mtime, size)
    and content hashing (SHA-256). The full content hash is recorded at each observation point,
    enabling temporal reconstruction of any file's state.</p>
    <p><strong>Actor Attribution:</strong> Every event records the process or user that caused the
    change, providing chain-of-custody from creation through every modification.</p>
</div>

<!-- Event Log -->
<h2>Event Log</h2>
<table>
    <tr><th>#</th><th>Timestamp</th><th>Event</th><th>File</th><th>Hash After</th><th>Actor</th></tr>
    {event_rows}
</table>

<!-- Chain Verification -->
<h2>Chain Verification</h2>
<table>
    <tr><td><strong>Genesis Hash</strong></td><td class="hash">{genesis_hash}</td></tr>
    <tr><td><strong>Terminal Hash</strong></td><td class="hash">{terminal_hash}</td></tr>
    <tr><td><strong>Total Links</strong></td><td>{total_links}</td></tr>
    <tr><td><strong>Verification Result</strong></td><td class="{status_class}">{chain_status}</td></tr>
</table>

<!-- File Inventory -->
<h2>File Inventory</h2>
<table>
    <tr><th>File Path</th><th>Content Hash</th><th>Size</th><th>Last Modified</th><th>Role</th></tr>
    {file_rows}
</table>

<!-- Attestation -->
<div class="attestation">
    <p><strong>System-Generated Attestation</strong></p>
    <p>This report was generated by Signal Provenance v{version} at {generated_at}.</p>
    <p>The hash chain was verified at generation time. Result: <span class="{status_class}">{chain_status}</span>.</p>
    <p>No human intervention was involved in the generation of this report.</p>
</div>

</body>
</html>"""


def _format_size(size_bytes) -> str:
    """Format bytes as human-readable size."""
    if size_bytes is None:
        return "?"
    for unit in ("B", "KB", "MB", "GB"):
        if abs(size_bytes) < 1024:
            return f"{size_bytes:.0f} {unit}" if unit == "B" else f"{size_bytes:.1f} {unit}"
        size_bytes /= 1024
    return f"{size_bytes:.1f} TB"


def export_pdf(
    conn: sqlite3.Connection,
    target_dir: Path,
    output_path: Path,
    start: str | None = None,
    end: str | None = None,
) -> Path:
    """Export compliance report as PDF. Requires weasyprint."""
    try:
        from weasyprint import HTML
    except ImportError:
        raise RuntimeError(
            "PDF export requires weasyprint. "
            "Install: pip install 'signal-provenance[pdf]'"
        )

    data = _collect_report_data(conn, target_dir, start, end)
    now = datetime.now(timezone.utc).isoformat()
    chain_valid = data["chain"].get("valid", False)

    # Compliance rows
    compliance_rows = ""
    for key, info in COMPLIANCE_MAPPING.items():
        name = key.replace("_", " ").upper()
        sections = ", ".join(info["sections"])
        compliance_rows += (
            f"<tr><td>{name}</td><td>{sections}</td>"
            f"<td>{info['description']}</td></tr>\n"
        )

    # Event rows
    event_rows = ""
    for e in data["events"]:
        fp = e.get("file_path") or ""
        hash_after = e.get("content_hash_after") or ""
        actor = e.get("actor") or ""
        ts = e["timestamp"][:19] if e.get("timestamp") else ""
        event_rows += (
            f"<tr><td>{e['sequence']}</td><td>{ts}</td>"
            f"<td>{e['event_type']}</td><td>{fp}</td>"
            f"<td class='hash'>{hash_after}</td><td>{actor}</td></tr>\n"
        )

    # File rows
    file_rows = ""
    for f in data["files"]:
        ch = f.get("content_hash") or ""
        size = _format_size(f.get("size_bytes"))
        lm = (f.get("last_modified") or "")[:19]
        role = f.get("role") or ""
        file_rows += (
            f"<tr><td>{f['file_path']}</td><td class='hash'>{ch}</td>"
            f"<td>{size}</td><td>{lm}</td><td>{role}</td></tr>\n"
        )

    period_start = (
        data["start"]
        or (data["chain"].get("first", {}).get("timestamp", ""))[:19]
    )
    period_end = (
        data["end"]
        or (data["chain"].get("last", {}).get("timestamp", ""))[:19]
    )

    html_str = _PDF_TEMPLATE.format(
        target_dir=data["target_dir"],
        period_start=period_start,
        period_end=period_end,
        generated_at=now[:19],
        chain_status="VALID" if chain_valid else "BROKEN",
        status_class="status-valid" if chain_valid else "status-broken",
        file_count=len(data["files"]),
        event_count=len(data["events"]),
        total_links=data["total_links"],
        break_count=len(data["chain"].get("breaks", [])),
        compliance_rows=compliance_rows,
        event_rows=event_rows,
        genesis_hash=data["genesis_hash"] or "N/A",
        terminal_hash=data["terminal_hash"] or "N/A",
        file_rows=file_rows,
        version=__version__,
    )

    HTML(string=html_str).write_pdf(str(output_path))
    return output_path
