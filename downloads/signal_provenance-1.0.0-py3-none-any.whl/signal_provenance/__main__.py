"""Allow running as: python3 -m signal_provenance"""
import sys


def _main():
    # If invoked with CLI arguments, use the normal CLI
    if len(sys.argv) > 1:
        from signal_provenance.cli import main
        main()
        return

    # No arguments: launch tray mode
    try:
        from signal_provenance.tray import run_tray
        run_tray()
    except ImportError:
        # pystray/pillow not installed -- fall back to terminal dashboard
        from signal_provenance.dashboard import serve_dashboard
        serve_dashboard(target_dir=None)


_main()
