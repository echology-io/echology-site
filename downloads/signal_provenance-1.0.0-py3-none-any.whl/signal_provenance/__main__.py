"""Allow running as: python3 -m signal_provenance"""
from signal_provenance.cli import main

main()
