"""Persistent configuration for Signal Provenance.

Stored at .signal-provenance/config.json. Written once by `watch`,
read by `harvest` and `watch` on subsequent runs.
"""

from __future__ import annotations

import json
from pathlib import Path

DEFAULT_CONFIG = {
    "target": "",
    "provider": "local",
    "exclude": [],
    "include": [],
    "interval_minutes": 60,
    "report_to": "",
    "report_format": "both",
    "deployment_name": "",
}


def config_path(target_dir: Path) -> Path:
    return target_dir / ".signal-provenance" / "config.json"


def load_config(target_dir: Path) -> dict:
    """Load config from .signal-provenance/config.json, or return defaults."""
    cp = config_path(target_dir)
    if cp.exists():
        try:
            with open(cp) as f:
                saved = json.load(f)
            merged = {**DEFAULT_CONFIG, **saved}
            return merged
        except (json.JSONDecodeError, OSError):
            pass
    return dict(DEFAULT_CONFIG)


def save_config(target_dir: Path, cfg: dict) -> None:
    """Write config to .signal-provenance/config.json."""
    cp = config_path(target_dir)
    cp.parent.mkdir(parents=True, exist_ok=True)
    with open(cp, "w") as f:
        json.dump(cfg, f, indent=2)
        f.write("\n")
