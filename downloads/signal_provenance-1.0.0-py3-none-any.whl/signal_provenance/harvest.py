"""Filesystem perception -- harvest file metadata from any storage backend.

Deterministic. No git required. No external dependencies for local use.
Cloud providers (S3, SharePoint, Google Drive) available via optional deps.
"""

import json
import sqlite3
import time
import platform
from datetime import datetime, timezone
from pathlib import Path

from signal_provenance.db import (
    get_all_file_ids,
    get_latest_snapshot_hashes,
    log_metadata_harvest,
    record_artifact_deletion,
    record_artifact_snapshot,
    upsert_file_metadata,
    witness,
)
from signal_provenance.providers import (
    FileEntry,
    StorageProvider,
    classify_role,
    get_provider,
)
from signal_provenance.config import load_config


# Re-export for backwards compatibility with tests
from signal_provenance.providers.local import LocalProvider
_sha256 = LocalProvider._sha256


def harvest(conn: sqlite3.Connection, target_dir: Path,
            verbose: bool = False, provider: StorageProvider | None = None) -> dict:
    """Harvest metadata from a storage target into the provenance database.

    If provider is None, resolves from target_dir (local filesystem).
    Pass a provider explicitly for cloud targets (S3, SharePoint, Google Drive).

    Returns summary dict with counts and timing.
    """
    start = time.monotonic()
    target_dir = target_dir.expanduser().resolve()
    host = platform.node()

    if provider is None:
        provider = get_provider(str(target_dir))

    # Collect all files from provider
    entries: list[FileEntry] = list(provider.list_files())

    # Bulk pre-loads
    existing_ids = get_all_file_ids(conn)
    prior_hashes = get_latest_snapshot_hashes(conn)

    # Edit frequencies -- 6 windows form the velocity vector per file
    _freq_windows = [
        ("1d", "-1 days"), ("7d", "-7 days"), ("14d", "-14 days"),
        ("21d", "-21 days"), ("30d", "-30 days"), ("90d", "-90 days"),
    ]
    edit_freqs: dict[str, dict[str, int]] = {}
    for label, offset in _freq_windows:
        for row in conn.execute(
            "SELECT f.file_path, count(*) as cnt FROM artifact_snapshots a "
            "JOIN file_metadata f ON a.file_id = f.id "
            "WHERE a.change_type IN ('created', 'modified') "
            "AND a.perceived_at >= datetime('now', ?) "
            "GROUP BY f.file_path", (offset,)
        ).fetchall():
            edit_freqs.setdefault(row[0], {})[label] = row[1]

    # Pre-load existing state for mtime-based skip
    existing_state: dict[str, tuple] = {}
    for row in conn.execute(
        "SELECT file_path, first_seen, last_modified, content_hash, "
        "lines_of_code FROM file_metadata"
    ).fetchall():
        existing_state[row[0]] = (row[1], row[2], row[3], row[4])

    # Create harvest record
    harvest_id = log_metadata_harvest(
        conn,
        repo_root=str(target_dir),
        files_total=len(entries),
        files_new=0, files_updated=0, files_deleted=0, duration_ms=0,
    )

    new_count = 0
    updated_count = 0
    skipped_count = 0

    for entry in entries:
        rel_path = entry["path"]
        ext = entry["extension"]
        size = entry["size"]
        last_modified = entry["mtime"]
        last_accessed = entry["atime"]
        content_hash = entry["content_hash"]
        loc = entry["lines_of_code"]

        known_id = existing_ids.get(rel_path)
        prior = existing_state.get(rel_path)

        # mtime-based skip: if mtime unchanged and hash matches, content is identical
        if prior and prior[1] == last_modified and prior[2] == content_hash:
            skipped_count += 1
            first_seen = prior[0]
            content_hash = prior[2]
            loc = prior[3]
            if verbose:
                print(f"  [skip] {rel_path}")
        else:
            first_seen = last_modified  # best estimate for new files
            if prior:
                first_seen = prior[0]  # preserve original observation
            if verbose:
                status = "new" if known_id is None else "mod"
                print(f"  [{status}] {rel_path}")

        role = classify_role(rel_path, ext)
        fv = edit_freqs.get(rel_path, {})

        if known_id is not None:
            updated_count += 1
        else:
            new_count += 1

        file_id = upsert_file_metadata(
            conn,
            commit=False,
            _existing_id=known_id,
            file_path=rel_path,
            content_hash=content_hash,
            size_bytes=size,
            extension=ext,
            role=role,
            first_seen=first_seen,
            last_modified=last_modified,
            last_accessed=last_accessed,
            edit_frequency_1d=fv.get("1d", 0),
            edit_frequency_7d=fv.get("7d", 0),
            edit_frequency_14d=fv.get("14d", 0),
            edit_frequency_21d=fv.get("21d", 0),
            edit_frequency_30d=fv.get("30d", 0),
            edit_frequency_90d=fv.get("90d", 0),
            lines_of_code=loc,
        )

        if known_id is None:
            existing_ids[rel_path] = file_id

        # Record artifact snapshot
        if content_hash:
            prior_hash = prior_hashes.get(file_id)
            record_artifact_snapshot(
                conn, target_dir, rel_path, content_hash,
                size_bytes=size, lines_of_code=loc,
                last_accessed=last_accessed,
                harvest_id=harvest_id,
                change_actor="harvest",
                commit=False,
                _file_id=file_id,
                _prior_hash=prior_hash,
            )

    conn.commit()

    # Perceive deleted files via provider
    deleted_paths = provider.detect_deletions(set(existing_ids.keys()))
    deleted_count = len(deleted_paths)
    if deleted_paths:
        for dp in deleted_paths:
            record_artifact_deletion(conn, target_dir, dp,
                                     harvest_id=harvest_id)
        conn.commit()

    duration_ms = int((time.monotonic() - start) * 1000)

    conn.execute(
        "UPDATE metadata_harvests SET files_new = ?, files_updated = ?, "
        "files_deleted = ?, files_skipped = ?, duration_ms = ? WHERE id = ?",
        (new_count, updated_count, deleted_count, skipped_count,
         duration_ms, harvest_id),
    )
    conn.commit()

    # Witness harvest completion
    witness(target_dir, "harvest_completed", "provenance.harvest", {
        "harvest_id": harvest_id,
        "files_total": len(entries),
        "files_new": new_count,
        "files_updated": updated_count,
        "files_deleted": deleted_count,
        "files_skipped": skipped_count,
        "duration_ms": duration_ms,
        "host": host,
    })

    return {
        "harvest_id": harvest_id,
        "files_total": len(entries),
        "files_new": new_count,
        "files_updated": updated_count,
        "files_deleted": deleted_count,
        "files_skipped": skipped_count,
        "duration_ms": duration_ms,
    }


def auto_report(conn: sqlite3.Connection, target_dir: Path) -> list[Path]:
    """Generate reports to the configured report_to directory.

    Reads config for report_to and report_format. Generates PDF and/or JSON.
    Maintains symlinks to latest reports. Cleans up old reports (keeps 30).
    Returns list of generated report paths.
    """
    from signal_provenance.license import check_license

    cfg = load_config(target_dir)
    report_to = cfg.get("report_to", "")
    if not report_to:
        report_to = str(target_dir / ".signal-provenance" / "reports")

    report_dir = Path(report_to)
    report_dir.mkdir(parents=True, exist_ok=True)

    fmt = cfg.get("report_format", "both")
    today = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H%M%S")
    generated = []

    # Dashboard always generated (no license gate -- it's local-only UX)
    from signal_provenance.dashboard import export_dashboard
    dash_out = report_dir / f"dashboard-{today}.html"
    try:
        export_dashboard(conn, target_dir, dash_out)
        generated.append(dash_out)
        _symlink_latest(report_dir, dash_out, "dashboard.html")
    except Exception:
        pass

    # Check license -- PDF/JSON export is pro feature
    lic = check_license()
    if lic is None:
        return generated

    if fmt in ("json", "both"):
        from signal_provenance.export import export_json
        out = report_dir / f"provenance-{today}.json"
        try:
            export_json(conn, target_dir, out)
            generated.append(out)
            _symlink_latest(report_dir, out, "provenance-latest.json")
        except Exception:
            pass

    if fmt in ("pdf", "both"):
        from signal_provenance.export import export_pdf
        out = report_dir / f"provenance-{today}.pdf"
        try:
            export_pdf(conn, target_dir, out)
            generated.append(out)
            _symlink_latest(report_dir, out, "provenance-latest.pdf")
        except Exception:
            pass

    # Cleanup: keep last 30 reports per format
    _cleanup_old_reports(report_dir, "provenance-*.json", 30)
    _cleanup_old_reports(report_dir, "provenance-*.pdf", 30)
    _cleanup_old_reports(report_dir, "dashboard-*.html", 30)

    return generated


def _symlink_latest(report_dir: Path, target: Path, link_name: str) -> None:
    """Create or update a symlink to the latest report."""
    link = report_dir / link_name
    try:
        if link.is_symlink() or link.exists():
            link.unlink()
        link.symlink_to(target.name)
    except OSError:
        pass


def _cleanup_old_reports(report_dir: Path, pattern: str, keep: int) -> None:
    """Remove old reports, keeping the most recent `keep` files."""
    import glob
    files = sorted(glob.glob(str(report_dir / pattern)))
    # Don't delete symlinks
    files = [f for f in files if not Path(f).is_symlink()]
    if len(files) > keep:
        for old in files[:-keep]:
            try:
                Path(old).unlink()
            except OSError:
                pass
