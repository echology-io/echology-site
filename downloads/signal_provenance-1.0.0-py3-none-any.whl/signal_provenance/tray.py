"""System tray icon for Signal Provenance.

Runs the dashboard server in a background thread and presents a
system tray icon with menu: Open Dashboard, Quit.
"""

from __future__ import annotations

import sys
import threading
import webbrowser


def _create_icon_image():
    """Generate a simple tray icon using PIL."""
    from PIL import Image, ImageDraw

    size = 64
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    # Green circle matching the accent color
    draw.ellipse([4, 4, size - 4, size - 4], fill=(110, 231, 183, 255))
    # "SP" text in dark color
    try:
        from PIL import ImageFont
        font = ImageFont.truetype("arial", 22)
    except (OSError, ImportError):
        font = ImageFont.load_default()
    draw.text((size // 2, size // 2), "SP", fill=(10, 10, 10, 255),
              anchor="mm", font=font)
    return img


def run_tray(target_dir=None, port: int = 9111) -> None:
    """Launch dashboard server in background thread, show tray icon."""
    import pystray

    from signal_provenance.dashboard import create_dashboard_server

    server, url = create_dashboard_server(target_dir, port)

    # Run HTTP server in daemon thread
    server_thread = threading.Thread(target=server.serve_forever, daemon=True)
    server_thread.start()

    # Open browser on first launch
    threading.Timer(0.5, lambda: webbrowser.open(url)).start()

    def on_open(icon, item):
        webbrowser.open(url)

    def on_quit(icon, item):
        server.shutdown()
        icon.stop()

    icon = pystray.Icon(
        "signal-provenance",
        icon=_create_icon_image(),
        title="Signal Provenance",
        menu=pystray.Menu(
            pystray.MenuItem("Open Dashboard", on_open, default=True),
            pystray.MenuItem("Quit", on_quit),
        ),
    )

    # icon.run() blocks the main thread (required on macOS for AppKit)
    print(f"Signal Provenance running at {url}")
    print("Look for the tray icon to open dashboard or quit.")
    icon.run()


if __name__ == "__main__":
    run_tray()
