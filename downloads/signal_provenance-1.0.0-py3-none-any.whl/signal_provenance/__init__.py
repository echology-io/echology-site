"""Signal Provenance -- hash-chained file provenance for any directory."""

__version__ = "1.0.0"
