"""Self-contained HTML dashboard for Signal Provenance.

Two modes:
  Static:  export_dashboard() generates a single dashboard.html file.
  Live:    serve_dashboard() runs a local HTTP server with action buttons
           that trigger harvest, PDF export, and auto-refresh.
"""

from __future__ import annotations

import json
import sqlite3
import threading
import webbrowser
from datetime import datetime, timezone
from http.server import HTTPServer, BaseHTTPRequestHandler
from pathlib import Path

from signal_provenance import __version__
from signal_provenance.export import COMPLIANCE_MAPPING, _collect_report_data, _format_size


def _build_dashboard_data(conn: sqlite3.Connection, target_dir: Path) -> str:
    """Build the JSON data blob for the dashboard template."""
    from signal_provenance.config import load_config

    data = _collect_report_data(conn, target_dir)
    now = datetime.now(timezone.utc).isoformat()
    chain_valid = data["chain"].get("valid", False)
    cfg = load_config(target_dir)

    # Deployment name from config, fallback to directory name
    deployment_name = cfg.get("deployment_name", "") or target_dir.name

    # Harvest history
    harvests = []
    for row in conn.execute(
        "SELECT id, harvested_at, files_total, files_new, files_updated, "
        "files_deleted, files_skipped, duration_ms "
        "FROM metadata_harvests ORDER BY harvested_at DESC LIMIT 50"
    ).fetchall():
        harvests.append({
            "id": row[0], "started_at": row[1], "files_total": row[2],
            "files_new": row[3], "files_updated": row[4],
            "files_deleted": row[5], "files_skipped": row[6],
            "duration_ms": row[7],
        })

    # Chain continuity -- days from first event to now
    first_event = None
    chain_days = 0
    if data["events"]:
        first_event = data["events"][0].get("timestamp", "")[:19]
        try:
            first_dt = datetime.fromisoformat(first_event.replace("Z", "+00:00"))
            chain_days = (datetime.now(timezone.utc) - first_dt).days
        except (ValueError, TypeError):
            pass

    role_counts = {}
    for f in data["files"]:
        role = f.get("role") or "other"
        role_counts[role] = role_counts.get(role, 0) + 1

    total_size = sum(f.get("size_bytes") or 0 for f in data["files"])

    event_types = {}
    for e in data["events"]:
        et = e.get("event_type", "unknown")
        event_types[et] = event_types.get(et, 0) + 1

    file_tree = []
    for f in data["files"]:
        file_tree.append({
            "path": f["file_path"],
            "hash": (f.get("content_hash") or "")[:12],
            "size": _format_size(f.get("size_bytes")),
            "modified": (f.get("last_modified") or "")[:19],
            "role": f.get("role") or "other",
        })

    recent = []
    for e in data["events"][-100:]:
        recent.append({
            "seq": e["sequence"],
            "time": (e.get("timestamp") or "")[:19],
            "type": e.get("event_type", ""),
            "file": e.get("file_path") or "",
            "hash": (e.get("content_hash_after") or "")[:12],
            "actor": e.get("actor") or "",
        })

    compliance = []
    for key, info in COMPLIANCE_MAPPING.items():
        compliance.append({
            "framework": key.replace("_", " ").upper(),
            "sections": info["sections"],
            "description": info["description"],
            "status": "covered" if chain_valid and data["total_links"] > 0 else "no_data",
        })

    return json.dumps({
        "generated": now[:19],
        "version": __version__,
        "target": str(target_dir),
        "deployment_name": deployment_name,
        "chain_valid": chain_valid,
        "total_links": data["total_links"],
        "genesis_hash": data["genesis_hash"],
        "terminal_hash": data["terminal_hash"],
        "first_event": first_event,
        "chain_days": chain_days,
        "file_count": len(data["files"]),
        "event_count": len(data["events"]),
        "total_size": _format_size(total_size),
        "role_counts": role_counts,
        "event_types": event_types,
        "harvests": harvests,
        "files": file_tree,
        "recent": recent,
        "compliance": compliance,
        "interval_minutes": cfg.get("interval_minutes", 60),
        "snapshot_retain": cfg.get("snapshot_retain", 10),
    }, default=str)


def export_dashboard(
    conn: sqlite3.Connection,
    target_dir: Path,
    output_path: Path,
) -> Path:
    """Generate a self-contained HTML dashboard."""
    dashboard_data = _build_dashboard_data(conn, target_dir)
    html = _DASHBOARD_TEMPLATE.replace("__DASHBOARD_DATA__", dashboard_data)
    output_path.write_text(html, encoding="utf-8")
    return output_path


def _dashboard_html(target_dir: Path, sources: list | None = None) -> str:
    """Generate dashboard HTML string from current state."""
    from signal_provenance.db import get_connection
    conn = get_connection(target_dir)
    dashboard_data = _build_dashboard_data(conn, target_dir)
    conn.close()
    html = _DASHBOARD_TEMPLATE.replace("__DASHBOARD_DATA__", dashboard_data)
    sources_json = json.dumps(sources or [])
    html = html.replace("__SOURCES_DATA__", sources_json)
    return html


def _send_notification(cfg: dict, subject: str, body: str) -> None:
    """Send an email notification in a background thread. No-op if not configured."""
    email = cfg.get("notify_email", "")
    host = cfg.get("smtp_host", "")
    if not email or not host:
        return

    def _send():
        import smtplib
        from email.mime.text import MIMEText
        try:
            msg = MIMEText(body, "plain")
            msg["Subject"] = subject
            msg["From"] = cfg.get("smtp_from") or f"signal-provenance@{host}"
            msg["To"] = email
            port = int(cfg.get("smtp_port", 587))
            with smtplib.SMTP(host, port, timeout=30) as s:
                if port != 25:
                    s.starttls()
                user = cfg.get("smtp_user", "")
                if user:
                    s.login(user, cfg.get("smtp_pass", ""))
                s.send_message(msg)
        except Exception:
            pass  # best-effort, don't block harvest

    threading.Thread(target=_send, daemon=True).start()


def create_dashboard_server(target_dir: Path | None = None,
                            port: int = 9111) -> tuple:
    """Create the dashboard HTTP server without starting it.

    Returns (server, url) tuple. Call server.serve_forever() to start.
    Used by tray.py for background operation and by serve_dashboard
    for terminal operation.
    """
    from signal_provenance.db import get_connection, init_db
    from signal_provenance.harvest import harvest, auto_report
    from signal_provenance.providers import get_provider
    from signal_provenance.config import load_config

    from signal_provenance.config import load_sources, register_source

    state = {"target_dir": None}
    if target_dir is not None:
        target_dir = target_dir.expanduser().resolve()
        state["target_dir"] = target_dir
        register_source(str(target_dir), "local")

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, fmt, *args):
            pass  # suppress request logs

        def do_GET(self):
            from urllib.parse import urlparse
            parsed_path = urlparse(self.path).path
            if parsed_path == "/" or parsed_path == "/dashboard":
                td = state["target_dir"]
                if td is None:
                    self._respond(200, "text/html", _SETUP_TEMPLATE.encode())
                else:
                    html = _dashboard_html(td, load_sources())
                    self._respond(200, "text/html", html.encode())
            elif self.path.startswith("/api/download"):
                from urllib.parse import urlparse, parse_qs
                qs = parse_qs(urlparse(self.path).query)
                fpath = Path(qs.get("path", [""])[0])
                if state["target_dir"] and fpath.exists() and fpath.is_file():
                    self._respond(200, "application/octet-stream",
                                  fpath.read_bytes(),
                                  extra={"Content-Disposition":
                                         f'attachment; filename="{fpath.name}"'})
                else:
                    self._json(404, {"ok": False, "error": "File not found"})
            else:
                self._json(404, {"ok": False, "error": "Not found"})

        def do_POST(self):
            if self.path == "/api/browse":
                self._handle_browse()
            elif self.path == "/api/setup":
                self._handle_setup()
            elif self.path == "/api/harvest":
                self._handle_harvest()
            elif self.path == "/api/export-pdf":
                self._handle_export_pdf()
            elif self.path == "/api/schedule-cron":
                self._handle_schedule_cron()
            elif self.path == "/api/save-settings":
                self._handle_save_settings()
            elif self.path == "/api/switch-source":
                self._handle_switch_source()
            elif self.path == "/api/save-notifications":
                self._handle_save_notifications()
            elif self.path == "/api/export-html":
                self._handle_export_html()
            elif self.path.startswith("/api/open-file"):
                self._handle_open_file()
            else:
                self._json(404, {"ok": False, "error": "Not found"})

        def _handle_browse(self):
            import subprocess
            import sys
            folder = None

            try:
                if sys.platform == "linux":
                    for cmd in [
                        ["zenity", "--file-selection", "--directory",
                         "--title=Select folder to watch",
                         "--filename=" + str(Path.home()) + "/",
                         "--modal"],
                        ["kdialog", "--getexistingdirectory",
                         str(Path.home()), "--title", "Select folder to watch"],
                    ]:
                        try:
                            result = subprocess.run(
                                cmd, capture_output=True, text=True, timeout=120)
                            if result.returncode == 0 and result.stdout.strip():
                                folder = result.stdout.strip()
                                break
                        except FileNotFoundError:
                            continue
                elif sys.platform == "darwin":
                    script = (
                        'tell application "System Events" to activate\n'
                        'set f to POSIX path of (choose folder with prompt '
                        '"Select folder to watch")\nreturn f'
                    )
                    try:
                        result = subprocess.run(
                            ["osascript", "-e", script],
                            capture_output=True, text=True, timeout=120)
                        if result.returncode == 0 and result.stdout.strip():
                            folder = result.stdout.strip().rstrip("/")
                    except FileNotFoundError:
                        pass
            except Exception:
                pass

            # Fallback: tkinter
            if folder is None:
                try:
                    import tkinter as tk
                    from tkinter import filedialog
                    root = tk.Tk()
                    root.withdraw()
                    root.attributes('-topmost', True)
                    folder = filedialog.askdirectory(
                        title="Select folder to watch",
                        initialdir=str(Path.home()))
                    root.destroy()
                except Exception:
                    pass

            if folder:
                self._json(200, {"ok": True, "folder": folder})
            else:
                self._json(200, {"ok": False, "error": "Cancelled"})

        def _handle_setup(self):
            import os as _os
            content_length = int(self.headers.get("Content-Length", 0))
            body = self.rfile.read(content_length) if content_length else b""
            try:
                data = json.loads(body) if body else {}
            except json.JSONDecodeError:
                self._json(400, {"ok": False, "error": "Invalid JSON"})
                return

            code = (data.get("code") or "").strip()
            source = (data.get("source") or "local").strip()

            # Activate license if code provided
            if code:
                try:
                    from signal_provenance.license import activate, LicenseError
                    activate(code)
                except Exception as e:
                    self._json(400, {"ok": False, "error": f"Activation failed: {e}"})
                    return

            if source == "cloud":
                prov = (data.get("provider") or "").strip()
                if prov == "sharepoint":
                    site = (data.get("sp_site") or "").strip()
                    library = (data.get("sp_library") or "Documents").strip()
                    if not site:
                        self._json(400, {"ok": False, "error": "SharePoint site name is required"})
                        return
                    # Set env vars for the provider
                    _os.environ["SP_TENANT_ID"] = (data.get("sp_tenant") or "").strip()
                    _os.environ["SP_CLIENT_ID"] = (data.get("sp_client_id") or "").strip()
                    _os.environ["SP_CLIENT_SECRET"] = (data.get("sp_client_secret") or "").strip()
                    target_uri = f"sharepoint://{site}/{library}"
                elif prov == "gdrive":
                    folder_id = (data.get("gd_folder_id") or "").strip()
                    creds = (data.get("gd_creds") or "").strip()
                    if not folder_id or not creds:
                        self._json(400, {"ok": False, "error": "Folder ID and credentials are required"})
                        return
                    _os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = creds
                    target_uri = f"gdrive://{folder_id}"
                elif prov == "s3":
                    s3_target = (data.get("s3_target") or "").strip()
                    if not s3_target:
                        self._json(400, {"ok": False, "error": "S3 bucket/prefix is required"})
                        return
                    target_uri = f"s3://{s3_target}"
                else:
                    self._json(400, {"ok": False, "error": f"Unknown provider: {prov}"})
                    return

                # Cloud providers store provenance data in ~/.signal-provenance/cloud/<name>
                cloud_name = target_uri.replace("://", "_").replace("/", "_")
                folder_path = Path.home() / ".signal-provenance" / "cloud" / cloud_name
                folder_path.mkdir(parents=True, exist_ok=True)

                # Store the target URI in config for re-scan
                cfg_file = folder_path / ".signal-provenance" / "config.json"
                cfg_file.parent.mkdir(parents=True, exist_ok=True)
                import json as _json
                cfg_data = {}
                if cfg_file.exists():
                    cfg_data = _json.loads(cfg_file.read_text())
                cfg_data["target_uri"] = target_uri
                cfg_file.write_text(_json.dumps(cfg_data, indent=2))

                try:
                    provider = get_provider(target_uri)
                except Exception as e:
                    self._json(400, {"ok": False, "error": f"Provider connection failed: {e}"})
                    return
            else:
                folder = (data.get("folder") or "").strip()
                if not folder:
                    self._json(400, {"ok": False, "error": "Folder path is required"})
                    return
                folder_path = Path(folder).expanduser().resolve()
                if not folder_path.is_dir():
                    self._json(400, {"ok": False, "error": f"Not a directory: {folder_path}"})
                    return
                cfg = load_config(folder_path)
                provider = get_provider(
                    str(folder_path),
                    exclude=cfg.get("exclude"),
                    include=cfg.get("include"),
                )

            # Init provenance
            prov_dir = folder_path / ".signal-provenance"
            prov_dir.mkdir(parents=True, exist_ok=True)
            conn = get_connection(folder_path)
            init_db(conn)

            # First harvest
            try:
                summary = harvest(conn, folder_path, provider=provider)
            except Exception as e:
                conn.close()
                self._json(500, {"ok": False, "error": f"Harvest failed: {e}"})
                return

            # Generate reports
            auto_report(conn, folder_path)
            conn.close()

            # Switch to dashboard mode and persist source
            state["target_dir"] = folder_path
            src_type = "cloud" if source == "cloud" else "local"
            register_source(str(folder_path), src_type)

            self._json(200, {
                "ok": True,
                "redirect": f"/?welcome=1&files={summary['files_total']}",
                "message": (f"Initialized and scanned {summary['files_total']} files "
                            f"({summary['files_new']} new) "
                            f"in {summary['duration_ms']}ms"),
            })

        def _handle_schedule_cron(self):
            """Set up cron to harvest --all at the configured interval."""
            import shutil
            import subprocess as _sub
            td = state["target_dir"]
            if td is None:
                self._json(400, {"ok": False, "error": "Not configured"})
                return
            cfg = load_config(td)
            interval = cfg.get("interval_minutes", 60)

            # Find the signal-provenance binary
            sp_bin = shutil.which("signal-provenance")
            if not sp_bin:
                import sys as _sys
                sp_bin = str(Path(_sys.executable).parent / "signal-provenance")
                if not Path(sp_bin).exists():
                    # Use python -m fallback
                    import sys as _sys
                    sp_bin = f"{_sys.executable} -m signal_provenance"

            cron_cmd = f"{sp_bin} harvest --all --auto-report"
            log_dir = Path.home() / ".local" / "log"
            log_dir.mkdir(parents=True, exist_ok=True)
            log_file = log_dir / "signal-provenance.log"
            cron_line = f"*/{interval} * * * * {cron_cmd} >> {log_file} 2>&1"

            try:
                existing = _sub.run(["crontab", "-l"], capture_output=True, text=True)
                current = existing.stdout if existing.returncode == 0 else ""
            except FileNotFoundError:
                self._json(400, {"ok": False,
                                 "error": f"crontab not available. Add manually: {cron_line}"})
                return

            marker = "signal-provenance harvest"
            if marker in current and "--all" in current:
                self._json(200, {"ok": True,
                                 "message": f"Already scheduled (every {interval}min)"})
                return

            # Remove any old single-source entries
            lines = [l for l in current.splitlines()
                     if "signal-provenance harvest" not in l]
            lines.append(cron_line)
            new_crontab = "\n".join(lines) + "\n"

            result = _sub.run(["crontab", "-"], input=new_crontab,
                              capture_output=True, text=True)
            if result.returncode == 0:
                self._json(200, {"ok": True,
                                 "message": f"Scheduled: harvest all sources every {interval} minutes"})
            else:
                self._json(500, {"ok": False,
                                 "error": f"crontab write failed. Add manually: {cron_line}"})

        def _handle_save_settings(self):
            from signal_provenance.config import save_config
            td = state["target_dir"]
            if td is None:
                self._json(400, {"ok": False, "error": "Not configured"})
                return
            content_length = int(self.headers.get("Content-Length", 0))
            body = self.rfile.read(content_length) if content_length else b""
            try:
                data = json.loads(body) if body else {}
            except json.JSONDecodeError:
                self._json(400, {"ok": False, "error": "Invalid JSON"})
                return
            cfg = load_config(td)
            if "interval_minutes" in data:
                cfg["interval_minutes"] = max(1, min(1440, int(data["interval_minutes"])))
            if "snapshot_retain" in data:
                cfg["snapshot_retain"] = max(1, min(100, int(data["snapshot_retain"])))
            save_config(td, cfg)
            self._json(200, {"ok": True, "message": "Settings saved"})

        def _handle_save_notifications(self):
            from signal_provenance.config import save_config
            td = state["target_dir"]
            if td is None:
                self._json(400, {"ok": False, "error": "Not configured"})
                return
            content_length = int(self.headers.get("Content-Length", 0))
            body = self.rfile.read(content_length) if content_length else b""
            try:
                data = json.loads(body) if body else {}
            except json.JSONDecodeError:
                self._json(400, {"ok": False, "error": "Invalid JSON"})
                return
            cfg = load_config(td)
            cfg["notify_email"] = (data.get("notify_email") or "").strip()
            cfg["notify_on"] = data.get("notify_on", [])
            cfg["smtp_host"] = (data.get("smtp_host") or "").strip()
            cfg["smtp_port"] = int(data.get("smtp_port", 587))
            cfg["smtp_user"] = (data.get("smtp_user") or "").strip()
            cfg["smtp_pass"] = (data.get("smtp_pass") or "").strip()
            cfg["smtp_from"] = (data.get("smtp_from") or "").strip()
            save_config(td, cfg)
            self._json(200, {"ok": True, "message": "Notification settings saved"})

        def _handle_switch_source(self):
            content_length = int(self.headers.get("Content-Length", 0))
            body = self.rfile.read(content_length) if content_length else b""
            try:
                data = json.loads(body) if body else {}
            except json.JSONDecodeError:
                self._json(400, {"ok": False, "error": "Invalid JSON"})
                return
            path = (data.get("path") or "").strip()
            if not path:
                self._json(400, {"ok": False, "error": "No path specified"})
                return
            # Find matching source
            for src in load_sources():
                if src["path"] == path:
                    state["target_dir"] = Path(path)
                    self._json(200, {"ok": True, "refresh": True,
                                     "message": f"Switched to {Path(path).name}"})
                    return
            self._json(400, {"ok": False, "error": "Source not found"})

        def _handle_open_file(self):
            import subprocess
            from urllib.parse import urlparse, parse_qs
            content_length = int(self.headers.get("Content-Length", 0))
            body = self.rfile.read(content_length) if content_length else b""
            try:
                data = json.loads(body) if body else {}
            except json.JSONDecodeError:
                data = {}
            td = state["target_dir"]
            if td is None:
                self._json(400, {"ok": False, "error": "Not configured"})
                return
            rel_path = data.get("path", "")
            full = td / rel_path
            if not full.exists():
                self._json(404, {"ok": False, "error": "File not found"})
                return
            try:
                full.resolve().relative_to(td.resolve())
            except ValueError:
                self._json(403, {"ok": False, "error": "Access denied"})
                return
            try:
                subprocess.Popen(["xdg-open", str(full)],
                                 stdout=subprocess.DEVNULL,
                                 stderr=subprocess.DEVNULL)
            except FileNotFoundError:
                try:
                    subprocess.Popen(["open", str(full)],
                                     stdout=subprocess.DEVNULL,
                                     stderr=subprocess.DEVNULL)
                except FileNotFoundError:
                    self._json(500, {"ok": False, "error": "No file opener found"})
                    return
            self._json(200, {"ok": True, "message": f"Opened {rel_path}"})

        def _handle_harvest(self):
            sources = load_sources()
            if not sources:
                self._json(400, {"ok": False, "error": "Not configured"})
                return
            try:
                results = []
                for src in sources:
                    src_path = Path(src["path"])
                    cfg = load_config(src_path)
                    conn = get_connection(src_path)
                    init_db(conn)

                    # Resolve provider (cloud sources store URI in config)
                    target_uri = cfg.get("target_uri")
                    if target_uri:
                        provider = get_provider(target_uri)
                    else:
                        provider = get_provider(
                            str(src_path),
                            exclude=cfg.get("exclude"),
                            include=cfg.get("include"),
                        )

                    summary = harvest(conn, src_path, provider=provider)

                    # Prune old snapshots (keep latest N per file)
                    retain = cfg.get("snapshot_retain", 10)
                    conn.execute(
                        "DELETE FROM artifact_snapshots WHERE id NOT IN ("
                        "  SELECT id FROM ("
                        "    SELECT id, ROW_NUMBER() OVER ("
                        "      PARTITION BY file_metadata_id ORDER BY snapshot_at DESC"
                        "    ) AS rn FROM artifact_snapshots"
                        "  ) WHERE rn <= ?"
                        ")", (retain,))
                    conn.commit()

                    auto_report(conn, src_path)
                    conn.close()
                    results.append(f"{src_path.name}: {summary['files_total']} files "
                                   f"({summary['files_new']} new, "
                                   f"{summary['files_updated']} updated)")

                # Send scan-complete notification if configured
                td = state["target_dir"]
                if td:
                    ncfg = load_config(td)
                    if "scan_complete" in ncfg.get("notify_on", []):
                        _send_notification(
                            ncfg,
                            "Signal Provenance: Scan Complete",
                            "Scan completed for all sources.\n\n" + "\n".join(results),
                        )

                self._json(200, {
                    "ok": True,
                    "refresh": True,
                    "message": " | ".join(results),
                })
            except Exception as e:
                self._json(500, {"ok": False, "error": str(e)})

        def _handle_export_pdf(self):
            td = state["target_dir"]
            if td is None:
                self._json(400, {"ok": False, "error": "Not configured"})
                return
            try:
                from signal_provenance.export import export_pdf
                conn = get_connection(td)
                report_dir = td / ".signal-provenance" / "reports"
                report_dir.mkdir(parents=True, exist_ok=True)
                stamp = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H%M%S")
                out = report_dir / f"provenance-{stamp}.pdf"
                export_pdf(conn, td, out)
                conn.close()
                self._json(200, {
                    "ok": True,
                    "download": str(out),
                    "message": f"PDF generated: {out.name}",
                })
            except Exception as e:
                self._json(500, {"ok": False, "error": str(e)})

        def _handle_export_html(self):
            td = state["target_dir"]
            if td is None:
                self._json(400, {"ok": False, "error": "Not configured"})
                return
            try:
                from signal_provenance.export import export_dashboard
                report_dir = td / ".signal-provenance" / "reports"
                report_dir.mkdir(parents=True, exist_ok=True)
                stamp = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H%M%S")
                out = report_dir / f"provenance-{stamp}.html"
                conn = get_connection(td)
                export_dashboard(conn, td, out)
                conn.close()
                self._json(200, {
                    "ok": True,
                    "download": str(out),
                    "message": f"HTML report generated: {out.name}",
                })
            except Exception as e:
                self._json(500, {"ok": False, "error": str(e)})

        def _json(self, code, data):
            body = json.dumps(data).encode()
            self._respond(code, "application/json", body)

        def _respond(self, code, content_type, body, extra=None):
            self.send_response(code)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(body)))
            if extra:
                for k, v in extra.items():
                    self.send_header(k, v)
            self.end_headers()
            self.wfile.write(body)

    server = HTTPServer(("127.0.0.1", port), Handler)
    url = f"http://localhost:{port}"
    return server, url


def serve_dashboard(target_dir: Path | None = None, port: int = 9111,
                    open_browser: bool = True) -> None:
    """Serve the dashboard with live action endpoints (terminal mode).

    If target_dir is None, serves a setup page where the user can
    enter an activation code and folder path to initialize provenance.
    """
    server, url = create_dashboard_server(target_dir, port)
    print(f"Dashboard live at {url}")
    print("Press Ctrl+C to stop")

    if open_browser:
        threading.Timer(0.5, lambda: webbrowser.open(url)).start()

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nDashboard stopped.")
        server.server_close()


_DASHBOARD_TEMPLATE = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Signal Provenance Dashboard</title>
<style>
:root {
    --bg: #0d1117;
    --surface: #161b22;
    --border: #30363d;
    --text: #e6edf3;
    --text-muted: #8b949e;
    --accent: #58a6ff;
    --green: #3fb950;
    --red: #f85149;
    --yellow: #d29922;
    --orange: #db6d28;
}
* { margin: 0; padding: 0; box-sizing: border-box; }
body {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif;
    background: var(--bg);
    color: var(--text);
    line-height: 1.5;
    min-height: 100vh;
}
a { color: var(--accent); text-decoration: none; }

/* Layout */
.header {
    background: var(--surface);
    border-bottom: 1px solid var(--border);
    padding: 16px 24px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 12px;
}
.header-left { display: flex; align-items: center; gap: 16px; }
.header-left h1 { font-size: 18px; font-weight: 600; }
.header-left h1 span { color: var(--text-muted); font-weight: 400; }
.deployment-name { font-size: 14px; color: var(--accent); font-weight: 500; padding-left: 16px; border-left: 1px solid var(--border); }
.header-actions { display: flex; gap: 8px; align-items: center; }
.header-meta { font-size: 12px; color: var(--text-muted); text-align: right; }

.tabs {
    background: var(--surface);
    border-bottom: 1px solid var(--border);
    padding: 0 24px;
    display: flex;
    gap: 0;
}
.tab {
    padding: 10px 16px;
    font-size: 13px;
    color: var(--text-muted);
    cursor: pointer;
    border-bottom: 2px solid transparent;
    transition: all 0.15s;
}
.tab:hover { color: var(--text); }
.tab.active { color: var(--text); border-bottom-color: var(--accent); }

.container { max-width: 1400px; margin: 0 auto; padding: 20px 24px; }
.panel { display: none; }
.panel.active { display: block; }

/* Status banner */
.status-banner {
    border: 1px solid var(--border);
    border-radius: 8px;
    padding: 20px 24px;
    margin-bottom: 24px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 16px;
}
.status-banner.valid { border-color: rgba(63, 185, 80, 0.4); background: rgba(63, 185, 80, 0.06); }
.status-banner.broken { border-color: rgba(248, 81, 73, 0.4); background: rgba(248, 81, 73, 0.06); }
.status-headline { font-size: 16px; font-weight: 600; }
.status-headline .status-word { font-weight: 700; }
.status-headline .status-word.valid { color: var(--green); }
.status-headline .status-word.broken { color: var(--red); }
.status-details { display: flex; gap: 24px; flex-wrap: wrap; }
.status-stat { text-align: center; }
.status-stat-value { font-size: 22px; font-weight: 700; color: var(--text); }
.status-stat-label { font-size: 11px; color: var(--text-muted); text-transform: uppercase; letter-spacing: 0.5px; }

/* Welcome modal */
.modal-overlay {
    display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%;
    background: rgba(0,0,0,0.7); z-index: 9999; align-items: center; justify-content: center;
}
.modal-overlay.show { display: flex; }
.modal-box {
    background: var(--surface); border: 1px solid var(--border); border-radius: 12px;
    padding: 40px; max-width: 520px; width: 90%; text-align: center;
}
.modal-box h2 { margin: 0 0 8px; font-size: 22px; color: var(--text); }
.modal-box .modal-sub { color: var(--text-muted); margin-bottom: 24px; }
.modal-checks { text-align: left; margin: 0 auto 28px; max-width: 380px; }
.modal-checks div { display: flex; align-items: flex-start; gap: 10px; margin-bottom: 12px; font-size: 14px; color: var(--text); }
.modal-checks .check { color: var(--green); font-weight: bold; flex-shrink: 0; }
.modal-actions { display: flex; flex-direction: column; gap: 10px; }
.modal-actions button {
    padding: 10px 16px; border-radius: 6px; border: 1px solid var(--border);
    background: var(--surface); color: var(--text); font-size: 14px; cursor: pointer;
}
.modal-actions button:hover { background: var(--border); }
.modal-actions button.primary { background: var(--green); color: #fff; border-color: var(--green); font-weight: 600; }
.modal-actions button.primary:hover { opacity: 0.9; }
.modal-dismiss { margin-top: 16px; font-size: 12px; color: var(--text-muted); cursor: pointer; text-decoration: underline; }
.modal-dismiss:hover { color: var(--text); }

/* Cards */
.cards { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; margin-bottom: 24px; }
.card {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 8px;
    padding: 16px;
}
.card-label { font-size: 12px; color: var(--text-muted); text-transform: uppercase; letter-spacing: 0.5px; }
.card-value { font-size: 28px; font-weight: 600; margin-top: 4px; }
.card-value.valid { color: var(--green); }
.card-value.broken { color: var(--red); }

/* Compliance mini strip on overview */
.comp-strip {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
    gap: 8px;
    margin-bottom: 24px;
}
.comp-mini {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 6px;
    padding: 10px 12px;
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 12px;
}
.comp-dot {
    width: 8px;
    height: 8px;
    border-radius: 50%;
    flex-shrink: 0;
}
.comp-dot.covered { background: var(--green); }
.comp-dot.no_data { background: var(--text-muted); }
.comp-mini-name { font-weight: 500; }

/* Tables */
.table-wrap {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 8px;
    overflow: hidden;
    margin-bottom: 24px;
}
.table-header {
    padding: 12px 16px;
    border-bottom: 1px solid var(--border);
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 8px;
}
.table-header h3 { font-size: 14px; font-weight: 600; }
.search-input {
    background: var(--bg);
    border: 1px solid var(--border);
    border-radius: 6px;
    padding: 6px 12px;
    font-size: 12px;
    color: var(--text);
    outline: none;
    width: 220px;
}
.search-input:focus { border-color: var(--accent); }
table { width: 100%; border-collapse: collapse; font-size: 13px; }
th {
    text-align: left;
    padding: 8px 16px;
    background: var(--bg);
    color: var(--text-muted);
    font-weight: 500;
    font-size: 12px;
    border-bottom: 1px solid var(--border);
    cursor: pointer;
    user-select: none;
    white-space: nowrap;
}
th:hover { color: var(--text); }
th .sort-arrow { margin-left: 4px; font-size: 10px; }
td {
    padding: 8px 16px;
    border-bottom: 1px solid var(--border);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    max-width: 400px;
}
td.path { font-family: "SFMono-Regular", Consolas, monospace; font-size: 12px; }
td.hash { font-family: "SFMono-Regular", Consolas, monospace; font-size: 11px; color: var(--text-muted); }
tr:hover td { background: rgba(88, 166, 255, 0.04); }
tr.file-row { cursor: pointer; }
tr.file-row:hover td { background: rgba(88, 166, 255, 0.08); }

/* Role badges */
.badge {
    display: inline-block;
    padding: 2px 8px;
    border-radius: 12px;
    font-size: 11px;
    font-weight: 500;
}
.badge-code { background: rgba(88, 166, 255, 0.15); color: var(--accent); }
.badge-config { background: rgba(210, 153, 34, 0.15); color: var(--yellow); }
.badge-doc { background: rgba(63, 185, 80, 0.15); color: var(--green); }
.badge-test { background: rgba(219, 109, 40, 0.15); color: var(--orange); }
.badge-data { background: rgba(248, 81, 73, 0.15); color: var(--red); }
.badge-other { background: rgba(139, 148, 158, 0.15); color: var(--text-muted); }
.badge-template { background: rgba(188, 140, 255, 0.15); color: #bc8cff; }
.badge-style { background: rgba(255, 123, 114, 0.15); color: #ff7b72; }
.badge-document { background: rgba(63, 185, 80, 0.15); color: var(--green); }

/* Event type badges */
.event-created { color: var(--green); }
.event-modified { color: var(--yellow); }
.event-deleted { color: var(--red); }

/* Breakdown bars */
.bar-row { display: flex; align-items: center; gap: 8px; margin-bottom: 6px; }
.bar-label { font-size: 12px; width: 100px; text-align: right; color: var(--text-muted); }
.bar-track { flex: 1; height: 20px; background: var(--bg); border-radius: 4px; overflow: hidden; }
.bar-fill { height: 100%; border-radius: 4px; transition: width 0.3s; min-width: 2px; }
.bar-count { font-size: 12px; width: 50px; color: var(--text-muted); }

/* Chain detail */
.chain-detail {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 8px;
    padding: 20px;
    margin-bottom: 24px;
}
.chain-row { display: flex; gap: 12px; margin-bottom: 8px; font-size: 13px; }
.chain-label { color: var(--text-muted); min-width: 140px; }
.chain-value { font-family: "SFMono-Regular", Consolas, monospace; font-size: 12px; word-break: break-all; }

/* Methodology */
.methodology {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 8px;
    padding: 20px;
    margin-bottom: 24px;
}
.methodology h3 { font-size: 14px; font-weight: 600; margin-bottom: 12px; }
.methodology p { font-size: 13px; color: var(--text-muted); margin-bottom: 10px; line-height: 1.6; }
.methodology code {
    background: var(--bg);
    padding: 2px 6px;
    border-radius: 4px;
    font-size: 12px;
    color: var(--accent);
}

/* Pagination */
.pagination {
    padding: 12px 16px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    border-top: 1px solid var(--border);
    font-size: 12px;
    color: var(--text-muted);
}
.page-btn {
    background: var(--bg);
    border: 1px solid var(--border);
    border-radius: 6px;
    padding: 4px 12px;
    color: var(--text);
    cursor: pointer;
    font-size: 12px;
}
.page-btn:hover { border-color: var(--accent); }
.page-btn:disabled { opacity: 0.4; cursor: default; }

/* Compliance cards */
.comp-card {
    background: var(--bg);
    border: 1px solid var(--border);
    border-radius: 8px;
    padding: 16px;
    position: relative;
    overflow: hidden;
}
.comp-card::before {
    content: "";
    position: absolute;
    top: 0; left: 0;
    width: 4px;
    height: 100%;
}
.comp-card.covered::before { background: var(--green); }
.comp-card.no_data::before { background: var(--text-muted); }
.comp-framework { font-size: 14px; font-weight: 600; margin-bottom: 4px; }
.comp-desc { font-size: 12px; color: var(--text-muted); margin-bottom: 10px; }
.comp-sections { display: flex; flex-wrap: wrap; gap: 6px; }
.comp-section {
    display: inline-block;
    padding: 2px 8px;
    border-radius: 4px;
    font-size: 11px;
    font-family: "SFMono-Regular", Consolas, monospace;
    background: rgba(88, 166, 255, 0.1);
    color: var(--accent);
}
.comp-status {
    position: absolute;
    top: 16px;
    right: 16px;
    font-size: 11px;
    font-weight: 600;
    text-transform: uppercase;
}
.comp-status.covered { color: var(--green); }
.comp-status.no_data { color: var(--text-muted); }

/* Upsell */
.upsell {
    background: var(--surface);
    border: 1px solid rgba(210, 153, 34, 0.3);
    border-radius: 8px;
    padding: 20px 24px;
    margin-top: 24px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 16px;
}
.upsell-text { max-width: 600px; }
.upsell-text strong { color: var(--yellow); font-size: 14px; }
.upsell-text p { font-size: 13px; color: var(--text-muted); margin-top: 4px; }

/* Action buttons */
.action-btn {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 7px 14px;
    border-radius: 6px;
    font-size: 12px;
    font-weight: 600;
    cursor: pointer;
    border: 1px solid var(--border);
    text-decoration: none;
    transition: all 0.15s;
}
.harvest-btn { background: rgba(63, 185, 80, 0.12); color: var(--green); border-color: rgba(63, 185, 80, 0.3); }
.harvest-btn:hover { background: rgba(63, 185, 80, 0.22); }
.pdf-btn { background: rgba(88, 166, 255, 0.12); color: var(--accent); border-color: rgba(88, 166, 255, 0.3); }
.pdf-btn:hover { background: rgba(88, 166, 255, 0.22); }
.signal-btn { background: rgba(210, 153, 34, 0.15); color: var(--yellow); border-color: rgba(210, 153, 34, 0.3); padding: 9px 20px; font-size: 13px; }
.signal-btn:hover { background: rgba(210, 153, 34, 0.25); }

/* Toast */
.toast {
    position: fixed;
    bottom: 24px;
    left: 50%;
    transform: translateX(-50%) translateY(80px);
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 8px;
    padding: 12px 20px;
    font-size: 13px;
    color: var(--text);
    box-shadow: 0 8px 24px rgba(0,0,0,0.4);
    opacity: 0;
    transition: all 0.3s ease;
    z-index: 1000;
    pointer-events: none;
}
.toast.show { opacity: 1; transform: translateX(-50%) translateY(0); }
.toast code { background: var(--bg); padding: 2px 6px; border-radius: 4px; font-size: 12px; }

/* Footer */
.footer {
    text-align: center;
    padding: 20px;
    font-size: 11px;
    color: var(--text-muted);
    border-top: 1px solid var(--border);
    margin-top: 40px;
}
</style>
</head>
<body>

<div class="header">
    <div class="header-left">
        <h1>Signal Provenance <span>Dashboard</span></h1>
        <div class="deployment-name" id="deployment-name"></div>
    </div>
    <div class="header-actions">
        <button class="action-btn harvest-btn" id="btn-harvest">Scan Now</button>
        <button class="action-btn pdf-btn" id="btn-pdf">Export Compliance Report</button>
        <button class="action-btn" id="btn-share" style="background:var(--surface);border:1px solid var(--border);color:var(--text);">Share Report</button>
    </div>
</div>

<div class="tabs">
    <div class="tab active" data-panel="overview">Overview</div>
    <div class="tab" data-panel="files">Files</div>
    <div class="tab" data-panel="changes">Changes</div>
    <div class="tab" data-panel="harvests">Scan History</div>
    <div class="tab" data-panel="compliance">Compliance</div>
    <div class="tab" data-panel="chain">Verification</div>
    <div class="tab" data-panel="sources">Sources</div>
</div>

<div class="container">

<!-- Overview Panel -->
<div class="panel active" id="panel-overview">

    <!-- Status banner -->
    <div class="status-banner" id="status-banner">
        <div class="status-headline" id="status-headline"></div>
        <div class="status-details">
            <div class="status-stat">
                <div class="status-stat-value" id="stat-frameworks"></div>
                <div class="status-stat-label">Frameworks</div>
            </div>
            <div class="status-stat">
                <div class="status-stat-value" id="stat-files"></div>
                <div class="status-stat-label">Files</div>
            </div>
            <div class="status-stat">
                <div class="status-stat-value" id="stat-days"></div>
                <div class="status-stat-label">Days Monitored</div>
            </div>
            <div class="status-stat">
                <div class="status-stat-value" id="stat-chain"></div>
                <div class="status-stat-label">Verified Events</div>
            </div>
        </div>
    </div>

    <!-- Compliance strip -->
    <div class="comp-strip" id="comp-strip"></div>

    <div class="cards">
        <div class="card">
            <div class="card-label">Total Events</div>
            <div class="card-value" id="card-events"></div>
        </div>
        <div class="card">
            <div class="card-label">Total Size</div>
            <div class="card-value" id="card-size"></div>
        </div>
        <div class="card">
            <div class="card-label">First Event</div>
            <div class="card-value" style="font-size: 16px;" id="card-first"></div>
        </div>
        <div class="card">
            <div class="card-label">Last Generated</div>
            <div class="card-value" style="font-size: 16px;" id="card-generated"></div>
        </div>
    </div>

    <!-- Coverage summary -->
    <div class="table-wrap" id="coverage-wrap" style="display:none;">
        <div class="table-header"><h3>Last Scan Coverage</h3></div>
        <div style="padding:16px;display:flex;gap:24px;flex-wrap:wrap;align-items:center;">
            <div style="flex:1;min-width:200px;">
                <div style="display:flex;justify-content:space-between;margin-bottom:6px;">
                    <span style="font-size:13px;">Files verified</span>
                    <span style="font-size:13px;font-weight:600;" id="cov-witnessed"></span>
                </div>
                <div style="height:8px;background:var(--bg);border-radius:4px;overflow:hidden;">
                    <div id="cov-bar" style="height:100%;background:var(--green);border-radius:4px;transition:width 0.3s;"></div>
                </div>
                <div style="display:flex;justify-content:space-between;margin-top:6px;">
                    <span style="font-size:11px;color:var(--text-muted);" id="cov-detail"></span>
                    <span style="font-size:11px;color:var(--text-muted);" id="cov-skipped"></span>
                </div>
            </div>
        </div>
    </div>

    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 24px;">
        <div class="table-wrap">
            <div class="table-header"><h3>File Roles</h3></div>
            <div id="role-breakdown" style="padding: 16px;"></div>
        </div>
        <div class="table-wrap">
            <div class="table-header"><h3>Event Types</h3></div>
            <div id="event-breakdown" style="padding: 16px;"></div>
        </div>
    </div>

    <div class="table-wrap">
        <div class="table-header"><h3>Recent Activity</h3></div>
        <table>
            <thead><tr>
                <th>Time</th><th>Event</th><th>File</th><th>Hash</th><th>Actor</th>
            </tr></thead>
            <tbody id="recent-tbody"></tbody>
        </table>
    </div>

    <!-- Upsell on overview -->
    <div class="upsell">
        <div class="upsell-text">
            <strong>Go beyond tracking.</strong>
            <p>Provenance proves what happened. Signal shows you what it means -- classification, enrichment, gap analysis, operational intelligence built on this same chain.</p>
        </div>
        <a class="action-btn signal-btn" href="https://echology.io/signal" target="_blank" rel="noopener">Get Full Signal</a>
    </div>
</div>

<!-- Files Panel -->
<div class="panel" id="panel-files">
    <div class="table-wrap">
        <div class="table-header">
            <h3>File Inventory (<span id="file-count-label"></span>)</h3>
            <input type="text" class="search-input" id="file-search" placeholder="Filter files...">
        </div>
        <table>
            <thead><tr>
                <th data-sort="path">Path <span class="sort-arrow"></span></th>
                <th data-sort="role">Role <span class="sort-arrow"></span></th>
                <th data-sort="size">Size <span class="sort-arrow"></span></th>
                <th data-sort="modified">Modified <span class="sort-arrow"></span></th>
                <th>Hash</th>
            </tr></thead>
            <tbody id="files-tbody"></tbody>
        </table>
        <div class="pagination" id="files-pagination"></div>
    </div>
</div>

<!-- Changes Panel -->
<div class="panel" id="panel-changes">
    <div class="table-wrap">
        <div class="table-header">
            <h3>Change History (<span id="change-count-label"></span>)</h3>
            <input type="text" class="search-input" id="change-search" placeholder="Filter changes...">
        </div>
        <table>
            <thead><tr>
                <th data-sort="seq"># <span class="sort-arrow"></span></th>
                <th data-sort="time">Time <span class="sort-arrow"></span></th>
                <th data-sort="type">Event <span class="sort-arrow"></span></th>
                <th data-sort="file">File <span class="sort-arrow"></span></th>
                <th>Hash</th>
                <th data-sort="actor">Actor <span class="sort-arrow"></span></th>
            </tr></thead>
            <tbody id="changes-tbody"></tbody>
        </table>
        <div class="pagination" id="changes-pagination"></div>
    </div>
</div>

<!-- Harvests Panel -->
<div class="panel" id="panel-harvests">
    <div class="table-wrap">
        <div class="table-header"><h3>Scan History</h3></div>
        <table>
            <thead><tr>
                <th>ID</th><th>Started</th><th>Total</th>
                <th>New</th><th>Updated</th><th>Deleted</th><th>Skipped</th><th>Duration</th>
            </tr></thead>
            <tbody id="harvests-tbody"></tbody>
        </table>
    </div>
</div>

<!-- Compliance Panel -->
<div class="panel" id="panel-compliance">
    <div class="cards" style="grid-template-columns: repeat(3, 1fr); margin-bottom: 24px;">
        <div class="card">
            <div class="card-label">Frameworks Covered</div>
            <div class="card-value" id="comp-count"></div>
        </div>
        <div class="card">
            <div class="card-label">Chain Integrity</div>
            <div class="card-value" id="comp-chain"></div>
        </div>
        <div class="card">
            <div class="card-label">Evidence Basis</div>
            <div class="card-value" style="font-size: 16px;">SHA-256 hash chain</div>
        </div>
    </div>
    <div class="table-wrap">
        <div class="table-header"><h3>Regulatory Coverage</h3></div>
        <div id="compliance-grid" style="padding: 16px; display: grid; grid-template-columns: repeat(auto-fit, minmax(380px, 1fr)); gap: 16px;"></div>
    </div>

    <!-- Upsell on compliance -->
    <div class="upsell">
        <div class="upsell-text">
            <strong>From audit trail to operational intelligence.</strong>
            <p>Signal adds automated classification, semantic decomposition, and gap analysis on top of this provenance chain. Same data. Deeper insight.</p>
        </div>
        <a class="action-btn signal-btn" href="https://echology.io/signal" target="_blank" rel="noopener">Get Full Signal</a>
    </div>
</div>

<!-- Chain Panel -->
<div class="panel" id="panel-chain">
    <div class="cards" style="grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));">
        <div class="card">
            <div class="card-label">Verification</div>
            <div class="card-value" id="chain-status"></div>
        </div>
        <div class="card">
            <div class="card-label">Total Links</div>
            <div class="card-value" id="chain-links"></div>
        </div>
        <div class="card">
            <div class="card-label">Days of Coverage</div>
            <div class="card-value" id="chain-days"></div>
        </div>
        <div class="card">
            <div class="card-label">Algorithm</div>
            <div class="card-value" style="font-size: 20px;">SHA-256</div>
        </div>
    </div>
    <div class="chain-detail">
        <div class="chain-row">
            <div class="chain-label">First Verification Point</div>
            <div class="chain-value" id="chain-genesis"></div>
        </div>
        <div class="chain-row">
            <div class="chain-label">Latest Verification Point</div>
            <div class="chain-value" id="chain-terminal"></div>
        </div>
        <div class="chain-row">
            <div class="chain-label">First Event</div>
            <div class="chain-value" id="chain-first-event"></div>
        </div>
        <div class="chain-row">
            <div class="chain-label">Target Directory</div>
            <div class="chain-value" id="chain-target"></div>
        </div>
        <div class="chain-row">
            <div class="chain-label">Timestamp Source</div>
            <div class="chain-value">System clock (local). No external timestamping authority.</div>
        </div>
        <div class="chain-row">
            <div class="chain-label">Actor Identity</div>
            <div class="chain-value">OS process identity. Authenticated via local system credentials.</div>
        </div>
    </div>

    <div class="methodology">
        <h3>Verification Methodology</h3>
        <p>Each ledger entry contains a SHA-256 hash computed from the entry's content concatenated with the previous entry's hash. This creates a tamper-evident chain: modifying any record invalidates all subsequent hashes. The genesis entry uses a fixed seed hash.</p>
        <p>Verification recomputes every hash from genesis and compares against stored values. A VALID result means zero divergence across the entire chain. A BROKEN result identifies the exact sequence number where the chain diverges.</p>
        <h3>Independent Verification</h3>
        <p>You do not need to trust this dashboard. To verify independently, run:</p>
        <p><code>signal-provenance verify</code></p>
        <p>This recomputes the full chain from the raw ledger database. The algorithm is deterministic -- the same input always produces the same result, on any machine, at any time. The verification code is open for inspection in the installed package.</p>
    </div>
</div>

<!-- Sources Panel -->
<div class="panel" id="panel-sources">
    <div class="table-wrap">
        <div class="table-header">
            <h3>Configured Sources</h3>
            <span style="font-size:12px;color:var(--text-muted);" id="src-count"></span>
        </div>
        <table>
            <thead><tr>
                <th>Status</th><th>Type</th><th>Path</th>
            </tr></thead>
            <tbody id="sources-tbody"></tbody>
        </table>
    </div>

    <div class="table-wrap" style="margin-top:24px;">
        <div class="table-header">
            <h3>Scan Settings</h3>
            <span style="font-size:12px;color:var(--text-muted);">Applies to the active source</span>
        </div>
        <div style="padding:24px;max-width:560px;">
            <div style="display:flex;gap:24px;flex-wrap:wrap;">
                <div style="flex:1;min-width:200px;">
                    <label style="font-size:11px;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.8px;display:block;margin-bottom:6px;font-weight:600;">Scan Interval (minutes)</label>
                    <input type="number" id="cfg-interval" min="1" max="1440" value="60" style="width:100%;padding:10px 14px;background:var(--bg);border:1px solid var(--border);border-radius:6px;color:var(--text);font-size:14px;outline:none;">
                    <p style="font-size:11px;color:var(--text-muted);margin-top:4px;">How often to re-scan when using watch mode</p>
                </div>
                <div style="flex:1;min-width:200px;">
                    <label style="font-size:11px;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.8px;display:block;margin-bottom:6px;font-weight:600;">Snapshot Retention</label>
                    <input type="number" id="cfg-retain" min="1" max="100" value="10" style="width:100%;padding:10px 14px;background:var(--bg);border:1px solid var(--border);border-radius:6px;color:var(--text);font-size:14px;outline:none;">
                    <p style="font-size:11px;color:var(--text-muted);margin-top:4px;">Snapshots to keep per file (older ones are pruned on harvest)</p>
                </div>
            </div>
            <div style="height:16px;"></div>
            <div style="display:flex;gap:12px;align-items:center;flex-wrap:wrap;">
                <button class="action-btn pdf-btn" id="btn-save-settings" style="padding:10px 20px;">Save Settings</button>
                <button class="action-btn harvest-btn" id="btn-schedule-cron" style="padding:10px 20px;">Schedule Automatic Scanning</button>
                <span id="settings-msg" style="font-size:13px;display:none;"></span>
            </div>
        </div>
    </div>

    <div class="table-wrap" style="margin-top:24px;">
        <div class="table-header">
            <h3>Add Local Source</h3>
            <span style="font-size:12px;color:var(--text-muted);">Watch another directory (including synced Google Drive, OneDrive, Dropbox)</span>
        </div>
        <div style="padding:24px;max-width:560px;">
            <label style="font-size:11px;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.8px;display:block;margin-bottom:6px;font-weight:600;">Folder Path</label>
            <div style="display:flex;gap:8px;">
                <input id="src-local-folder" placeholder="/path/to/another/project" autocomplete="off" spellcheck="false" style="flex:1;padding:10px 14px;background:var(--bg);border:1px solid var(--border);border-radius:6px;color:var(--text);font-size:14px;outline:none;">
                <button type="button" id="src-local-browse" style="padding:10px 16px;background:var(--bg);color:var(--text);border:1px solid var(--border);border-radius:6px;font-size:13px;cursor:pointer;white-space:nowrap;">Browse</button>
            </div>
            <div style="height:16px;"></div>
            <button class="action-btn harvest-btn" id="btn-add-local" style="width:100%;justify-content:center;padding:12px;font-size:14px;">Add &amp; Scan</button>
            <div id="src-local-msg" style="font-size:13px;margin-top:14px;padding:10px 14px;border-radius:6px;display:none;"></div>
        </div>
    </div>

    <div class="table-wrap" style="margin-top:24px;">
        <div class="table-header">
            <h3>Add Cloud Source</h3>
            <span style="font-size:12px;color:var(--text-muted);">Connect a cloud storage provider for enterprise monitoring</span>
        </div>
        <div style="padding:24px;max-width:560px;">
            <label style="font-size:11px;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.8px;display:block;margin-bottom:6px;font-weight:600;">Provider</label>
            <select id="src-provider" style="width:100%;padding:10px 14px;background:var(--bg);border:1px solid var(--border);border-radius:6px;color:var(--text);font-size:14px;margin-bottom:16px;outline:none;-webkit-appearance:none;appearance:none;">
                <option value="sharepoint">SharePoint / OneDrive for Business</option>
                <option value="gdrive">Google Drive (Service Account)</option>
                <option value="s3">AWS S3</option>
            </select>

            <div id="src-fields-sharepoint">
                <label style="font-size:11px;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.8px;display:block;margin-bottom:6px;font-weight:600;">SharePoint Site Name</label>
                <input id="src-sp-site" placeholder="MySiteName" autocomplete="off" spellcheck="false" style="width:100%;padding:10px 14px;background:var(--bg);border:1px solid var(--border);border-radius:6px;color:var(--text);font-size:14px;margin-bottom:16px;outline:none;">
                <label style="font-size:11px;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.8px;display:block;margin-bottom:6px;font-weight:600;">Document Library <span style="text-transform:none;letter-spacing:0;font-weight:400;">(default: Documents)</span></label>
                <input id="src-sp-library" placeholder="Documents" autocomplete="off" spellcheck="false" style="width:100%;padding:10px 14px;background:var(--bg);border:1px solid var(--border);border-radius:6px;color:var(--text);font-size:14px;margin-bottom:16px;outline:none;">
                <label style="font-size:11px;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.8px;display:block;margin-bottom:6px;font-weight:600;">Azure AD Tenant ID</label>
                <input id="src-sp-tenant" placeholder="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx" autocomplete="off" spellcheck="false" style="width:100%;padding:10px 14px;background:var(--bg);border:1px solid var(--border);border-radius:6px;color:var(--text);font-size:14px;margin-bottom:16px;outline:none;">
                <label style="font-size:11px;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.8px;display:block;margin-bottom:6px;font-weight:600;">App Registration Client ID</label>
                <input id="src-sp-client-id" placeholder="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx" autocomplete="off" spellcheck="false" style="width:100%;padding:10px 14px;background:var(--bg);border:1px solid var(--border);border-radius:6px;color:var(--text);font-size:14px;margin-bottom:16px;outline:none;">
                <label style="font-size:11px;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.8px;display:block;margin-bottom:6px;font-weight:600;">App Registration Client Secret</label>
                <input id="src-sp-client-secret" type="password" placeholder="Client secret" autocomplete="off" spellcheck="false" style="width:100%;padding:10px 14px;background:var(--bg);border:1px solid var(--border);border-radius:6px;color:var(--text);font-size:14px;margin-bottom:16px;outline:none;">
            </div>

            <div id="src-fields-gdrive" style="display:none;">
                <label style="font-size:11px;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.8px;display:block;margin-bottom:6px;font-weight:600;">Google Drive Folder ID</label>
                <input id="src-gd-folder-id" placeholder="1A2B3C4D5E6F..." autocomplete="off" spellcheck="false" style="width:100%;padding:10px 14px;background:var(--bg);border:1px solid var(--border);border-radius:6px;color:var(--text);font-size:14px;margin-bottom:16px;outline:none;">
                <label style="font-size:11px;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.8px;display:block;margin-bottom:6px;font-weight:600;">Service Account JSON Key Path</label>
                <input id="src-gd-creds" placeholder="/path/to/service-account.json" autocomplete="off" spellcheck="false" style="width:100%;padding:10px 14px;background:var(--bg);border:1px solid var(--border);border-radius:6px;color:var(--text);font-size:14px;margin-bottom:16px;outline:none;">
            </div>

            <div id="src-fields-s3" style="display:none;">
                <label style="font-size:11px;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.8px;display:block;margin-bottom:6px;font-weight:600;">S3 Bucket / Prefix</label>
                <input id="src-s3-target" placeholder="my-bucket/optional/prefix" autocomplete="off" spellcheck="false" style="width:100%;padding:10px 14px;background:var(--bg);border:1px solid var(--border);border-radius:6px;color:var(--text);font-size:14px;margin-bottom:16px;outline:none;">
                <p style="font-size:11px;color:var(--text-muted);margin-top:-8px;margin-bottom:16px;">Uses your AWS credentials (~/.aws/credentials or environment variables)</p>
            </div>

            <button class="action-btn harvest-btn" id="btn-add-source" style="width:100%;justify-content:center;padding:12px;font-size:14px;">Connect &amp; Scan</button>
            <div id="src-msg" style="font-size:13px;margin-top:14px;padding:10px 14px;border-radius:6px;display:none;"></div>
        </div>
    </div>

    <!-- Notifications -->
    <div class="card" style="margin-top:20px;">
        <div style="padding:16px 24px;border-bottom:1px solid var(--border);display:flex;justify-content:space-between;align-items:center;">
            <h3>Email Notifications</h3>
            <span style="font-size:12px;color:var(--text-muted);">Get notified when scans complete or issues are detected</span>
        </div>
        <div style="padding:24px;max-width:560px;">
            <label style="font-size:11px;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.8px;display:block;margin-bottom:6px;font-weight:600;">Email Address</label>
            <input id="notify-email" placeholder="you@company.com" autocomplete="off" style="width:100%;padding:10px 14px;background:var(--bg);border:1px solid var(--border);border-radius:6px;color:var(--text);font-size:14px;margin-bottom:16px;outline:none;">

            <label style="font-size:11px;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.8px;display:block;margin-bottom:10px;font-weight:600;">Notify On</label>
            <div style="margin-bottom:16px;">
                <label style="display:flex;align-items:center;gap:8px;margin-bottom:8px;font-size:13px;color:var(--text);cursor:pointer;">
                    <input type="checkbox" id="notify-scan-complete" value="scan_complete"> Scan completed
                </label>
                <label style="display:flex;align-items:center;gap:8px;margin-bottom:8px;font-size:13px;color:var(--text);cursor:pointer;">
                    <input type="checkbox" id="notify-chain-break" value="chain_break"> Verification gap detected
                </label>
                <label style="display:flex;align-items:center;gap:8px;font-size:13px;color:var(--text);cursor:pointer;">
                    <input type="checkbox" id="notify-weekly-digest" value="weekly_digest"> Weekly digest (Monday)
                </label>
            </div>

            <details style="margin-bottom:16px;">
                <summary style="font-size:12px;color:var(--text-muted);cursor:pointer;margin-bottom:12px;">SMTP Settings (optional -- defaults to localhost)</summary>
                <label style="font-size:11px;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.8px;display:block;margin-bottom:6px;font-weight:600;">SMTP Host</label>
                <input id="smtp-host" placeholder="smtp.gmail.com" autocomplete="off" style="width:100%;padding:10px 14px;background:var(--bg);border:1px solid var(--border);border-radius:6px;color:var(--text);font-size:14px;margin-bottom:12px;outline:none;">
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px;">
                    <div>
                        <label style="font-size:11px;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.8px;display:block;margin-bottom:6px;font-weight:600;">Port</label>
                        <input id="smtp-port" type="number" value="587" style="width:100%;padding:10px 14px;background:var(--bg);border:1px solid var(--border);border-radius:6px;color:var(--text);font-size:14px;outline:none;">
                    </div>
                    <div>
                        <label style="font-size:11px;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.8px;display:block;margin-bottom:6px;font-weight:600;">From Address</label>
                        <input id="smtp-from" placeholder="alerts@company.com" autocomplete="off" style="width:100%;padding:10px 14px;background:var(--bg);border:1px solid var(--border);border-radius:6px;color:var(--text);font-size:14px;outline:none;">
                    </div>
                </div>
                <label style="font-size:11px;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.8px;display:block;margin-bottom:6px;font-weight:600;">Username</label>
                <input id="smtp-user" autocomplete="off" style="width:100%;padding:10px 14px;background:var(--bg);border:1px solid var(--border);border-radius:6px;color:var(--text);font-size:14px;margin-bottom:12px;outline:none;">
                <label style="font-size:11px;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.8px;display:block;margin-bottom:6px;font-weight:600;">Password</label>
                <input id="smtp-pass" type="password" autocomplete="off" style="width:100%;padding:10px 14px;background:var(--bg);border:1px solid var(--border);border-radius:6px;color:var(--text);font-size:14px;margin-bottom:12px;outline:none;">
            </details>

            <button class="action-btn" id="btn-save-notifications" style="width:100%;justify-content:center;padding:12px;font-size:14px;">Save Notification Settings</button>
            <div id="notify-msg" style="font-size:13px;margin-top:14px;padding:10px 14px;border-radius:6px;display:none;"></div>
        </div>
    </div>
</div>

</div><!-- container -->

<div id="toast" class="toast"></div>

<div class="footer">
    Signal Provenance v<span id="footer-version"></span> &middot; Generated <span id="footer-time"></span> &middot; Chain is local. Verification is deterministic. Data never leaves your machine.
</div>

<script>
const D = __DASHBOARD_DATA__;

// -- Actions --
const LIVE = location.protocol !== 'file:';

function showToast(html, duration) {
    const t = document.getElementById('toast');
    t.innerHTML = html;
    t.classList.add('show');
    setTimeout(() => { t.classList.remove('show'); }, duration || 3000);
}

function actionBtn(btn, endpoint, label) {
    btn.addEventListener('click', () => {
        if (!LIVE) {
            showToast('Run: <code>signal-provenance dashboard --live</code> for live actions', 4000);
            return;
        }
        const orig = btn.textContent;
        btn.textContent = label + '...';
        btn.disabled = true;
        fetch(endpoint, { method: 'POST' })
            .then(r => r.json())
            .then(data => {
                if (data.ok) {
                    showToast(data.message || 'Done');
                    if (data.refresh) setTimeout(() => location.reload(), 600);
                    if (data.download) {
                        const a = document.createElement('a');
                        a.href = '/api/download?path=' + encodeURIComponent(data.download);
                        a.download = data.download.split('/').pop();
                        a.click();
                    }
                } else {
                    showToast('<span style="color:var(--red)">' + (data.error || 'Failed') + '</span>');
                }
            })
            .catch(err => {
                showToast('<span style="color:var(--red)">Connection lost</span>');
            })
            .finally(() => { btn.textContent = orig; btn.disabled = false; });
    });
}

actionBtn(document.getElementById('btn-harvest'), '/api/harvest', 'Scanning');
actionBtn(document.getElementById('btn-pdf'), '/api/export-pdf', 'Generating');
actionBtn(document.getElementById('btn-share'), '/api/export-html', 'Generating');

// -- Init --
document.getElementById("deployment-name").textContent = D.deployment_name;
document.getElementById("footer-version").textContent = D.version;
document.getElementById("footer-time").textContent = D.generated;

// Status banner
const banner = document.getElementById("status-banner");
banner.className = "status-banner " + (D.chain_valid ? "valid" : "broken");
const coveredCount = (D.compliance || []).filter(c => c.status === "covered").length;
if (D.chain_valid) {
    document.getElementById("status-headline").innerHTML =
        'Your <strong>' + D.file_count + ' files</strong> have been continuously monitored for <strong>' +
        (D.chain_days || '<1') + ' day' + (D.chain_days !== 1 ? 's' : '') +
        '</strong>. No unauthorized changes detected. ' +
        '<span class="status-word valid">You can prove this to any auditor.</span>';
} else {
    document.getElementById("status-headline").innerHTML =
        '<span class="status-word broken">Warning:</span> A gap was detected in your file tracking. ' +
        'Some file changes may not be fully verified. ' +
        'Review the <strong>Verification</strong> tab for details.';
}
document.getElementById("stat-frameworks").textContent = coveredCount;
document.getElementById("stat-files").textContent = D.file_count;
document.getElementById("stat-days").textContent = D.chain_days || '<1';
document.getElementById("stat-chain").textContent = D.total_links;

// Compliance strip on overview
const strip = document.getElementById("comp-strip");
strip.innerHTML = (D.compliance || []).map(c =>
    '<div class="comp-mini">' +
    '<div class="comp-dot ' + c.status + '"></div>' +
    '<div class="comp-mini-name">' + c.framework + '</div></div>'
).join("");

// Overview cards
document.getElementById("card-events").textContent = D.event_count;
document.getElementById("card-size").textContent = D.total_size;
document.getElementById("card-first").textContent = D.first_event || 'No events';
document.getElementById("card-generated").textContent = D.generated;

// Chain panel
document.getElementById("chain-status").textContent = D.chain_valid ? "VALID" : "BROKEN";
document.getElementById("chain-status").className = "card-value " + (D.chain_valid ? "valid" : "broken");
document.getElementById("chain-links").textContent = D.total_links;
document.getElementById("chain-days").textContent = D.chain_days || '<1';
document.getElementById("chain-genesis").textContent = D.genesis_hash || "N/A";
document.getElementById("chain-terminal").textContent = D.terminal_hash || "N/A";
document.getElementById("chain-first-event").textContent = D.first_event || "N/A";
document.getElementById("chain-target").textContent = D.target;

// -- Tabs --
document.querySelectorAll(".tab").forEach(tab => {
    tab.addEventListener("click", () => {
        document.querySelectorAll(".tab").forEach(t => t.classList.remove("active"));
        document.querySelectorAll(".panel").forEach(p => p.classList.remove("active"));
        tab.classList.add("active");
        document.getElementById("panel-" + tab.dataset.panel).classList.add("active");
    });
});

// -- Breakdown bars --
function renderBreakdown(containerId, counts, colors) {
    const el = document.getElementById(containerId);
    const max = Math.max(...Object.values(counts), 1);
    const sorted = Object.entries(counts).sort((a, b) => b[1] - a[1]);
    el.innerHTML = sorted.map(([k, v]) => {
        const pct = (v / max * 100).toFixed(1);
        const color = colors[k] || "var(--text-muted)";
        return '<div class="bar-row">' +
            '<div class="bar-label">' + k + '</div>' +
            '<div class="bar-track"><div class="bar-fill" style="width:' + pct + '%;background:' + color + '"></div></div>' +
            '<div class="bar-count">' + v + '</div></div>';
    }).join("");
}

const roleColors = {
    code: "var(--accent)", config: "var(--yellow)", doc: "var(--green)",
    test: "var(--orange)", data: "var(--red)", other: "var(--text-muted)",
    template: "#bc8cff", style: "#ff7b72", document: "var(--green)",
};
const eventColors = {
    created: "var(--green)", modified: "var(--yellow)", deleted: "var(--red)",
    harvest_completed: "var(--accent)", chain_verified: "#bc8cff",
};
renderBreakdown("role-breakdown", D.role_counts, roleColors);
renderBreakdown("event-breakdown", D.event_types, eventColors);

// -- Coverage summary (last harvest) --
if (D.harvests && D.harvests.length > 0) {
    var lastH = D.harvests[0];
    var witnessed = lastH.files_total || 0;
    var skipped = lastH.files_skipped || 0;
    var total = witnessed + skipped;
    var pct = total > 0 ? (witnessed / total * 100) : 100;
    document.getElementById("coverage-wrap").style.display = "block";
    document.getElementById("cov-witnessed").textContent = witnessed + " of " + total;
    document.getElementById("cov-bar").style.width = pct.toFixed(1) + "%";
    document.getElementById("cov-detail").textContent = lastH.files_new + " new, " + lastH.files_updated + " updated, " + lastH.files_deleted + " deleted";
    document.getElementById("cov-skipped").textContent = skipped > 0 ? skipped + " skipped (binary/hidden)" : "None skipped";
}

// -- Recent activity (overview, last 10) --
(function() {
    const tbody = document.getElementById("recent-tbody");
    const rows = D.recent.slice(-10).reverse();
    tbody.innerHTML = rows.map(r => {
        const cls = "event-" + r.type.split("_")[0];
        return "<tr>" +
            "<td>" + r.time + "</td>" +
            '<td class="' + cls + '">' + r.type + "</td>" +
            '<td class="path">' + r.file + "</td>" +
            '<td class="hash">' + r.hash + "</td>" +
            "<td>" + r.actor + "</td></tr>";
    }).join("");
})();

// -- Paginated table helper --
function createPaginatedTable(opts) {
    const PAGE_SIZE = 50;
    let data = opts.data.slice();
    let filtered = data;
    let page = 0;
    let sortCol = null;
    let sortAsc = true;

    function render() {
        const start = page * PAGE_SIZE;
        const slice = filtered.slice(start, start + PAGE_SIZE);
        opts.tbody.innerHTML = slice.map(opts.renderRow).join("");
        opts.countLabel.textContent = filtered.length + " items";

        const totalPages = Math.ceil(filtered.length / PAGE_SIZE);
        opts.pagination.innerHTML =
            '<span>Page ' + (page + 1) + ' of ' + Math.max(totalPages, 1) + '</span>' +
            '<div>' +
            '<button class="page-btn" id="' + opts.id + '-prev"' + (page === 0 ? " disabled" : "") + '>&laquo; Prev</button> ' +
            '<button class="page-btn" id="' + opts.id + '-next"' + (page >= totalPages - 1 ? " disabled" : "") + '>Next &raquo;</button>' +
            '</div>';

        document.getElementById(opts.id + "-prev").onclick = () => { if (page > 0) { page--; render(); } };
        document.getElementById(opts.id + "-next").onclick = () => { if (page < totalPages - 1) { page++; render(); } };
    }

    opts.searchInput.addEventListener("input", function() {
        const q = this.value.toLowerCase();
        filtered = q ? data.filter(r => opts.searchFn(r, q)) : data;
        page = 0;
        render();
    });

    opts.tbody.closest("table").querySelectorAll("th[data-sort]").forEach(th => {
        th.addEventListener("click", () => {
            const col = th.dataset.sort;
            if (sortCol === col) { sortAsc = !sortAsc; } else { sortCol = col; sortAsc = true; }
            filtered.sort((a, b) => {
                const va = a[col] || "";
                const vb = b[col] || "";
                if (typeof va === "number") return sortAsc ? va - vb : vb - va;
                return sortAsc ? String(va).localeCompare(String(vb)) : String(vb).localeCompare(String(va));
            });
            page = 0;
            render();
        });
    });

    render();
}

// -- Files table --
function badgeFor(role) {
    return '<span class="badge badge-' + (role || "other") + '">' + (role || "other") + '</span>';
}

createPaginatedTable({
    id: "files",
    data: D.files,
    tbody: document.getElementById("files-tbody"),
    countLabel: document.getElementById("file-count-label"),
    pagination: document.getElementById("files-pagination"),
    searchInput: document.getElementById("file-search"),
    searchFn: (r, q) => r.path.toLowerCase().includes(q) || (r.role || "").includes(q),
    renderRow: r => '<tr class="file-row" data-path="' + r.path + '">' +
        '<td class="path">' + r.path + "</td>" +
        "<td>" + badgeFor(r.role) + "</td>" +
        "<td>" + r.size + "</td>" +
        "<td>" + r.modified + "</td>" +
        '<td class="hash">' + r.hash + "</td></tr>",
});

// File click to open (live mode only)
document.getElementById("files-tbody").addEventListener("click", function(e) {
    const row = e.target.closest(".file-row");
    if (!row || !LIVE) return;
    const path = row.dataset.path;
    fetch("/api/open-file", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({path: path})
    }).then(r => r.json()).then(data => {
        if (data.ok) showToast("Opened " + path, 2000);
        else showToast('<span style="color:var(--red)">' + data.error + '</span>');
    }).catch(() => {});
});

// -- Changes table --
createPaginatedTable({
    id: "changes",
    data: D.recent.slice().reverse(),
    tbody: document.getElementById("changes-tbody"),
    countLabel: document.getElementById("change-count-label"),
    pagination: document.getElementById("changes-pagination"),
    searchInput: document.getElementById("change-search"),
    searchFn: (r, q) => r.file.toLowerCase().includes(q) || r.type.includes(q) || r.actor.includes(q),
    renderRow: r => {
        const cls = "event-" + r.type.split("_")[0];
        return "<tr>" +
            "<td>" + r.seq + "</td>" +
            "<td>" + r.time + "</td>" +
            '<td class="' + cls + '">' + r.type + "</td>" +
            '<td class="path">' + r.file + "</td>" +
            '<td class="hash">' + r.hash + "</td>" +
            "<td>" + r.actor + "</td></tr>";
    },
});

// -- Harvests table --
(function() {
    const tbody = document.getElementById("harvests-tbody");
    tbody.innerHTML = D.harvests.map(h => "<tr>" +
        "<td>" + h.id + "</td>" +
        "<td>" + (h.started_at || "").substring(0, 19) + "</td>" +
        "<td>" + h.files_total + "</td>" +
        '<td class="event-created">' + (h.files_new || 0) + "</td>" +
        '<td class="event-modified">' + (h.files_updated || 0) + "</td>" +
        '<td class="event-deleted">' + (h.files_deleted || 0) + "</td>" +
        "<td>" + (h.files_skipped || 0) + "</td>" +
        "<td>" + (h.duration_ms || 0) + "ms</td></tr>"
    ).join("");
})();

// -- Compliance panel --
(function() {
    const comp = D.compliance || [];
    document.getElementById("comp-count").textContent = comp.filter(c => c.status === "covered").length;
    const chainEl = document.getElementById("comp-chain");
    chainEl.textContent = D.chain_valid ? "VALID" : "BROKEN";
    chainEl.className = "card-value " + (D.chain_valid ? "valid" : "broken");

    const grid = document.getElementById("compliance-grid");
    grid.innerHTML = comp.map(c => {
        const statusLabel = c.status === "covered" ? "Active" : "No Data";
        return '<div class="comp-card ' + c.status + '">' +
            '<div class="comp-status ' + c.status + '">' + statusLabel + '</div>' +
            '<div class="comp-framework">' + c.framework + '</div>' +
            '<div class="comp-desc">' + c.description + '</div>' +
            '<div class="comp-sections">' +
            c.sections.map(s => '<span class="comp-section">' + s + '</span>').join("") +
            '</div></div>';
    }).join("");
})();

// -- Sources panel --
const SOURCES = __SOURCES_DATA__;
(function() {
    var tbody = document.getElementById("sources-tbody");
    var countEl = document.getElementById("src-count");
    countEl.textContent = SOURCES.length + " source" + (SOURCES.length !== 1 ? "s" : "");
    tbody.innerHTML = SOURCES.map(function(s) {
        var isActive = s.path === D.target;
        var status = isActive
            ? '<span style="color:var(--green);font-weight:600;">Active</span>'
            : '<span style="color:var(--accent);cursor:pointer;">View</span>';
        var typeLabel = s.type === "cloud" ? "Cloud" : "Local";
        return '<tr class="source-row" data-path="' + s.path + '" style="cursor:pointer;">' +
            "<td>" + status + "</td>" +
            "<td>" + typeLabel + "</td>" +
            '<td class="path">' + s.path + "</td></tr>";
    }).join("");

    // Click to switch active source
    tbody.addEventListener("click", function(e) {
        var row = e.target.closest(".source-row");
        if (!row || !LIVE) return;
        var path = row.dataset.path;
        if (path === D.target) return; // already active
        fetch("/api/switch-source", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({path: path})
        }).then(function(r) { return r.json(); })
        .then(function(data) {
            if (data.ok) {
                showToast(data.message);
                if (data.refresh) setTimeout(function() { location.reload(); }, 600);
            } else {
                showToast('<span style="color:var(--red)">' + data.error + '</span>');
            }
        });
    });
})();

// Settings
(function() {
    document.getElementById("cfg-interval").value = D.interval_minutes || 60;
    document.getElementById("cfg-retain").value = D.snapshot_retain || 10;

    document.getElementById("btn-save-settings").addEventListener("click", function() {
        var btn = this;
        var msgEl = document.getElementById("settings-msg");
        btn.disabled = true;
        btn.textContent = "Saving...";
        fetch("/api/save-settings", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({
                interval_minutes: parseInt(document.getElementById("cfg-interval").value) || 60,
                snapshot_retain: parseInt(document.getElementById("cfg-retain").value) || 10,
            })
        })
        .then(function(r) { return r.json(); })
        .then(function(data) {
            msgEl.style.display = "inline";
            if (data.ok) {
                msgEl.style.color = "var(--green)";
                msgEl.textContent = "Saved";
            } else {
                msgEl.style.color = "var(--red)";
                msgEl.textContent = data.error;
            }
            btn.disabled = false;
            btn.textContent = "Save Settings";
            setTimeout(function() { msgEl.style.display = "none"; }, 3000);
        })
        .catch(function() {
            msgEl.style.display = "inline";
            msgEl.style.color = "var(--red)";
            msgEl.textContent = "Error";
            btn.disabled = false;
            btn.textContent = "Save Settings";
        });
    });
})();

// Schedule cron
(function() {
    var cronBtn = document.getElementById("btn-schedule-cron");
    var msgEl = document.getElementById("settings-msg");
    if (cronBtn) {
        cronBtn.addEventListener("click", function() {
            cronBtn.disabled = true;
            cronBtn.textContent = "Scheduling...";
            fetch("/api/schedule-cron", {method: "POST"})
            .then(function(r) { return r.json(); })
            .then(function(data) {
                msgEl.style.display = "inline";
                msgEl.style.color = data.ok ? "var(--green)" : "var(--red)";
                msgEl.textContent = data.ok ? data.message : data.error;
                cronBtn.disabled = false;
                cronBtn.textContent = "Schedule Automatic Scanning";
                setTimeout(function() { msgEl.style.display = "none"; }, 5000);
            })
            .catch(function() {
                msgEl.style.display = "inline";
                msgEl.style.color = "var(--red)";
                msgEl.textContent = "Error";
                cronBtn.disabled = false;
                cronBtn.textContent = "Schedule Automatic Scanning";
            });
        });
    }
})();

// Add local source
(function() {
    var browseBtn = document.getElementById("src-local-browse");
    var addBtn = document.getElementById("btn-add-local");
    var localMsg = document.getElementById("src-local-msg");

    if (browseBtn) {
        browseBtn.addEventListener("click", function() {
            browseBtn.disabled = true;
            browseBtn.textContent = "...";
            fetch("/api/browse", {method: "POST"})
            .then(function(r) { return r.json(); })
            .then(function(data) {
                if (data.ok) document.getElementById("src-local-folder").value = data.folder;
                browseBtn.disabled = false;
                browseBtn.textContent = "Browse";
            })
            .catch(function() {
                browseBtn.disabled = false;
                browseBtn.textContent = "Browse";
            });
        });
    }

    if (addBtn) {
        addBtn.addEventListener("click", function() {
            var folder = (document.getElementById("src-local-folder").value || "").trim();
            if (!folder) {
                localMsg.style.display = "block";
                localMsg.style.background = "rgba(248,81,73,0.1)";
                localMsg.style.border = "1px solid var(--red)";
                localMsg.style.color = "var(--red)";
                localMsg.textContent = "Enter a folder path.";
                return;
            }
            addBtn.disabled = true;
            addBtn.textContent = "Setting up...";
            localMsg.style.display = "none";

            fetch("/api/setup", {
                method: "POST",
                headers: {"Content-Type": "application/json"},
                body: JSON.stringify({source: "local", folder: folder, code: ""}),
            })
            .then(function(r) { return r.json(); })
            .then(function(data) {
                if (data.ok) {
                    localMsg.style.display = "block";
                    localMsg.style.background = "rgba(63,185,80,0.1)";
                    localMsg.style.border = "1px solid var(--green)";
                    localMsg.style.color = "var(--green)";
                    localMsg.textContent = data.message;
                    setTimeout(function() { location.reload(); }, 1500);
                } else {
                    localMsg.style.display = "block";
                    localMsg.style.background = "rgba(248,81,73,0.1)";
                    localMsg.style.border = "1px solid var(--red)";
                    localMsg.style.color = "var(--red)";
                    localMsg.textContent = data.error;
                    addBtn.disabled = false;
                    addBtn.textContent = "Add & Scan";
                }
            })
            .catch(function() {
                localMsg.style.display = "block";
                localMsg.style.background = "rgba(248,81,73,0.1)";
                localMsg.style.border = "1px solid var(--red)";
                localMsg.style.color = "var(--red)";
                localMsg.textContent = "Connection error.";
                addBtn.disabled = false;
                addBtn.textContent = "Add & Scan";
            });
        });
    }
})();

// Provider field switching
(function() {
    var srcProv = document.getElementById("src-provider");
    if (srcProv) {
        srcProv.addEventListener("change", function() {
            ["sharepoint","gdrive","s3"].forEach(function(p) {
                document.getElementById("src-fields-" + p).style.display = srcProv.value === p ? "block" : "none";
            });
        });
    }

    var addBtn = document.getElementById("btn-add-source");
    var srcMsg = document.getElementById("src-msg");
    if (addBtn) {
        addBtn.addEventListener("click", function() {
            var prov = srcProv.value;
            var payload = {source: "cloud", provider: prov, code: ""};

            if (prov === "sharepoint") {
                payload.sp_site = (document.getElementById("src-sp-site").value || "").trim();
                payload.sp_library = (document.getElementById("src-sp-library").value || "").trim() || "Documents";
                payload.sp_tenant = (document.getElementById("src-sp-tenant").value || "").trim();
                payload.sp_client_id = (document.getElementById("src-sp-client-id").value || "").trim();
                payload.sp_client_secret = (document.getElementById("src-sp-client-secret").value || "").trim();
                if (!payload.sp_site || !payload.sp_tenant || !payload.sp_client_id || !payload.sp_client_secret) {
                    srcMsg.style.display = "block";
                    srcMsg.style.background = "rgba(248,81,73,0.1)";
                    srcMsg.style.border = "1px solid var(--red)";
                    srcMsg.style.color = "var(--red)";
                    srcMsg.textContent = "All SharePoint fields are required.";
                    return;
                }
            } else if (prov === "gdrive") {
                payload.gd_folder_id = (document.getElementById("src-gd-folder-id").value || "").trim();
                payload.gd_creds = (document.getElementById("src-gd-creds").value || "").trim();
                if (!payload.gd_folder_id || !payload.gd_creds) {
                    srcMsg.style.display = "block";
                    srcMsg.style.background = "rgba(248,81,73,0.1)";
                    srcMsg.style.border = "1px solid var(--red)";
                    srcMsg.style.color = "var(--red)";
                    srcMsg.textContent = "Folder ID and credentials path are required.";
                    return;
                }
            } else if (prov === "s3") {
                payload.s3_target = (document.getElementById("src-s3-target").value || "").trim();
                if (!payload.s3_target) {
                    srcMsg.style.display = "block";
                    srcMsg.style.background = "rgba(248,81,73,0.1)";
                    srcMsg.style.border = "1px solid var(--red)";
                    srcMsg.style.color = "var(--red)";
                    srcMsg.textContent = "S3 bucket/prefix is required.";
                    return;
                }
            }

            addBtn.disabled = true;
            addBtn.textContent = "Connecting...";
            srcMsg.style.display = "none";

            fetch("/api/setup", {
                method: "POST",
                headers: {"Content-Type": "application/json"},
                body: JSON.stringify(payload),
            })
            .then(function(r) { return r.json(); })
            .then(function(data) {
                if (data.ok) {
                    srcMsg.style.display = "block";
                    srcMsg.style.background = "rgba(63,185,80,0.1)";
                    srcMsg.style.border = "1px solid var(--green)";
                    srcMsg.style.color = "var(--green)";
                    srcMsg.textContent = data.message;
                    setTimeout(function() { location.reload(); }, 1500);
                } else {
                    srcMsg.style.display = "block";
                    srcMsg.style.background = "rgba(248,81,73,0.1)";
                    srcMsg.style.border = "1px solid var(--red)";
                    srcMsg.style.color = "var(--red)";
                    srcMsg.textContent = data.error;
                    addBtn.disabled = false;
                    addBtn.textContent = "Connect & Scan";
                }
            })
            .catch(function() {
                srcMsg.style.display = "block";
                srcMsg.style.background = "rgba(248,81,73,0.1)";
                srcMsg.style.border = "1px solid var(--red)";
                srcMsg.style.color = "var(--red)";
                srcMsg.textContent = "Connection error.";
                addBtn.disabled = false;
                addBtn.textContent = "Connect & Scan";
            });
        });
    }
})();

// -- Notifications --
(function() {
    var saveBtn = document.getElementById("btn-save-notifications");
    if (!saveBtn) return;
    saveBtn.addEventListener("click", function() {
        var notifyOn = [];
        if (document.getElementById("notify-scan-complete").checked) notifyOn.push("scan_complete");
        if (document.getElementById("notify-chain-break").checked) notifyOn.push("chain_break");
        if (document.getElementById("notify-weekly-digest").checked) notifyOn.push("weekly_digest");
        var payload = {
            notify_email: (document.getElementById("notify-email").value || "").trim(),
            notify_on: notifyOn,
            smtp_host: (document.getElementById("smtp-host").value || "").trim(),
            smtp_port: parseInt(document.getElementById("smtp-port").value) || 587,
            smtp_user: (document.getElementById("smtp-user").value || "").trim(),
            smtp_pass: (document.getElementById("smtp-pass").value || "").trim(),
            smtp_from: (document.getElementById("smtp-from").value || "").trim(),
        };
        saveBtn.disabled = true;
        saveBtn.textContent = "Saving...";
        var msg = document.getElementById("notify-msg");
        fetch("/api/save-notifications", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify(payload),
        })
        .then(function(r) { return r.json(); })
        .then(function(data) {
            msg.style.display = "block";
            if (data.ok) {
                msg.style.background = "rgba(63,185,80,0.1)";
                msg.style.border = "1px solid var(--green)";
                msg.style.color = "var(--green)";
                msg.textContent = "Notification settings saved.";
            } else {
                msg.style.background = "rgba(248,81,73,0.1)";
                msg.style.border = "1px solid var(--red)";
                msg.style.color = "var(--red)";
                msg.textContent = data.error;
            }
            saveBtn.disabled = false;
            saveBtn.textContent = "Save Notification Settings";
        })
        .catch(function() {
            msg.style.display = "block";
            msg.style.background = "rgba(248,81,73,0.1)";
            msg.style.border = "1px solid var(--red)";
            msg.style.color = "var(--red)";
            msg.textContent = "Connection error.";
            saveBtn.disabled = false;
            saveBtn.textContent = "Save Notification Settings";
        });
    });
})();

// -- Welcome modal --
(function() {
    const params = new URLSearchParams(window.location.search);
    if (!params.has("welcome")) return;
    const fileCount = params.get("files") || D.file_count;
    const overlay = document.createElement("div");
    overlay.className = "modal-overlay show";
    overlay.innerHTML = `
        <div class="modal-box">
            <h2>You're All Set</h2>
            <p class="modal-sub">We just scanned <strong>${fileCount} files</strong> and started tracking them.</p>
            <div class="modal-checks">
                <div><span class="check">&#10003;</span> Every file has been hashed and recorded</div>
                <div><span class="check">&#10003;</span> A tamper-proof verification chain has been created</div>
                <div><span class="check">&#10003;</span> You can now prove file integrity to any auditor</div>
            </div>
            <div class="modal-actions">
                <button class="primary" id="welcome-schedule">Set up automatic scanning</button>
                <button id="welcome-add">Add another folder</button>
                <button id="welcome-report">Download your first compliance report</button>
            </div>
            <div class="modal-dismiss" id="welcome-dismiss">I'll explore on my own</div>
        </div>`;
    document.body.appendChild(overlay);
    function dismiss() {
        overlay.remove();
        window.history.replaceState({}, "", "/");
    }
    document.getElementById("welcome-dismiss").onclick = dismiss;
    document.getElementById("welcome-schedule").onclick = function() {
        dismiss();
        document.querySelector('[data-tab="sources"]').click();
    };
    document.getElementById("welcome-add").onclick = function() {
        dismiss();
        document.querySelector('[data-tab="sources"]').click();
    };
    document.getElementById("welcome-report").onclick = function() {
        dismiss();
        document.getElementById("btn-pdf").click();
    };
})();
</script>
</body>
</html>"""


_SETUP_TEMPLATE = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Signal Provenance</title>
<style>
:root {
    --bg: #0d1117;
    --surface: #161b22;
    --border: #30363d;
    --text: #e6edf3;
    --text-muted: #8b949e;
    --accent: #58a6ff;
    --green: #3fb950;
    --red: #f85149;
}
* { margin: 0; padding: 0; box-sizing: border-box; }
body { background: var(--bg); color: var(--text); font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Helvetica, Arial, sans-serif; }
.container { max-width: 440px; margin: 100px auto; padding: 0 20px; }
.card { background: var(--surface); border: 1px solid var(--border); border-radius: 12px; padding: 36px; }
.card h1 { font-size: 22px; font-weight: 700; margin-bottom: 4px; }
.card .sub { color: var(--text-muted); font-size: 14px; margin-bottom: 28px; }
label { font-size: 11px; color: var(--text-muted); text-transform: uppercase; letter-spacing: 0.8px; display: block; margin-bottom: 6px; font-weight: 600; }
label .optional { text-transform: none; letter-spacing: 0; font-weight: 400; }
input { width: 100%; padding: 10px 14px; background: var(--bg); border: 1px solid var(--border); border-radius: 6px; color: var(--text); font-size: 14px; margin-bottom: 20px; outline: none; transition: border-color 0.2s; }
input:focus { border-color: var(--accent); }
input::placeholder { color: var(--text-muted); opacity: 0.6; }
.code-input { font-family: 'SF Mono', 'Consolas', 'Courier New', monospace; font-size: 16px; letter-spacing: 1px; color: var(--accent); }
.btn { width: 100%; padding: 12px; background: var(--green); color: var(--bg); border: none; border-radius: 6px; font-size: 15px; font-weight: 700; cursor: pointer; transition: opacity 0.2s; }
.btn:hover { opacity: 0.9; }
.btn:disabled { opacity: 0.5; cursor: default; }
.msg { font-size: 13px; margin-top: 14px; padding: 10px 14px; border-radius: 6px; display: none; }
.msg.error { background: rgba(248,81,73,0.1); border: 1px solid var(--red); color: var(--red); }
.msg.success { background: rgba(63,185,80,0.1); border: 1px solid var(--green); color: var(--green); }
.footer { text-align: center; margin-top: 20px; font-size: 12px; color: var(--text-muted); }
.stab { flex:1;padding:10px;background:var(--bg);color:var(--text-muted);border:1px solid var(--border);font-size:13px;cursor:pointer;transition:all 0.15s; }
.stab:first-child { border-radius:6px 0 0 6px; }
.stab:last-child { border-radius:0 6px 6px 0; border-left:none; }
.stab.active { background:var(--accent);color:var(--bg);border-color:var(--accent);font-weight:600; }
select { -webkit-appearance: none; appearance: none; }
</style>
</head>
<body>
<div class="container">
    <div class="card">
        <h1>Signal Provenance</h1>
        <p class="sub">Prove what happened.</p>

        <label>Activation Code <span class="optional">(paste from email, or leave blank for free tier)</span></label>
        <input class="code-input" id="code" placeholder="SP-XXXX-XXXX-XXXX" autocomplete="off" spellcheck="false">

        <label>Source</label>
        <div id="source-tabs" style="display:flex;gap:0;margin-bottom:16px;">
            <button type="button" class="stab active" data-source="local">Local / Synced Folder</button>
            <button type="button" class="stab" data-source="cloud">Cloud (Enterprise)</button>
        </div>

        <div id="source-local">
            <label>Folder to Watch</label>
            <div style="display:flex;gap:8px;">
                <input id="folder" placeholder="/path/to/your/project" autocomplete="off" spellcheck="false" style="margin-bottom:0;flex:1;">
                <button type="button" id="browse" style="padding:10px 16px;background:var(--surface);color:var(--text);border:1px solid var(--border);border-radius:6px;font-size:13px;cursor:pointer;white-space:nowrap;">Browse</button>
            </div>
            <p style="font-size:11px;color:var(--text-muted);margin-top:8px;margin-bottom:20px;line-height:1.5;">
                Works with any local folder, including synced cloud storage:<br>
                Google Drive, OneDrive, Dropbox, iCloud Drive
            </p>
        </div>

        <div id="source-cloud" style="display:none;">
            <label>Provider</label>
            <select id="cloud-provider" style="width:100%;padding:10px 14px;background:var(--bg);border:1px solid var(--border);border-radius:6px;color:var(--text);font-size:14px;margin-bottom:16px;outline:none;">
                <option value="sharepoint">SharePoint / OneDrive for Business</option>
                <option value="gdrive">Google Drive (Service Account)</option>
                <option value="s3">AWS S3</option>
            </select>

            <div id="fields-sharepoint">
                <label>SharePoint Site Name</label>
                <input id="sp-site" placeholder="MySiteName" autocomplete="off" spellcheck="false">
                <label>Document Library <span class="optional">(default: Documents)</span></label>
                <input id="sp-library" placeholder="Documents" autocomplete="off" spellcheck="false">
                <label>Azure AD Tenant ID</label>
                <input id="sp-tenant" placeholder="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx" autocomplete="off" spellcheck="false">
                <label>App Registration Client ID</label>
                <input id="sp-client-id" placeholder="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx" autocomplete="off" spellcheck="false">
                <label>App Registration Client Secret</label>
                <input id="sp-client-secret" type="password" placeholder="Client secret" autocomplete="off" spellcheck="false">
            </div>

            <div id="fields-gdrive" style="display:none;">
                <label>Google Drive Folder ID</label>
                <input id="gd-folder-id" placeholder="1A2B3C4D5E6F..." autocomplete="off" spellcheck="false">
                <label>Service Account JSON Key Path</label>
                <div style="display:flex;gap:8px;">
                    <input id="gd-creds" placeholder="/path/to/service-account.json" autocomplete="off" spellcheck="false" style="margin-bottom:0;flex:1;">
                    <button type="button" id="browse-creds" style="padding:10px 16px;background:var(--surface);color:var(--text);border:1px solid var(--border);border-radius:6px;font-size:13px;cursor:pointer;white-space:nowrap;">Browse</button>
                </div>
                <div style="height:20px;"></div>
            </div>

            <div id="fields-s3" style="display:none;">
                <label>S3 Bucket / Prefix</label>
                <input id="s3-target" placeholder="my-bucket/optional/prefix" autocomplete="off" spellcheck="false">
                <p style="font-size:11px;color:var(--text-muted);margin-top:-12px;margin-bottom:20px;">
                    Uses your AWS credentials (~/.aws/credentials or environment variables)
                </p>
            </div>
        </div>

        <button class="btn" id="start">Start</button>
        <div class="msg" id="msg"></div>
    </div>
    <p class="footer">Your data never leaves your machine.</p>
</div>
<script>
(function() {
    var btn = document.getElementById("start");
    var msg = document.getElementById("msg");
    var activeSource = "local";

    // Source tab switching
    document.querySelectorAll(".stab").forEach(function(tab) {
        tab.addEventListener("click", function() {
            document.querySelectorAll(".stab").forEach(function(t) { t.classList.remove("active"); });
            tab.classList.add("active");
            activeSource = tab.dataset.source;
            document.getElementById("source-local").style.display = activeSource === "local" ? "block" : "none";
            document.getElementById("source-cloud").style.display = activeSource === "cloud" ? "block" : "none";
        });
    });

    // Cloud provider field switching
    var providerSelect = document.getElementById("cloud-provider");
    if (providerSelect) {
        providerSelect.addEventListener("change", function() {
            ["sharepoint","gdrive","s3"].forEach(function(p) {
                document.getElementById("fields-" + p).style.display = providerSelect.value === p ? "block" : "none";
            });
        });
    }

    // Browse buttons (local folder + gdrive creds)
    function browseTo(inputId) {
        return function() {
            var browseBtn = this;
            browseBtn.disabled = true;
            browseBtn.textContent = "...";
            fetch("/api/browse", {method: "POST"})
            .then(function(res) { return res.json(); })
            .then(function(data) {
                if (data.ok) document.getElementById(inputId).value = data.folder;
                browseBtn.disabled = false;
                browseBtn.textContent = "Browse";
            })
            .catch(function() {
                browseBtn.disabled = false;
                browseBtn.textContent = "Browse";
            });
        };
    }
    document.getElementById("browse").addEventListener("click", browseTo("folder"));
    var browseCreds = document.getElementById("browse-creds");
    if (browseCreds) browseCreds.addEventListener("click", browseTo("gd-creds"));

    btn.addEventListener("click", function() {
        var code = document.getElementById("code").value.trim();
        var payload = {code: code, source: activeSource};

        if (activeSource === "local") {
            payload.folder = document.getElementById("folder").value.trim();
            if (!payload.folder) {
                msg.className = "msg error";
                msg.textContent = "Enter the path to the folder you want to watch.";
                msg.style.display = "block";
                return;
            }
        } else {
            var prov = document.getElementById("cloud-provider").value;
            payload.provider = prov;
            if (prov === "sharepoint") {
                payload.sp_site = document.getElementById("sp-site").value.trim();
                payload.sp_library = document.getElementById("sp-library").value.trim() || "Documents";
                payload.sp_tenant = document.getElementById("sp-tenant").value.trim();
                payload.sp_client_id = document.getElementById("sp-client-id").value.trim();
                payload.sp_client_secret = document.getElementById("sp-client-secret").value.trim();
                if (!payload.sp_site || !payload.sp_tenant || !payload.sp_client_id || !payload.sp_client_secret) {
                    msg.className = "msg error";
                    msg.textContent = "All SharePoint fields are required.";
                    msg.style.display = "block";
                    return;
                }
            } else if (prov === "gdrive") {
                payload.gd_folder_id = document.getElementById("gd-folder-id").value.trim();
                payload.gd_creds = document.getElementById("gd-creds").value.trim();
                if (!payload.gd_folder_id || !payload.gd_creds) {
                    msg.className = "msg error";
                    msg.textContent = "Folder ID and credentials path are required.";
                    msg.style.display = "block";
                    return;
                }
            } else if (prov === "s3") {
                payload.s3_target = document.getElementById("s3-target").value.trim();
                if (!payload.s3_target) {
                    msg.className = "msg error";
                    msg.textContent = "S3 bucket/prefix is required.";
                    msg.style.display = "block";
                    return;
                }
            }
        }

        btn.disabled = true;
        btn.textContent = "Setting up...";
        msg.style.display = "none";

        fetch("/api/setup", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify(payload),
        })
        .then(function(res) { return res.json(); })
        .then(function(data) {
            if (data.ok) {
                msg.className = "msg success";
                msg.textContent = data.message;
                msg.style.display = "block";
                btn.textContent = "Redirecting...";
                setTimeout(function() {
                    window.location.href = data.redirect || "/";
                }, 1000);
            } else {
                msg.className = "msg error";
                msg.textContent = data.error;
                msg.style.display = "block";
                btn.disabled = false;
                btn.textContent = "Start";
            }
        })
        .catch(function() {
            msg.className = "msg error";
            msg.textContent = "Connection error. Is the server running?";
            msg.style.display = "block";
            btn.disabled = false;
            btn.textContent = "Start";
        });
    });
})();
</script>
</body>
</html>"""
