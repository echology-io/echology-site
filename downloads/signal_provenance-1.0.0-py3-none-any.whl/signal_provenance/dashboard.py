"""Self-contained HTML dashboard for Signal Provenance.

Two modes:
  Static:  export_dashboard() generates a single dashboard.html file.
  Live:    serve_dashboard() runs a local HTTP server with action buttons
           that trigger harvest, PDF export, and auto-refresh.
"""

from __future__ import annotations

import json
import sqlite3
import threading
import webbrowser
from datetime import datetime, timezone
from http.server import HTTPServer, BaseHTTPRequestHandler
from pathlib import Path

from signal_provenance import __version__
from signal_provenance.export import COMPLIANCE_MAPPING, _collect_report_data, _format_size


def _build_dashboard_data(conn: sqlite3.Connection, target_dir: Path) -> str:
    """Build the JSON data blob for the dashboard template."""
    from signal_provenance.config import load_config

    data = _collect_report_data(conn, target_dir)
    now = datetime.now(timezone.utc).isoformat()
    chain_valid = data["chain"].get("valid", False)
    cfg = load_config(target_dir)

    # Deployment name from config, fallback to directory name
    deployment_name = cfg.get("deployment_name", "") or target_dir.name

    # Harvest history
    harvests = []
    for row in conn.execute(
        "SELECT id, harvested_at, files_total, files_new, files_updated, "
        "files_deleted, files_skipped, duration_ms "
        "FROM metadata_harvests ORDER BY harvested_at DESC LIMIT 50"
    ).fetchall():
        harvests.append({
            "id": row[0], "started_at": row[1], "files_total": row[2],
            "files_new": row[3], "files_updated": row[4],
            "files_deleted": row[5], "files_skipped": row[6],
            "duration_ms": row[7],
        })

    # Chain continuity -- days from first event to now
    first_event = None
    chain_days = 0
    if data["events"]:
        first_event = data["events"][0].get("timestamp", "")[:19]
        try:
            first_dt = datetime.fromisoformat(first_event.replace("Z", "+00:00"))
            chain_days = (datetime.now(timezone.utc) - first_dt).days
        except (ValueError, TypeError):
            pass

    role_counts = {}
    for f in data["files"]:
        role = f.get("role") or "other"
        role_counts[role] = role_counts.get(role, 0) + 1

    total_size = sum(f.get("size_bytes") or 0 for f in data["files"])

    event_types = {}
    for e in data["events"]:
        et = e.get("event_type", "unknown")
        event_types[et] = event_types.get(et, 0) + 1

    file_tree = []
    for f in data["files"]:
        file_tree.append({
            "path": f["file_path"],
            "hash": (f.get("content_hash") or "")[:12],
            "size": _format_size(f.get("size_bytes")),
            "modified": (f.get("last_modified") or "")[:19],
            "role": f.get("role") or "other",
        })

    recent = []
    for e in data["events"][-100:]:
        recent.append({
            "seq": e["sequence"],
            "time": (e.get("timestamp") or "")[:19],
            "type": e.get("event_type", ""),
            "file": e.get("file_path") or "",
            "hash": (e.get("content_hash_after") or "")[:12],
            "actor": e.get("actor") or "",
        })

    compliance = []
    for key, info in COMPLIANCE_MAPPING.items():
        compliance.append({
            "framework": key.replace("_", " ").upper(),
            "sections": info["sections"],
            "description": info["description"],
            "status": "covered" if chain_valid and data["total_links"] > 0 else "no_data",
        })

    return json.dumps({
        "generated": now[:19],
        "version": __version__,
        "target": str(target_dir),
        "deployment_name": deployment_name,
        "chain_valid": chain_valid,
        "total_links": data["total_links"],
        "genesis_hash": data["genesis_hash"],
        "terminal_hash": data["terminal_hash"],
        "first_event": first_event,
        "chain_days": chain_days,
        "file_count": len(data["files"]),
        "event_count": len(data["events"]),
        "total_size": _format_size(total_size),
        "role_counts": role_counts,
        "event_types": event_types,
        "harvests": harvests,
        "files": file_tree,
        "recent": recent,
        "compliance": compliance,
    }, default=str)


def export_dashboard(
    conn: sqlite3.Connection,
    target_dir: Path,
    output_path: Path,
) -> Path:
    """Generate a self-contained HTML dashboard."""
    dashboard_data = _build_dashboard_data(conn, target_dir)
    html = _DASHBOARD_TEMPLATE.replace("__DASHBOARD_DATA__", dashboard_data)
    output_path.write_text(html, encoding="utf-8")
    return output_path


def _dashboard_html(target_dir: Path) -> str:
    """Generate dashboard HTML string from current state."""
    from signal_provenance.db import get_connection
    conn = get_connection(target_dir)
    dashboard_data = _build_dashboard_data(conn, target_dir)
    conn.close()
    return _DASHBOARD_TEMPLATE.replace("__DASHBOARD_DATA__", dashboard_data)


def serve_dashboard(target_dir: Path | None = None, port: int = 9111,
                    open_browser: bool = True) -> None:
    """Serve the dashboard with live action endpoints.

    If target_dir is None, serves a setup page where the user can
    enter an activation code and folder path to initialize provenance.
    """
    from signal_provenance.db import get_connection, init_db
    from signal_provenance.harvest import harvest, auto_report
    from signal_provenance.providers import get_provider
    from signal_provenance.config import load_config

    state = {"target_dir": None}
    if target_dir is not None:
        target_dir = target_dir.expanduser().resolve()
        state["target_dir"] = target_dir

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, fmt, *args):
            pass  # suppress request logs

        def do_GET(self):
            if self.path == "/" or self.path == "/dashboard":
                td = state["target_dir"]
                if td is None:
                    self._respond(200, "text/html", _SETUP_TEMPLATE.encode())
                else:
                    html = _dashboard_html(td)
                    self._respond(200, "text/html", html.encode())
            elif self.path.startswith("/api/download"):
                from urllib.parse import urlparse, parse_qs
                qs = parse_qs(urlparse(self.path).query)
                fpath = Path(qs.get("path", [""])[0])
                if state["target_dir"] and fpath.exists() and fpath.is_file():
                    self._respond(200, "application/octet-stream",
                                  fpath.read_bytes(),
                                  extra={"Content-Disposition":
                                         f'attachment; filename="{fpath.name}"'})
                else:
                    self._json(404, {"ok": False, "error": "File not found"})
            else:
                self._json(404, {"ok": False, "error": "Not found"})

        def do_POST(self):
            if self.path == "/api/setup":
                self._handle_setup()
            elif self.path == "/api/harvest":
                self._handle_harvest()
            elif self.path == "/api/export-pdf":
                self._handle_export_pdf()
            elif self.path.startswith("/api/open-file"):
                self._handle_open_file()
            else:
                self._json(404, {"ok": False, "error": "Not found"})

        def _handle_setup(self):
            content_length = int(self.headers.get("Content-Length", 0))
            body = self.rfile.read(content_length) if content_length else b""
            try:
                data = json.loads(body) if body else {}
            except json.JSONDecodeError:
                self._json(400, {"ok": False, "error": "Invalid JSON"})
                return

            code = (data.get("code") or "").strip()
            folder = (data.get("folder") or "").strip()

            if not folder:
                self._json(400, {"ok": False, "error": "Folder path is required"})
                return

            folder_path = Path(folder).expanduser().resolve()
            if not folder_path.is_dir():
                self._json(400, {"ok": False, "error": f"Not a directory: {folder_path}"})
                return

            # Activate license if code provided
            if code:
                try:
                    from signal_provenance.license import activate, LicenseError
                    activate(code)
                except Exception as e:
                    self._json(400, {"ok": False, "error": f"Activation failed: {e}"})
                    return

            # Init provenance
            prov_dir = folder_path / ".signal-provenance"
            prov_dir.mkdir(parents=True, exist_ok=True)
            conn = get_connection(folder_path)
            init_db(conn)

            # First harvest
            cfg = load_config(folder_path)
            provider = get_provider(
                str(folder_path),
                exclude=cfg.get("exclude"),
                include=cfg.get("include"),
            )
            summary = harvest(conn, folder_path, provider=provider)

            # Generate reports
            auto_report(conn, folder_path)
            conn.close()

            # Switch to dashboard mode
            state["target_dir"] = folder_path

            self._json(200, {
                "ok": True,
                "redirect": "/",
                "message": (f"Initialized and harvested {summary['files_total']} files "
                            f"({summary['files_new']} new) "
                            f"in {summary['duration_ms']}ms"),
            })

        def _handle_open_file(self):
            import subprocess
            from urllib.parse import urlparse, parse_qs
            content_length = int(self.headers.get("Content-Length", 0))
            body = self.rfile.read(content_length) if content_length else b""
            try:
                data = json.loads(body) if body else {}
            except json.JSONDecodeError:
                data = {}
            td = state["target_dir"]
            if td is None:
                self._json(400, {"ok": False, "error": "Not configured"})
                return
            rel_path = data.get("path", "")
            full = td / rel_path
            if not full.exists():
                self._json(404, {"ok": False, "error": "File not found"})
                return
            try:
                full.resolve().relative_to(td.resolve())
            except ValueError:
                self._json(403, {"ok": False, "error": "Access denied"})
                return
            try:
                subprocess.Popen(["xdg-open", str(full)],
                                 stdout=subprocess.DEVNULL,
                                 stderr=subprocess.DEVNULL)
            except FileNotFoundError:
                try:
                    subprocess.Popen(["open", str(full)],
                                     stdout=subprocess.DEVNULL,
                                     stderr=subprocess.DEVNULL)
                except FileNotFoundError:
                    self._json(500, {"ok": False, "error": "No file opener found"})
                    return
            self._json(200, {"ok": True, "message": f"Opened {rel_path}"})

        def _handle_harvest(self):
            td = state["target_dir"]
            if td is None:
                self._json(400, {"ok": False, "error": "Not configured"})
                return
            try:
                cfg = load_config(td)
                conn = get_connection(td)
                init_db(conn)
                provider = get_provider(
                    str(td),
                    exclude=cfg.get("exclude"),
                    include=cfg.get("include"),
                )
                summary = harvest(conn, td, provider=provider)
                auto_report(conn, td)
                conn.close()
                self._json(200, {
                    "ok": True,
                    "refresh": True,
                    "message": (f"Harvested {summary['files_total']} files "
                                f"({summary['files_new']} new, "
                                f"{summary['files_updated']} updated, "
                                f"{summary['files_deleted']} deleted) "
                                f"in {summary['duration_ms']}ms"),
                })
            except Exception as e:
                self._json(500, {"ok": False, "error": str(e)})

        def _handle_export_pdf(self):
            td = state["target_dir"]
            if td is None:
                self._json(400, {"ok": False, "error": "Not configured"})
                return
            try:
                from signal_provenance.export import export_pdf
                conn = get_connection(td)
                report_dir = td / ".signal-provenance" / "reports"
                report_dir.mkdir(parents=True, exist_ok=True)
                stamp = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H%M%S")
                out = report_dir / f"provenance-{stamp}.pdf"
                export_pdf(conn, td, out)
                conn.close()
                self._json(200, {
                    "ok": True,
                    "download": str(out),
                    "message": f"PDF generated: {out.name}",
                })
            except Exception as e:
                self._json(500, {"ok": False, "error": str(e)})

        def _json(self, code, data):
            body = json.dumps(data).encode()
            self._respond(code, "application/json", body)

        def _respond(self, code, content_type, body, extra=None):
            self.send_response(code)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(body)))
            if extra:
                for k, v in extra.items():
                    self.send_header(k, v)
            self.end_headers()
            self.wfile.write(body)

    server = HTTPServer(("127.0.0.1", port), Handler)
    url = f"http://localhost:{port}"
    print(f"Dashboard live at {url}")
    print("Press Ctrl+C to stop")

    if open_browser:
        threading.Timer(0.5, lambda: webbrowser.open(url)).start()

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nDashboard stopped.")
        server.server_close()


_DASHBOARD_TEMPLATE = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Signal Provenance Dashboard</title>
<style>
:root {
    --bg: #0d1117;
    --surface: #161b22;
    --border: #30363d;
    --text: #e6edf3;
    --text-muted: #8b949e;
    --accent: #58a6ff;
    --green: #3fb950;
    --red: #f85149;
    --yellow: #d29922;
    --orange: #db6d28;
}
* { margin: 0; padding: 0; box-sizing: border-box; }
body {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif;
    background: var(--bg);
    color: var(--text);
    line-height: 1.5;
    min-height: 100vh;
}
a { color: var(--accent); text-decoration: none; }

/* Layout */
.header {
    background: var(--surface);
    border-bottom: 1px solid var(--border);
    padding: 16px 24px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 12px;
}
.header-left { display: flex; align-items: center; gap: 16px; }
.header-left h1 { font-size: 18px; font-weight: 600; }
.header-left h1 span { color: var(--text-muted); font-weight: 400; }
.deployment-name { font-size: 14px; color: var(--accent); font-weight: 500; padding-left: 16px; border-left: 1px solid var(--border); }
.header-actions { display: flex; gap: 8px; align-items: center; }
.header-meta { font-size: 12px; color: var(--text-muted); text-align: right; }

.tabs {
    background: var(--surface);
    border-bottom: 1px solid var(--border);
    padding: 0 24px;
    display: flex;
    gap: 0;
}
.tab {
    padding: 10px 16px;
    font-size: 13px;
    color: var(--text-muted);
    cursor: pointer;
    border-bottom: 2px solid transparent;
    transition: all 0.15s;
}
.tab:hover { color: var(--text); }
.tab.active { color: var(--text); border-bottom-color: var(--accent); }

.container { max-width: 1400px; margin: 0 auto; padding: 20px 24px; }
.panel { display: none; }
.panel.active { display: block; }

/* Status banner */
.status-banner {
    border: 1px solid var(--border);
    border-radius: 8px;
    padding: 20px 24px;
    margin-bottom: 24px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 16px;
}
.status-banner.valid { border-color: rgba(63, 185, 80, 0.4); background: rgba(63, 185, 80, 0.06); }
.status-banner.broken { border-color: rgba(248, 81, 73, 0.4); background: rgba(248, 81, 73, 0.06); }
.status-headline { font-size: 16px; font-weight: 600; }
.status-headline .status-word { font-weight: 700; }
.status-headline .status-word.valid { color: var(--green); }
.status-headline .status-word.broken { color: var(--red); }
.status-details { display: flex; gap: 24px; flex-wrap: wrap; }
.status-stat { text-align: center; }
.status-stat-value { font-size: 22px; font-weight: 700; color: var(--text); }
.status-stat-label { font-size: 11px; color: var(--text-muted); text-transform: uppercase; letter-spacing: 0.5px; }

/* Cards */
.cards { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; margin-bottom: 24px; }
.card {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 8px;
    padding: 16px;
}
.card-label { font-size: 12px; color: var(--text-muted); text-transform: uppercase; letter-spacing: 0.5px; }
.card-value { font-size: 28px; font-weight: 600; margin-top: 4px; }
.card-value.valid { color: var(--green); }
.card-value.broken { color: var(--red); }

/* Compliance mini strip on overview */
.comp-strip {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
    gap: 8px;
    margin-bottom: 24px;
}
.comp-mini {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 6px;
    padding: 10px 12px;
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 12px;
}
.comp-dot {
    width: 8px;
    height: 8px;
    border-radius: 50%;
    flex-shrink: 0;
}
.comp-dot.covered { background: var(--green); }
.comp-dot.no_data { background: var(--text-muted); }
.comp-mini-name { font-weight: 500; }

/* Tables */
.table-wrap {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 8px;
    overflow: hidden;
    margin-bottom: 24px;
}
.table-header {
    padding: 12px 16px;
    border-bottom: 1px solid var(--border);
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 8px;
}
.table-header h3 { font-size: 14px; font-weight: 600; }
.search-input {
    background: var(--bg);
    border: 1px solid var(--border);
    border-radius: 6px;
    padding: 6px 12px;
    font-size: 12px;
    color: var(--text);
    outline: none;
    width: 220px;
}
.search-input:focus { border-color: var(--accent); }
table { width: 100%; border-collapse: collapse; font-size: 13px; }
th {
    text-align: left;
    padding: 8px 16px;
    background: var(--bg);
    color: var(--text-muted);
    font-weight: 500;
    font-size: 12px;
    border-bottom: 1px solid var(--border);
    cursor: pointer;
    user-select: none;
    white-space: nowrap;
}
th:hover { color: var(--text); }
th .sort-arrow { margin-left: 4px; font-size: 10px; }
td {
    padding: 8px 16px;
    border-bottom: 1px solid var(--border);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    max-width: 400px;
}
td.path { font-family: "SFMono-Regular", Consolas, monospace; font-size: 12px; }
td.hash { font-family: "SFMono-Regular", Consolas, monospace; font-size: 11px; color: var(--text-muted); }
tr:hover td { background: rgba(88, 166, 255, 0.04); }
tr.file-row { cursor: pointer; }
tr.file-row:hover td { background: rgba(88, 166, 255, 0.08); }

/* Role badges */
.badge {
    display: inline-block;
    padding: 2px 8px;
    border-radius: 12px;
    font-size: 11px;
    font-weight: 500;
}
.badge-code { background: rgba(88, 166, 255, 0.15); color: var(--accent); }
.badge-config { background: rgba(210, 153, 34, 0.15); color: var(--yellow); }
.badge-doc { background: rgba(63, 185, 80, 0.15); color: var(--green); }
.badge-test { background: rgba(219, 109, 40, 0.15); color: var(--orange); }
.badge-data { background: rgba(248, 81, 73, 0.15); color: var(--red); }
.badge-other { background: rgba(139, 148, 158, 0.15); color: var(--text-muted); }
.badge-template { background: rgba(188, 140, 255, 0.15); color: #bc8cff; }
.badge-style { background: rgba(255, 123, 114, 0.15); color: #ff7b72; }
.badge-document { background: rgba(63, 185, 80, 0.15); color: var(--green); }

/* Event type badges */
.event-created { color: var(--green); }
.event-modified { color: var(--yellow); }
.event-deleted { color: var(--red); }

/* Breakdown bars */
.bar-row { display: flex; align-items: center; gap: 8px; margin-bottom: 6px; }
.bar-label { font-size: 12px; width: 100px; text-align: right; color: var(--text-muted); }
.bar-track { flex: 1; height: 20px; background: var(--bg); border-radius: 4px; overflow: hidden; }
.bar-fill { height: 100%; border-radius: 4px; transition: width 0.3s; min-width: 2px; }
.bar-count { font-size: 12px; width: 50px; color: var(--text-muted); }

/* Chain detail */
.chain-detail {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 8px;
    padding: 20px;
    margin-bottom: 24px;
}
.chain-row { display: flex; gap: 12px; margin-bottom: 8px; font-size: 13px; }
.chain-label { color: var(--text-muted); min-width: 140px; }
.chain-value { font-family: "SFMono-Regular", Consolas, monospace; font-size: 12px; word-break: break-all; }

/* Methodology */
.methodology {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 8px;
    padding: 20px;
    margin-bottom: 24px;
}
.methodology h3 { font-size: 14px; font-weight: 600; margin-bottom: 12px; }
.methodology p { font-size: 13px; color: var(--text-muted); margin-bottom: 10px; line-height: 1.6; }
.methodology code {
    background: var(--bg);
    padding: 2px 6px;
    border-radius: 4px;
    font-size: 12px;
    color: var(--accent);
}

/* Pagination */
.pagination {
    padding: 12px 16px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    border-top: 1px solid var(--border);
    font-size: 12px;
    color: var(--text-muted);
}
.page-btn {
    background: var(--bg);
    border: 1px solid var(--border);
    border-radius: 6px;
    padding: 4px 12px;
    color: var(--text);
    cursor: pointer;
    font-size: 12px;
}
.page-btn:hover { border-color: var(--accent); }
.page-btn:disabled { opacity: 0.4; cursor: default; }

/* Compliance cards */
.comp-card {
    background: var(--bg);
    border: 1px solid var(--border);
    border-radius: 8px;
    padding: 16px;
    position: relative;
    overflow: hidden;
}
.comp-card::before {
    content: "";
    position: absolute;
    top: 0; left: 0;
    width: 4px;
    height: 100%;
}
.comp-card.covered::before { background: var(--green); }
.comp-card.no_data::before { background: var(--text-muted); }
.comp-framework { font-size: 14px; font-weight: 600; margin-bottom: 4px; }
.comp-desc { font-size: 12px; color: var(--text-muted); margin-bottom: 10px; }
.comp-sections { display: flex; flex-wrap: wrap; gap: 6px; }
.comp-section {
    display: inline-block;
    padding: 2px 8px;
    border-radius: 4px;
    font-size: 11px;
    font-family: "SFMono-Regular", Consolas, monospace;
    background: rgba(88, 166, 255, 0.1);
    color: var(--accent);
}
.comp-status {
    position: absolute;
    top: 16px;
    right: 16px;
    font-size: 11px;
    font-weight: 600;
    text-transform: uppercase;
}
.comp-status.covered { color: var(--green); }
.comp-status.no_data { color: var(--text-muted); }

/* Upsell */
.upsell {
    background: var(--surface);
    border: 1px solid rgba(210, 153, 34, 0.3);
    border-radius: 8px;
    padding: 20px 24px;
    margin-top: 24px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 16px;
}
.upsell-text { max-width: 600px; }
.upsell-text strong { color: var(--yellow); font-size: 14px; }
.upsell-text p { font-size: 13px; color: var(--text-muted); margin-top: 4px; }

/* Action buttons */
.action-btn {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 7px 14px;
    border-radius: 6px;
    font-size: 12px;
    font-weight: 600;
    cursor: pointer;
    border: 1px solid var(--border);
    text-decoration: none;
    transition: all 0.15s;
}
.harvest-btn { background: rgba(63, 185, 80, 0.12); color: var(--green); border-color: rgba(63, 185, 80, 0.3); }
.harvest-btn:hover { background: rgba(63, 185, 80, 0.22); }
.pdf-btn { background: rgba(88, 166, 255, 0.12); color: var(--accent); border-color: rgba(88, 166, 255, 0.3); }
.pdf-btn:hover { background: rgba(88, 166, 255, 0.22); }
.signal-btn { background: rgba(210, 153, 34, 0.15); color: var(--yellow); border-color: rgba(210, 153, 34, 0.3); padding: 9px 20px; font-size: 13px; }
.signal-btn:hover { background: rgba(210, 153, 34, 0.25); }

/* Toast */
.toast {
    position: fixed;
    bottom: 24px;
    left: 50%;
    transform: translateX(-50%) translateY(80px);
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 8px;
    padding: 12px 20px;
    font-size: 13px;
    color: var(--text);
    box-shadow: 0 8px 24px rgba(0,0,0,0.4);
    opacity: 0;
    transition: all 0.3s ease;
    z-index: 1000;
    pointer-events: none;
}
.toast.show { opacity: 1; transform: translateX(-50%) translateY(0); }
.toast code { background: var(--bg); padding: 2px 6px; border-radius: 4px; font-size: 12px; }

/* Footer */
.footer {
    text-align: center;
    padding: 20px;
    font-size: 11px;
    color: var(--text-muted);
    border-top: 1px solid var(--border);
    margin-top: 40px;
}
</style>
</head>
<body>

<div class="header">
    <div class="header-left">
        <h1>Signal Provenance <span>Dashboard</span></h1>
        <div class="deployment-name" id="deployment-name"></div>
    </div>
    <div class="header-actions">
        <button class="action-btn harvest-btn" id="btn-harvest">Harvest Now</button>
        <button class="action-btn pdf-btn" id="btn-pdf">Export Compliance Report</button>
    </div>
</div>

<div class="tabs">
    <div class="tab active" data-panel="overview">Overview</div>
    <div class="tab" data-panel="files">Files</div>
    <div class="tab" data-panel="changes">Changes</div>
    <div class="tab" data-panel="harvests">Harvests</div>
    <div class="tab" data-panel="compliance">Compliance</div>
    <div class="tab" data-panel="chain">Chain</div>
</div>

<div class="container">

<!-- Overview Panel -->
<div class="panel active" id="panel-overview">

    <!-- Status banner -->
    <div class="status-banner" id="status-banner">
        <div class="status-headline" id="status-headline"></div>
        <div class="status-details">
            <div class="status-stat">
                <div class="status-stat-value" id="stat-frameworks"></div>
                <div class="status-stat-label">Frameworks</div>
            </div>
            <div class="status-stat">
                <div class="status-stat-value" id="stat-files"></div>
                <div class="status-stat-label">Files</div>
            </div>
            <div class="status-stat">
                <div class="status-stat-value" id="stat-days"></div>
                <div class="status-stat-label">Days Monitored</div>
            </div>
            <div class="status-stat">
                <div class="status-stat-value" id="stat-chain"></div>
                <div class="status-stat-label">Chain Links</div>
            </div>
        </div>
    </div>

    <!-- Compliance strip -->
    <div class="comp-strip" id="comp-strip"></div>

    <div class="cards">
        <div class="card">
            <div class="card-label">Total Events</div>
            <div class="card-value" id="card-events"></div>
        </div>
        <div class="card">
            <div class="card-label">Total Size</div>
            <div class="card-value" id="card-size"></div>
        </div>
        <div class="card">
            <div class="card-label">First Event</div>
            <div class="card-value" style="font-size: 16px;" id="card-first"></div>
        </div>
        <div class="card">
            <div class="card-label">Last Generated</div>
            <div class="card-value" style="font-size: 16px;" id="card-generated"></div>
        </div>
    </div>

    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 24px;">
        <div class="table-wrap">
            <div class="table-header"><h3>File Roles</h3></div>
            <div id="role-breakdown" style="padding: 16px;"></div>
        </div>
        <div class="table-wrap">
            <div class="table-header"><h3>Event Types</h3></div>
            <div id="event-breakdown" style="padding: 16px;"></div>
        </div>
    </div>

    <div class="table-wrap">
        <div class="table-header"><h3>Recent Activity</h3></div>
        <table>
            <thead><tr>
                <th>Time</th><th>Event</th><th>File</th><th>Hash</th><th>Actor</th>
            </tr></thead>
            <tbody id="recent-tbody"></tbody>
        </table>
    </div>

    <!-- Upsell on overview -->
    <div class="upsell">
        <div class="upsell-text">
            <strong>Go beyond tracking.</strong>
            <p>Provenance proves what happened. Signal shows you what it means -- classification, enrichment, gap analysis, operational intelligence built on this same chain.</p>
        </div>
        <a class="action-btn signal-btn" href="https://echology.io/signal" target="_blank" rel="noopener">Get Full Signal</a>
    </div>
</div>

<!-- Files Panel -->
<div class="panel" id="panel-files">
    <div class="table-wrap">
        <div class="table-header">
            <h3>File Inventory (<span id="file-count-label"></span>)</h3>
            <input type="text" class="search-input" id="file-search" placeholder="Filter files...">
        </div>
        <table>
            <thead><tr>
                <th data-sort="path">Path <span class="sort-arrow"></span></th>
                <th data-sort="role">Role <span class="sort-arrow"></span></th>
                <th data-sort="size">Size <span class="sort-arrow"></span></th>
                <th data-sort="modified">Modified <span class="sort-arrow"></span></th>
                <th>Hash</th>
            </tr></thead>
            <tbody id="files-tbody"></tbody>
        </table>
        <div class="pagination" id="files-pagination"></div>
    </div>
</div>

<!-- Changes Panel -->
<div class="panel" id="panel-changes">
    <div class="table-wrap">
        <div class="table-header">
            <h3>Change History (<span id="change-count-label"></span>)</h3>
            <input type="text" class="search-input" id="change-search" placeholder="Filter changes...">
        </div>
        <table>
            <thead><tr>
                <th data-sort="seq"># <span class="sort-arrow"></span></th>
                <th data-sort="time">Time <span class="sort-arrow"></span></th>
                <th data-sort="type">Event <span class="sort-arrow"></span></th>
                <th data-sort="file">File <span class="sort-arrow"></span></th>
                <th>Hash</th>
                <th data-sort="actor">Actor <span class="sort-arrow"></span></th>
            </tr></thead>
            <tbody id="changes-tbody"></tbody>
        </table>
        <div class="pagination" id="changes-pagination"></div>
    </div>
</div>

<!-- Harvests Panel -->
<div class="panel" id="panel-harvests">
    <div class="table-wrap">
        <div class="table-header"><h3>Harvest History</h3></div>
        <table>
            <thead><tr>
                <th>ID</th><th>Started</th><th>Total</th>
                <th>New</th><th>Updated</th><th>Deleted</th><th>Skipped</th><th>Duration</th>
            </tr></thead>
            <tbody id="harvests-tbody"></tbody>
        </table>
    </div>
</div>

<!-- Compliance Panel -->
<div class="panel" id="panel-compliance">
    <div class="cards" style="grid-template-columns: repeat(3, 1fr); margin-bottom: 24px;">
        <div class="card">
            <div class="card-label">Frameworks Covered</div>
            <div class="card-value" id="comp-count"></div>
        </div>
        <div class="card">
            <div class="card-label">Chain Integrity</div>
            <div class="card-value" id="comp-chain"></div>
        </div>
        <div class="card">
            <div class="card-label">Evidence Basis</div>
            <div class="card-value" style="font-size: 16px;">SHA-256 hash chain</div>
        </div>
    </div>
    <div class="table-wrap">
        <div class="table-header"><h3>Regulatory Coverage</h3></div>
        <div id="compliance-grid" style="padding: 16px; display: grid; grid-template-columns: repeat(auto-fit, minmax(380px, 1fr)); gap: 16px;"></div>
    </div>

    <!-- Upsell on compliance -->
    <div class="upsell">
        <div class="upsell-text">
            <strong>From audit trail to operational intelligence.</strong>
            <p>Signal adds automated classification, semantic decomposition, and gap analysis on top of this provenance chain. Same data. Deeper insight.</p>
        </div>
        <a class="action-btn signal-btn" href="https://echology.io/signal" target="_blank" rel="noopener">Get Full Signal</a>
    </div>
</div>

<!-- Chain Panel -->
<div class="panel" id="panel-chain">
    <div class="cards" style="grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));">
        <div class="card">
            <div class="card-label">Verification</div>
            <div class="card-value" id="chain-status"></div>
        </div>
        <div class="card">
            <div class="card-label">Total Links</div>
            <div class="card-value" id="chain-links"></div>
        </div>
        <div class="card">
            <div class="card-label">Days of Coverage</div>
            <div class="card-value" id="chain-days"></div>
        </div>
        <div class="card">
            <div class="card-label">Algorithm</div>
            <div class="card-value" style="font-size: 20px;">SHA-256</div>
        </div>
    </div>
    <div class="chain-detail">
        <div class="chain-row">
            <div class="chain-label">Genesis Hash</div>
            <div class="chain-value" id="chain-genesis"></div>
        </div>
        <div class="chain-row">
            <div class="chain-label">Terminal Hash</div>
            <div class="chain-value" id="chain-terminal"></div>
        </div>
        <div class="chain-row">
            <div class="chain-label">First Event</div>
            <div class="chain-value" id="chain-first-event"></div>
        </div>
        <div class="chain-row">
            <div class="chain-label">Target Directory</div>
            <div class="chain-value" id="chain-target"></div>
        </div>
        <div class="chain-row">
            <div class="chain-label">Timestamp Source</div>
            <div class="chain-value">System clock (local). No external timestamping authority.</div>
        </div>
        <div class="chain-row">
            <div class="chain-label">Actor Identity</div>
            <div class="chain-value">OS process identity. Authenticated via local system credentials.</div>
        </div>
    </div>

    <div class="methodology">
        <h3>Verification Methodology</h3>
        <p>Each ledger entry contains a SHA-256 hash computed from the entry's content concatenated with the previous entry's hash. This creates a tamper-evident chain: modifying any record invalidates all subsequent hashes. The genesis entry uses a fixed seed hash.</p>
        <p>Verification recomputes every hash from genesis and compares against stored values. A VALID result means zero divergence across the entire chain. A BROKEN result identifies the exact sequence number where the chain diverges.</p>
        <h3>Independent Verification</h3>
        <p>You do not need to trust this dashboard. To verify independently, run:</p>
        <p><code>signal-provenance verify</code></p>
        <p>This recomputes the full chain from the raw ledger database. The algorithm is deterministic -- the same input always produces the same result, on any machine, at any time. The verification code is open for inspection in the installed package.</p>
    </div>
</div>

</div><!-- container -->

<div id="toast" class="toast"></div>

<div class="footer">
    Signal Provenance v<span id="footer-version"></span> &middot; Generated <span id="footer-time"></span> &middot; Chain is local. Verification is deterministic. Data never leaves your machine.
</div>

<script>
const D = __DASHBOARD_DATA__;

// -- Actions --
const LIVE = location.protocol !== 'file:';

function showToast(html, duration) {
    const t = document.getElementById('toast');
    t.innerHTML = html;
    t.classList.add('show');
    setTimeout(() => { t.classList.remove('show'); }, duration || 3000);
}

function actionBtn(btn, endpoint, label) {
    btn.addEventListener('click', () => {
        if (!LIVE) {
            showToast('Run: <code>signal-provenance dashboard --live</code> for live actions', 4000);
            return;
        }
        const orig = btn.textContent;
        btn.textContent = label + '...';
        btn.disabled = true;
        fetch(endpoint, { method: 'POST' })
            .then(r => r.json())
            .then(data => {
                if (data.ok) {
                    showToast(data.message || 'Done');
                    if (data.refresh) setTimeout(() => location.reload(), 600);
                    if (data.download) {
                        const a = document.createElement('a');
                        a.href = '/api/download?path=' + encodeURIComponent(data.download);
                        a.download = data.download.split('/').pop();
                        a.click();
                    }
                } else {
                    showToast('<span style="color:var(--red)">' + (data.error || 'Failed') + '</span>');
                }
            })
            .catch(err => {
                showToast('<span style="color:var(--red)">Connection lost</span>');
            })
            .finally(() => { btn.textContent = orig; btn.disabled = false; });
    });
}

actionBtn(document.getElementById('btn-harvest'), '/api/harvest', 'Harvesting');
actionBtn(document.getElementById('btn-pdf'), '/api/export-pdf', 'Generating');

// -- Init --
document.getElementById("deployment-name").textContent = D.deployment_name;
document.getElementById("footer-version").textContent = D.version;
document.getElementById("footer-time").textContent = D.generated;

// Status banner
const banner = document.getElementById("status-banner");
banner.className = "status-banner " + (D.chain_valid ? "valid" : "broken");
const coveredCount = (D.compliance || []).filter(c => c.status === "covered").length;
document.getElementById("status-headline").innerHTML =
    'Chain integrity: <span class="status-word ' + (D.chain_valid ? "valid" : "broken") + '">' +
    (D.chain_valid ? "VALID" : "BROKEN") + '</span>. ' +
    (D.chain_valid ? 'All files witnessed. No gaps detected.' : 'Chain break detected. Investigate immediately.');
document.getElementById("stat-frameworks").textContent = coveredCount;
document.getElementById("stat-files").textContent = D.file_count;
document.getElementById("stat-days").textContent = D.chain_days || '<1';
document.getElementById("stat-chain").textContent = D.total_links;

// Compliance strip on overview
const strip = document.getElementById("comp-strip");
strip.innerHTML = (D.compliance || []).map(c =>
    '<div class="comp-mini">' +
    '<div class="comp-dot ' + c.status + '"></div>' +
    '<div class="comp-mini-name">' + c.framework + '</div></div>'
).join("");

// Overview cards
document.getElementById("card-events").textContent = D.event_count;
document.getElementById("card-size").textContent = D.total_size;
document.getElementById("card-first").textContent = D.first_event || 'No events';
document.getElementById("card-generated").textContent = D.generated;

// Chain panel
document.getElementById("chain-status").textContent = D.chain_valid ? "VALID" : "BROKEN";
document.getElementById("chain-status").className = "card-value " + (D.chain_valid ? "valid" : "broken");
document.getElementById("chain-links").textContent = D.total_links;
document.getElementById("chain-days").textContent = D.chain_days || '<1';
document.getElementById("chain-genesis").textContent = D.genesis_hash || "N/A";
document.getElementById("chain-terminal").textContent = D.terminal_hash || "N/A";
document.getElementById("chain-first-event").textContent = D.first_event || "N/A";
document.getElementById("chain-target").textContent = D.target;

// -- Tabs --
document.querySelectorAll(".tab").forEach(tab => {
    tab.addEventListener("click", () => {
        document.querySelectorAll(".tab").forEach(t => t.classList.remove("active"));
        document.querySelectorAll(".panel").forEach(p => p.classList.remove("active"));
        tab.classList.add("active");
        document.getElementById("panel-" + tab.dataset.panel).classList.add("active");
    });
});

// -- Breakdown bars --
function renderBreakdown(containerId, counts, colors) {
    const el = document.getElementById(containerId);
    const max = Math.max(...Object.values(counts), 1);
    const sorted = Object.entries(counts).sort((a, b) => b[1] - a[1]);
    el.innerHTML = sorted.map(([k, v]) => {
        const pct = (v / max * 100).toFixed(1);
        const color = colors[k] || "var(--text-muted)";
        return '<div class="bar-row">' +
            '<div class="bar-label">' + k + '</div>' +
            '<div class="bar-track"><div class="bar-fill" style="width:' + pct + '%;background:' + color + '"></div></div>' +
            '<div class="bar-count">' + v + '</div></div>';
    }).join("");
}

const roleColors = {
    code: "var(--accent)", config: "var(--yellow)", doc: "var(--green)",
    test: "var(--orange)", data: "var(--red)", other: "var(--text-muted)",
    template: "#bc8cff", style: "#ff7b72", document: "var(--green)",
};
const eventColors = {
    created: "var(--green)", modified: "var(--yellow)", deleted: "var(--red)",
    harvest_completed: "var(--accent)", chain_verified: "#bc8cff",
};
renderBreakdown("role-breakdown", D.role_counts, roleColors);
renderBreakdown("event-breakdown", D.event_types, eventColors);

// -- Recent activity (overview, last 10) --
(function() {
    const tbody = document.getElementById("recent-tbody");
    const rows = D.recent.slice(-10).reverse();
    tbody.innerHTML = rows.map(r => {
        const cls = "event-" + r.type.split("_")[0];
        return "<tr>" +
            "<td>" + r.time + "</td>" +
            '<td class="' + cls + '">' + r.type + "</td>" +
            '<td class="path">' + r.file + "</td>" +
            '<td class="hash">' + r.hash + "</td>" +
            "<td>" + r.actor + "</td></tr>";
    }).join("");
})();

// -- Paginated table helper --
function createPaginatedTable(opts) {
    const PAGE_SIZE = 50;
    let data = opts.data.slice();
    let filtered = data;
    let page = 0;
    let sortCol = null;
    let sortAsc = true;

    function render() {
        const start = page * PAGE_SIZE;
        const slice = filtered.slice(start, start + PAGE_SIZE);
        opts.tbody.innerHTML = slice.map(opts.renderRow).join("");
        opts.countLabel.textContent = filtered.length + " items";

        const totalPages = Math.ceil(filtered.length / PAGE_SIZE);
        opts.pagination.innerHTML =
            '<span>Page ' + (page + 1) + ' of ' + Math.max(totalPages, 1) + '</span>' +
            '<div>' +
            '<button class="page-btn" id="' + opts.id + '-prev"' + (page === 0 ? " disabled" : "") + '>&laquo; Prev</button> ' +
            '<button class="page-btn" id="' + opts.id + '-next"' + (page >= totalPages - 1 ? " disabled" : "") + '>Next &raquo;</button>' +
            '</div>';

        document.getElementById(opts.id + "-prev").onclick = () => { if (page > 0) { page--; render(); } };
        document.getElementById(opts.id + "-next").onclick = () => { if (page < totalPages - 1) { page++; render(); } };
    }

    opts.searchInput.addEventListener("input", function() {
        const q = this.value.toLowerCase();
        filtered = q ? data.filter(r => opts.searchFn(r, q)) : data;
        page = 0;
        render();
    });

    opts.tbody.closest("table").querySelectorAll("th[data-sort]").forEach(th => {
        th.addEventListener("click", () => {
            const col = th.dataset.sort;
            if (sortCol === col) { sortAsc = !sortAsc; } else { sortCol = col; sortAsc = true; }
            filtered.sort((a, b) => {
                const va = a[col] || "";
                const vb = b[col] || "";
                if (typeof va === "number") return sortAsc ? va - vb : vb - va;
                return sortAsc ? String(va).localeCompare(String(vb)) : String(vb).localeCompare(String(va));
            });
            page = 0;
            render();
        });
    });

    render();
}

// -- Files table --
function badgeFor(role) {
    return '<span class="badge badge-' + (role || "other") + '">' + (role || "other") + '</span>';
}

createPaginatedTable({
    id: "files",
    data: D.files,
    tbody: document.getElementById("files-tbody"),
    countLabel: document.getElementById("file-count-label"),
    pagination: document.getElementById("files-pagination"),
    searchInput: document.getElementById("file-search"),
    searchFn: (r, q) => r.path.toLowerCase().includes(q) || (r.role || "").includes(q),
    renderRow: r => '<tr class="file-row" data-path="' + r.path + '">' +
        '<td class="path">' + r.path + "</td>" +
        "<td>" + badgeFor(r.role) + "</td>" +
        "<td>" + r.size + "</td>" +
        "<td>" + r.modified + "</td>" +
        '<td class="hash">' + r.hash + "</td></tr>",
});

// File click to open (live mode only)
document.getElementById("files-tbody").addEventListener("click", function(e) {
    const row = e.target.closest(".file-row");
    if (!row || !LIVE) return;
    const path = row.dataset.path;
    fetch("/api/open-file", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({path: path})
    }).then(r => r.json()).then(data => {
        if (data.ok) showToast("Opened " + path, 2000);
        else showToast('<span style="color:var(--red)">' + data.error + '</span>');
    }).catch(() => {});
});

// -- Changes table --
createPaginatedTable({
    id: "changes",
    data: D.recent.slice().reverse(),
    tbody: document.getElementById("changes-tbody"),
    countLabel: document.getElementById("change-count-label"),
    pagination: document.getElementById("changes-pagination"),
    searchInput: document.getElementById("change-search"),
    searchFn: (r, q) => r.file.toLowerCase().includes(q) || r.type.includes(q) || r.actor.includes(q),
    renderRow: r => {
        const cls = "event-" + r.type.split("_")[0];
        return "<tr>" +
            "<td>" + r.seq + "</td>" +
            "<td>" + r.time + "</td>" +
            '<td class="' + cls + '">' + r.type + "</td>" +
            '<td class="path">' + r.file + "</td>" +
            '<td class="hash">' + r.hash + "</td>" +
            "<td>" + r.actor + "</td></tr>";
    },
});

// -- Harvests table --
(function() {
    const tbody = document.getElementById("harvests-tbody");
    tbody.innerHTML = D.harvests.map(h => "<tr>" +
        "<td>" + h.id + "</td>" +
        "<td>" + (h.started_at || "").substring(0, 19) + "</td>" +
        "<td>" + h.files_total + "</td>" +
        '<td class="event-created">' + (h.files_new || 0) + "</td>" +
        '<td class="event-modified">' + (h.files_updated || 0) + "</td>" +
        '<td class="event-deleted">' + (h.files_deleted || 0) + "</td>" +
        "<td>" + (h.files_skipped || 0) + "</td>" +
        "<td>" + (h.duration_ms || 0) + "ms</td></tr>"
    ).join("");
})();

// -- Compliance panel --
(function() {
    const comp = D.compliance || [];
    document.getElementById("comp-count").textContent = comp.filter(c => c.status === "covered").length;
    const chainEl = document.getElementById("comp-chain");
    chainEl.textContent = D.chain_valid ? "VALID" : "BROKEN";
    chainEl.className = "card-value " + (D.chain_valid ? "valid" : "broken");

    const grid = document.getElementById("compliance-grid");
    grid.innerHTML = comp.map(c => {
        const statusLabel = c.status === "covered" ? "Active" : "No Data";
        return '<div class="comp-card ' + c.status + '">' +
            '<div class="comp-status ' + c.status + '">' + statusLabel + '</div>' +
            '<div class="comp-framework">' + c.framework + '</div>' +
            '<div class="comp-desc">' + c.description + '</div>' +
            '<div class="comp-sections">' +
            c.sections.map(s => '<span class="comp-section">' + s + '</span>').join("") +
            '</div></div>';
    }).join("");
})();
</script>
</body>
</html>"""


_SETUP_TEMPLATE = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Signal Provenance</title>
<style>
:root {
    --bg: #0d1117;
    --surface: #161b22;
    --border: #30363d;
    --text: #e6edf3;
    --text-muted: #8b949e;
    --accent: #58a6ff;
    --green: #3fb950;
    --red: #f85149;
}
* { margin: 0; padding: 0; box-sizing: border-box; }
body { background: var(--bg); color: var(--text); font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Helvetica, Arial, sans-serif; }
.container { max-width: 440px; margin: 100px auto; padding: 0 20px; }
.card { background: var(--surface); border: 1px solid var(--border); border-radius: 12px; padding: 36px; }
.card h1 { font-size: 22px; font-weight: 700; margin-bottom: 4px; }
.card .sub { color: var(--text-muted); font-size: 14px; margin-bottom: 28px; }
label { font-size: 11px; color: var(--text-muted); text-transform: uppercase; letter-spacing: 0.8px; display: block; margin-bottom: 6px; font-weight: 600; }
label .optional { text-transform: none; letter-spacing: 0; font-weight: 400; }
input { width: 100%; padding: 10px 14px; background: var(--bg); border: 1px solid var(--border); border-radius: 6px; color: var(--text); font-size: 14px; margin-bottom: 20px; outline: none; transition: border-color 0.2s; }
input:focus { border-color: var(--accent); }
input::placeholder { color: var(--text-muted); opacity: 0.6; }
.code-input { font-family: 'SF Mono', 'Consolas', 'Courier New', monospace; font-size: 16px; letter-spacing: 1px; color: var(--accent); }
.btn { width: 100%; padding: 12px; background: var(--green); color: var(--bg); border: none; border-radius: 6px; font-size: 15px; font-weight: 700; cursor: pointer; transition: opacity 0.2s; }
.btn:hover { opacity: 0.9; }
.btn:disabled { opacity: 0.5; cursor: default; }
.msg { font-size: 13px; margin-top: 14px; padding: 10px 14px; border-radius: 6px; display: none; }
.msg.error { background: rgba(248,81,73,0.1); border: 1px solid var(--red); color: var(--red); }
.msg.success { background: rgba(63,185,80,0.1); border: 1px solid var(--green); color: var(--green); }
.footer { text-align: center; margin-top: 20px; font-size: 12px; color: var(--text-muted); }
</style>
</head>
<body>
<div class="container">
    <div class="card">
        <h1>Signal Provenance</h1>
        <p class="sub">Prove what happened.</p>

        <label>Activation Code <span class="optional">(paste from email, or leave blank for free tier)</span></label>
        <input class="code-input" id="code" placeholder="SP-XXXX-XXXX-XXXX" autocomplete="off" spellcheck="false">

        <label>Folder to Watch</label>
        <input id="folder" placeholder="/path/to/your/project" autocomplete="off" spellcheck="false">

        <button class="btn" id="start">Start</button>
        <div class="msg" id="msg"></div>
    </div>
    <p class="footer">Your data never leaves your machine.</p>
</div>
<script>
(function() {
    var btn = document.getElementById("start");
    var msg = document.getElementById("msg");

    btn.addEventListener("click", function() {
        var code = document.getElementById("code").value.trim();
        var folder = document.getElementById("folder").value.trim();

        if (!folder) {
            msg.className = "msg error";
            msg.textContent = "Enter the path to the folder you want to watch.";
            msg.style.display = "block";
            return;
        }

        btn.disabled = true;
        btn.textContent = "Setting up...";
        msg.style.display = "none";

        fetch("/api/setup", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({code: code, folder: folder}),
        })
        .then(function(res) { return res.json(); })
        .then(function(data) {
            if (data.ok) {
                msg.className = "msg success";
                msg.textContent = data.message;
                msg.style.display = "block";
                btn.textContent = "Redirecting...";
                setTimeout(function() {
                    window.location.href = data.redirect || "/";
                }, 1000);
            } else {
                msg.className = "msg error";
                msg.textContent = data.error;
                msg.style.display = "block";
                btn.disabled = false;
                btn.textContent = "Start";
            }
        })
        .catch(function() {
            msg.className = "msg error";
            msg.textContent = "Connection error. Is the server running?";
            msg.style.display = "block";
            btn.disabled = false;
            btn.textContent = "Start";
        });
    });
})();
</script>
</body>
</html>"""
