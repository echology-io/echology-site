"""Signal Provenance CLI -- hash-chained file provenance from the terminal.

Usage:
    signal-provenance watch [target] [options]   # Full setup in one command
    signal-provenance init [path]
    signal-provenance harvest [path] [-v]
    signal-provenance verify [path]
    signal-provenance history <file> [path]
    signal-provenance snapshot <timestamp> [path]
    signal-provenance stats [path]
    signal-provenance log [path] [-n LIMIT]
    signal-provenance dashboard [path]
    signal-provenance export [--format pdf|json]
    signal-provenance activate <license.lic>
    signal-provenance license
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from signal_provenance import __version__


def _resolve_target(path_arg: str | None) -> Path:
    """Resolve the target directory from a CLI argument or cwd."""
    if path_arg:
        return Path(path_arg).expanduser().resolve()
    return Path.cwd()


def cmd_init(args):
    """Initialize provenance tracking for a directory."""
    from signal_provenance.db import get_connection, init_db, witness

    target = _resolve_target(args.path)
    if not target.is_dir():
        print(f"Not a directory: {target}")
        sys.exit(1)

    prov_dir = target / ".signal-provenance"
    existed = prov_dir.exists()

    conn = get_connection(target)
    init_db(conn)
    conn.close()

    if existed:
        print(f"Provenance already initialized: {prov_dir}")
    else:
        witness(target, "harvest_started", "provenance.init", {
            "action": "initialized",
            "target": str(target),
        })
        print(f"Provenance initialized: {prov_dir}")
        print(f"  Database: {prov_dir / 'provenance.db'}")
        print(f"  Ledger:   {prov_dir / 'ledger.db'}")
        print(f"\nRun 'signal-provenance harvest' to start witnessing.")


def cmd_harvest(args):
    """Harvest file metadata and record provenance.

    Supports local directories and cloud storage URIs:
      signal-provenance harvest /local/path
      signal-provenance harvest s3://bucket/prefix
      signal-provenance harvest sharepoint://SiteName/Library
      signal-provenance harvest gdrive://folder-id
    """
    from signal_provenance.config import load_config
    from signal_provenance.db import get_connection, init_db
    from signal_provenance.harvest import auto_report, harvest
    from signal_provenance.providers import get_provider

    target_arg = args.path
    is_cloud = target_arg and any(
        target_arg.startswith(s) for s in ("s3://", "sharepoint://", "gdrive://")
    )

    if is_cloud:
        target = Path.cwd()
        prov_dir = target / ".signal-provenance"
        if not prov_dir.exists():
            print(f"Not initialized. Run: signal-provenance init")
            sys.exit(1)
        cfg = load_config(target)
        provider = get_provider(target_arg,
                                exclude=cfg.get("exclude"),
                                include=cfg.get("include"))
        label = target_arg
    else:
        target = _resolve_target(target_arg)
        if not target.is_dir():
            print(f"Not a directory: {target}")
            sys.exit(1)
        prov_dir = target / ".signal-provenance"
        if not prov_dir.exists():
            print(f"Not initialized. Run: signal-provenance init {target}")
            sys.exit(1)
        cfg = load_config(target)
        exclude = cfg.get("exclude") or []
        include = cfg.get("include") or []
        provider = get_provider(str(target), exclude=exclude, include=include)
        label = str(target)

    print(f"Harvesting: {label}")
    conn = get_connection(target)
    init_db(conn)
    summary = harvest(conn, target, verbose=args.verbose, provider=provider)

    # Auto-report if flag set or config says so
    if getattr(args, "auto_report", False):
        reports = auto_report(conn, target)
        if reports:
            for r in reports:
                print(f"  Report: {r}")

    conn.close()

    print(f"\n  {summary['files_total']} files "
          f"({summary['files_new']} new, "
          f"{summary['files_updated']} updated, "
          f"{summary['files_skipped']} unchanged, "
          f"{summary['files_deleted']} deleted) "
          f"in {summary['duration_ms']}ms")


def cmd_verify(args):
    """Verify the Aletheia ledger chain integrity."""
    from signal_provenance.db import verify_chain

    target = _resolve_target(args.path)
    result = verify_chain(target)

    if result.get("error"):
        print(f"Verify: {result['error']}")
        sys.exit(1)

    print(f"Ledger: {target}")
    print(f"  Entries: {result['entries']}")
    print(f"  First:   seq={result['first']['seq']} "
          f"{result['first']['timestamp']}")
    print(f"  Last:    seq={result['last']['seq']} "
          f"{result['last']['timestamp']}")
    if result["valid"]:
        print(f"  Chain:   VALID (all {result['entries']} entries linked)")
    else:
        print(f"  CHAIN BREAKS: {len(result['breaks'])} "
              f"at seq {result['breaks'][:10]}")
        sys.exit(1)


def cmd_history(args):
    """Show change history for a specific file."""
    from signal_provenance.db import get_connection, get_file_history

    target = _resolve_target(args.path)
    conn = get_connection(target)
    history = get_file_history(conn, args.file)
    conn.close()

    if not history:
        print(f"No history for: {args.file}")
        sys.exit(1)

    print(f"History for {args.file} ({len(history)} snapshots):\n")
    for h in history:
        actor = f"  by {h['change_actor']}" if h.get("change_actor") else ""
        reason = f"  ({h['change_reason']})" if h.get("change_reason") else ""
        print(f"  {h['perceived_at']}  {h['change_type']:<10s}  "
              f"hash={h['content_hash'][:16]}  "
              f"{h.get('size_bytes', '?')}B{actor}{reason}")


def cmd_snapshot(args):
    """Reconstruct the file environment at a point in time."""
    from signal_provenance.db import get_connection, get_environment_at_time

    target = _resolve_target(args.path)
    conn = get_connection(target)
    files = get_environment_at_time(conn, args.timestamp)
    conn.close()

    if not files:
        print(f"No files at {args.timestamp}")
        sys.exit(1)

    print(f"Environment at {args.timestamp}: {len(files)} files\n")
    for f in files:
        marker = {
            "created": "+", "modified": "~",
            "unchanged": " ", "deleted": "-",
        }.get(f["change_type"], "?")
        print(f"  {marker} {f['file_path']:<60s} "
              f"{f.get('content_hash', '')[:16]}")


def cmd_stats(args):
    """Show ledger and provenance statistics."""
    from signal_provenance.db import get_connection, get_ledger_stats

    target = _resolve_target(args.path)

    # Database stats
    conn = get_connection(target)
    files = conn.execute("SELECT count(*) FROM file_metadata").fetchone()[0]
    snapshots = conn.execute(
        "SELECT count(*) FROM artifact_snapshots"
    ).fetchone()[0]
    created = conn.execute(
        "SELECT count(*) FROM artifact_snapshots "
        "WHERE change_type = 'created'"
    ).fetchone()[0]
    modified = conn.execute(
        "SELECT count(*) FROM artifact_snapshots "
        "WHERE change_type = 'modified'"
    ).fetchone()[0]
    deleted = conn.execute(
        "SELECT count(*) FROM artifact_snapshots "
        "WHERE change_type = 'deleted'"
    ).fetchone()[0]
    harvests = conn.execute(
        "SELECT count(*) FROM metadata_harvests"
    ).fetchone()[0]
    conn.close()

    print(f"Provenance: {target}\n")
    print(f"  Files tracked:    {files}")
    print(f"  Total snapshots:  {snapshots}")
    print(f"    created:        {created}")
    print(f"    modified:       {modified}")
    print(f"    deleted:        {deleted}")
    print(f"  Harvests:         {harvests}")

    # Ledger stats
    lstats = get_ledger_stats(target)
    if lstats:
        print(f"\n  Ledger entries:   {lstats['total']}")
        if lstats["first"]:
            print(f"  First entry:      {lstats['first']}")
        if lstats["last"]:
            print(f"  Last entry:       {lstats['last']}")
        if lstats["events"]:
            print(f"\n  By event type:")
            for etype, count in lstats["events"].items():
                print(f"    {etype:<30s} {count:>5d}")


def cmd_log(args):
    """Show recent ledger entries."""
    from signal_provenance.db import get_ledger_history

    target = _resolve_target(args.path)
    entries = get_ledger_history(target, limit=args.limit)

    if not entries:
        print("No ledger entries.")
        sys.exit(1)

    print(f"Ledger (last {len(entries)} entries):\n")
    for e in entries:
        action = e["summary"].get("action", e["event_type"])
        fp = e["summary"].get("file_path", "")
        detail = f"  {fp}" if fp else ""
        print(f"  [{e['seq']:>4d}] {e['timestamp'][:19]} "
              f"{e['event_type']:<20s}{detail}")


def cmd_export(args):
    """Export compliance report (JSON or PDF)."""
    from signal_provenance.license import require_license
    from signal_provenance.db import get_connection

    require_license()

    target = _resolve_target(args.path)
    prov_dir = target / ".signal-provenance"
    if not prov_dir.exists():
        print(f"Not initialized. Run: signal-provenance init {target}")
        sys.exit(1)

    conn = get_connection(target)

    fmt = args.format
    if args.output:
        output = Path(args.output)
    else:
        suffix = ".json" if fmt == "json" else ".pdf"
        output = Path(f"provenance-report{suffix}")

    if fmt == "json":
        from signal_provenance.export import export_json
        export_json(conn, target, output, start=args.start, end=args.end)
    else:
        from signal_provenance.export import export_pdf
        export_pdf(conn, target, output, start=args.start, end=args.end)

    conn.close()
    print(f"Report exported: {output}")


def cmd_dashboard(args):
    """Generate or serve an interactive HTML dashboard."""
    target = _resolve_target(args.path)
    prov_dir = target / ".signal-provenance"
    if not prov_dir.exists():
        print(f"Not initialized. Run: signal-provenance init {target}")
        sys.exit(1)

    if args.live:
        from signal_provenance.dashboard import serve_dashboard
        serve_dashboard(target, port=args.port)
    else:
        from signal_provenance.db import get_connection
        from signal_provenance.dashboard import export_dashboard
        conn = get_connection(target)
        if args.output:
            output = Path(args.output)
        else:
            output = prov_dir / "reports" / "dashboard.html"
            output.parent.mkdir(parents=True, exist_ok=True)
        export_dashboard(conn, target, output)
        conn.close()
        print(f"Dashboard: {output}")


def cmd_activate(args):
    """Activate a license file."""
    from signal_provenance.license import activate, LicenseError

    try:
        lic = activate(args.license_file)
        print(f"License activated.")
        print(f"  Customer: {lic.cid} ({lic.email})")
        print(f"  Tier:     {lic.tier}")
        print(f"  Expires:  {lic.expires}")
    except LicenseError as e:
        print(f"Activation failed: {e}")
        sys.exit(1)


def cmd_license_status(args):
    """Show current license status."""
    from signal_provenance.license import check_license, LICENSE_FILE

    lic = check_license()
    if lic is None:
        print("No valid license found.")
        print(f"  Expected: {LICENSE_FILE}")
        print("\nFree tier: init, harvest, verify, history, stats, log")
        print("Pro tier:  + watch, export, snapshot, auto-reports")
        print("\nPurchase: https://echology.io/provenance")
    else:
        print(f"License: VALID")
        print(f"  Customer: {lic.cid} ({lic.email})")
        print(f"  Tier:     {lic.tier}")
        print(f"  Issued:   {lic.issued}")
        print(f"  Expires:  {lic.expires}")


def cmd_watch(args):
    """Set up continuous provenance monitoring with one command.

    Initializes tracking, runs first harvest, verifies the chain,
    generates reports, and schedules recurring harvests via cron.
    """
    import shutil
    import subprocess
    from signal_provenance.config import load_config, save_config
    from signal_provenance.db import get_connection, init_db, witness
    from signal_provenance.harvest import auto_report, harvest
    from signal_provenance.providers import get_provider

    target_arg = args.target
    is_cloud = target_arg and any(
        target_arg.startswith(s) for s in ("s3://", "sharepoint://", "gdrive://")
    )

    if is_cloud:
        target = Path.cwd()
        provider_type = target_arg.split("://")[0]
    else:
        target = Path(target_arg).expanduser().resolve() if target_arg else Path.cwd()
        if not target.is_dir():
            print(f"Not a directory: {target}")
            sys.exit(1)
        provider_type = "local"

    print(f"Signal Provenance v{__version__}\n")

    # -- Init if needed --
    prov_dir = target / ".signal-provenance"
    if not prov_dir.exists():
        conn = get_connection(target)
        init_db(conn)
        witness(target, "harvest_started", "provenance.init", {
            "action": "initialized",
            "target": str(target),
        })
        conn.close()
        print(f"  Initialized: {prov_dir}")
    else:
        print(f"  Database: {prov_dir}")

    # -- Build and save config --
    exclude = args.exclude or []
    include = args.include or []
    interval = args.interval
    report_to = args.report_to or str(prov_dir / "reports")
    report_format = args.report_format

    deployment_name = getattr(args, "name", None) or ""

    cfg = {
        "target": target_arg or str(target),
        "provider": provider_type,
        "exclude": exclude,
        "include": include,
        "interval_minutes": interval,
        "report_to": report_to,
        "report_format": report_format,
        "deployment_name": deployment_name,
    }
    save_config(target, cfg)

    if exclude:
        print(f"  Excluding: {', '.join(exclude)}")
    if include:
        print(f"  Including: {', '.join(include)}")

    # -- Resolve provider --
    if is_cloud:
        provider = get_provider(target_arg, exclude=exclude, include=include)
    else:
        provider = get_provider(str(target), exclude=exclude, include=include)

    # -- First harvest --
    print(f"\n  Harvesting: {target_arg or target}")
    conn = get_connection(target)
    init_db(conn)
    summary = harvest(conn, target, verbose=args.verbose, provider=provider)

    print(f"    {summary['files_total']} files "
          f"({summary['files_new']} new, "
          f"{summary['files_updated']} updated, "
          f"{summary['files_skipped']} unchanged, "
          f"{summary['files_deleted']} deleted) "
          f"in {summary['duration_ms']}ms")

    # -- Verify chain --
    from signal_provenance.db import verify_chain
    result = verify_chain(target)
    if result.get("valid"):
        print(f"\n  Chain: VALID ({result['entries']} entries)")
    elif result.get("valid") is False:
        print(f"\n  Chain: BROKEN ({len(result['breaks'])} breaks)")
    else:
        print(f"\n  Chain: {result.get('error', 'unknown')}")

    # -- Auto-report --
    from signal_provenance.license import check_license
    reports = auto_report(conn, target)
    has_license = check_license() is not None
    has_exports = any(str(r).endswith((".json", ".pdf")) for r in reports)

    if reports:
        print(f"\n  Reports:")
        for r in reports:
            print(f"    {r}")
        dash_link = Path(report_to) / "dashboard.html"
        if dash_link.exists() or dash_link.is_symlink():
            print(f"    Dashboard: {dash_link}")
        if not has_exports:
            print(f"    PDF/JSON: unlock with pro license (echology.io/provenance)")

    conn.close()

    # -- Schedule via cron (if not --once) --
    if not args.once:
        _schedule_cron(target, target_arg, interval, is_cloud)

    print(f"\n  Done. Your chain is building.")
    print()
    print("  Next steps:")
    print("    signal-provenance dashboard --live    Open live dashboard")
    if has_license:
        print("    signal-provenance export -f pdf       Export compliance report")
    else:
        print("    signal-provenance activate <file>     Activate license for compliance exports")
    print("    signal-provenance verify              Verify chain integrity")


def _schedule_cron(target: Path, target_arg: str | None, interval: int,
                   is_cloud: bool) -> None:
    """Add a cron entry for recurring harvest + auto-report."""
    import shutil
    import subprocess

    sp_bin = shutil.which("signal-provenance")
    if not sp_bin:
        # Try to find it relative to current Python
        sp_bin = str(Path(sys.executable).parent / "signal-provenance")
        if not Path(sp_bin).exists():
            print(f"\n  Schedule: could not locate signal-provenance binary")
            return

    if is_cloud:
        harvest_target = target_arg
    else:
        harvest_target = str(target)

    cron_cmd = f"{sp_bin} harvest --auto-report {harvest_target}"
    log_dir = Path.home() / ".local" / "log"
    log_dir.mkdir(parents=True, exist_ok=True)
    log_file = log_dir / "signal-provenance.log"

    cron_line = f"*/{interval} * * * * {cron_cmd} >> {log_file} 2>&1"

    # Check if already scheduled
    try:
        existing = subprocess.run(
            ["crontab", "-l"], capture_output=True, text=True
        )
        current_crontab = existing.stdout if existing.returncode == 0 else ""
    except FileNotFoundError:
        print(f"\n  Schedule: crontab not available. Add manually:")
        print(f"    {cron_line}")
        return

    # Check for existing signal-provenance entry for this target
    marker = f"signal-provenance harvest"
    if marker in current_crontab and harvest_target in current_crontab:
        print(f"\n  Schedule: already configured (every {interval}min)")
        return

    # Safe append (never echo pipe)
    new_crontab = current_crontab.rstrip("\n") + "\n" + cron_line + "\n"
    result = subprocess.run(
        ["crontab", "-"], input=new_crontab, capture_output=True, text=True
    )

    if result.returncode == 0:
        print(f"\n  Schedule: every {interval} minutes via cron")
        print(f"    Log: {log_file}")
    else:
        print(f"\n  Schedule: crontab write failed. Add manually:")
        print(f"    {cron_line}")


def main():
    parser = argparse.ArgumentParser(
        prog="signal-provenance",
        description="Hash-chained file provenance. Prove what happened.",
    )
    parser.add_argument(
        "--version", action="version",
        version=f"signal-provenance {__version__}",
    )
    sub = parser.add_subparsers(dest="command")

    # init
    p = sub.add_parser("init", help="Initialize provenance tracking")
    p.add_argument("path", nargs="?", help="Directory to track (default: cwd)")

    # harvest
    p = sub.add_parser("harvest", help="Harvest filesystem state")
    p.add_argument("path", nargs="?", help="Directory or cloud URI (default: cwd)")
    p.add_argument("-v", "--verbose", action="store_true")
    p.add_argument("--auto-report", action="store_true",
                   help="Generate reports after harvest (uses saved config)")

    # verify
    p = sub.add_parser("verify", help="Verify ledger chain integrity")
    p.add_argument("path", nargs="?", help="Directory (default: cwd)")

    # history
    p = sub.add_parser("history", help="File change history")
    p.add_argument("file", help="Relative file path")
    p.add_argument("path", nargs="?", help="Directory (default: cwd)")

    # snapshot
    p = sub.add_parser("snapshot", help="Reconstruct environment at time")
    p.add_argument("timestamp", help="ISO-8601 timestamp")
    p.add_argument("path", nargs="?", help="Directory (default: cwd)")

    # stats
    p = sub.add_parser("stats", help="Show provenance statistics")
    p.add_argument("path", nargs="?", help="Directory (default: cwd)")

    # log
    p = sub.add_parser("log", help="Show recent ledger entries")
    p.add_argument("path", nargs="?", help="Directory (default: cwd)")
    p.add_argument("-n", "--limit", type=int, default=20,
                   help="Number of entries (default: 20)")

    # export (pro)
    p = sub.add_parser("export", help="Export compliance report (pro)")
    p.add_argument("--format", "-f", choices=["json", "pdf"], default="json",
                   help="Output format (default: json)")
    p.add_argument("--output", "-o", help="Output file path")
    p.add_argument("--start", help="Period start (ISO-8601)")
    p.add_argument("--end", help="Period end (ISO-8601)")
    p.add_argument("path", nargs="?", help="Directory (default: cwd)")

    # dashboard
    p = sub.add_parser("dashboard", help="Generate or serve interactive dashboard")
    p.add_argument("--output", "-o", help="Output file path")
    p.add_argument("--live", action="store_true",
                   help="Serve live dashboard with action buttons")
    p.add_argument("--port", type=int, default=9111,
                   help="Port for live server (default: 9111)")
    p.add_argument("path", nargs="?", help="Directory (default: cwd)")

    # watch (the magic command)
    p = sub.add_parser("watch",
                       help="Start continuous provenance (init + harvest + schedule + reports)")
    p.add_argument("target", nargs="?",
                   help="Directory or cloud URI (s3://, sharepoint://, gdrive://)")
    p.add_argument("--exclude", action="append", default=[],
                   help="Exclude directories/patterns (repeatable)")
    p.add_argument("--include", action="append", default=[],
                   help="Include only matching patterns (repeatable)")
    p.add_argument("--interval", type=int, default=60,
                   help="Harvest interval in minutes (default: 60)")
    p.add_argument("--report-to",
                   help="Directory for auto-generated reports")
    p.add_argument("--report-format", choices=["pdf", "json", "both"],
                   default="both", help="Report format (default: both)")
    p.add_argument("--name",
                   help="Deployment name (e.g. 'Acme Corp - Engineering')")
    p.add_argument("--once", action="store_true",
                   help="Run a single harvest and exit (no scheduling)")
    p.add_argument("-v", "--verbose", action="store_true")

    # activate
    p = sub.add_parser("activate", help="Activate a license")
    p.add_argument("license_file", help="Activation code (SP-XXXX-XXXX-XXXX) or path to .lic file")

    # license
    sub.add_parser("license", help="Show license status")

    args = parser.parse_args()
    if not args.command:
        from signal_provenance.dashboard import serve_dashboard
        serve_dashboard(target_dir=None)
        return

    commands = {
        "init": cmd_init,
        "harvest": cmd_harvest,
        "verify": cmd_verify,
        "history": cmd_history,
        "snapshot": cmd_snapshot,
        "stats": cmd_stats,
        "log": cmd_log,
        "export": cmd_export,
        "dashboard": cmd_dashboard,
        "watch": cmd_watch,
        "activate": cmd_activate,
        "license": cmd_license_status,
    }
    commands[args.command](args)


if __name__ == "__main__":
    main()
