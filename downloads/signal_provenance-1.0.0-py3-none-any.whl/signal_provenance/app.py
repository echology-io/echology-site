"""Signal Provenance desktop app -- no terminal required."""

import sys
import threading
import webbrowser
import tkinter as tk
from tkinter import filedialog, messagebox
from pathlib import Path


# -- Colors (dark theme matching dashboard) --
BG = "#0d1117"
SURFACE = "#161b22"
BORDER = "#30363d"
TEXT = "#e6edf3"
TEXT_MUTED = "#8b949e"
ACCENT = "#58a6ff"
GREEN = "#3fb950"
RED = "#f85149"


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Signal Provenance")
        self.configure(bg=BG)
        self.geometry("480x520")
        self.resizable(False, False)

        self._server_thread = None
        self._target = None
        self._licensed = False

        self._build_ui()
        self._check_license()

    def _build_ui(self):
        # Header
        header = tk.Frame(self, bg=BG)
        header.pack(fill="x", padx=28, pady=(28, 0))
        tk.Label(
            header, text="Signal Provenance", font=("Helvetica", 22, "bold"),
            fg=TEXT, bg=BG,
        ).pack(anchor="w")
        tk.Label(
            header, text="Prove what happened.",
            font=("Helvetica", 12), fg=TEXT_MUTED, bg=BG,
        ).pack(anchor="w", pady=(2, 0))

        # Status indicator
        self._status_frame = tk.Frame(self, bg=SURFACE, highlightbackground=BORDER,
                                       highlightthickness=1)
        self._status_frame.pack(fill="x", padx=28, pady=(16, 0), ipady=8)
        self._status_label = tk.Label(
            self._status_frame, text="Checking license...",
            font=("Helvetica", 11), fg=TEXT_MUTED, bg=SURFACE,
        )
        self._status_label.pack(padx=12)

        # --- Single setup flow ---
        setup = tk.Frame(self, bg=BG)
        setup.pack(fill="x", padx=28, pady=(20, 0))

        # Activation code
        tk.Label(
            setup, text="Activation Code", font=("Helvetica", 11, "bold"),
            fg=TEXT, bg=BG,
        ).pack(anchor="w")
        self._code_var = tk.StringVar()
        self._code_entry = tk.Entry(
            setup, textvariable=self._code_var,
            font=("Courier", 14), fg=ACCENT, bg=SURFACE,
            insertbackground=TEXT, relief="flat", bd=0,
            highlightbackground=BORDER, highlightthickness=1,
        )
        self._code_entry.pack(fill="x", pady=(4, 0), ipady=6)

        # Folder
        tk.Label(
            setup, text="Folder to Watch", font=("Helvetica", 11, "bold"),
            fg=TEXT, bg=BG,
        ).pack(anchor="w", pady=(16, 0))

        folder_row = tk.Frame(setup, bg=BG)
        folder_row.pack(fill="x", pady=(4, 0))

        self._folder_var = tk.StringVar(value="")
        self._folder_entry = tk.Entry(
            folder_row, textvariable=self._folder_var,
            font=("Helvetica", 11), fg=TEXT_MUTED, bg=SURFACE,
            insertbackground=TEXT, relief="flat", bd=0,
            highlightbackground=BORDER, highlightthickness=1,
        )
        self._folder_entry.pack(side="left", fill="x", expand=True, ipady=6)

        tk.Button(
            folder_row, text="Browse", font=("Helvetica", 10),
            fg=TEXT, bg=SURFACE, activebackground=BORDER,
            relief="flat", bd=0, padx=14, pady=6,
            highlightbackground=BORDER, highlightthickness=1,
            command=self._browse,
        ).pack(side="right", padx=(8, 0))

        # Go button -- the only action button
        self._go_btn = tk.Button(
            setup, text="Start", font=("Helvetica", 14, "bold"),
            fg=BG, bg=GREEN, activebackground="#2ea043", activeforeground=BG,
            relief="flat", bd=0, pady=10,
            command=self._go,
        )
        self._go_btn.pack(fill="x", pady=(20, 0), ipady=2)

        # Log area
        log_frame = tk.Frame(self, bg=BG)
        log_frame.pack(fill="both", expand=True, padx=28, pady=(16, 28))

        self._log = tk.Text(
            log_frame, font=("Courier", 9), fg=TEXT_MUTED, bg=SURFACE,
            relief="flat", bd=0, highlightbackground=BORDER,
            highlightthickness=1, wrap="word", height=6,
        )
        self._log.pack(fill="both", expand=True)
        self._log.configure(state="disabled")

    def _log_msg(self, msg: str):
        self._log.configure(state="normal")
        self._log.insert("end", msg + "\n")
        self._log.see("end")
        self._log.configure(state="disabled")

    def _set_status(self, text: str, color: str = TEXT_MUTED):
        self._status_label.configure(text=text, fg=color)

    def _check_license(self):
        try:
            from signal_provenance.license import check_license
            lic = check_license()
            if lic:
                self._licensed = True
                self._set_status(f"Licensed: {lic.cid} ({lic.tier})", GREEN)
                self._log_msg(f"License valid: {lic.cid}")
            else:
                self._set_status("Paste your activation code, pick a folder, hit Start.", TEXT_MUTED)
        except Exception as e:
            self._set_status(f"License error: {e}", RED)

    def _browse(self):
        folder = filedialog.askdirectory(title="Select folder to watch")
        if folder:
            self._target = Path(folder)
            self._folder_var.set(str(self._target))

    def _go(self):
        """Single button: activate (if needed) -> harvest -> dashboard -> browser."""
        code = self._code_var.get().strip()
        folder = self._folder_var.get().strip()

        if not folder:
            messagebox.showwarning("Signal Provenance", "Pick a folder to watch.")
            return

        self._target = Path(folder)
        if not self._target.is_dir():
            messagebox.showerror("Signal Provenance", f"Not a valid folder: {folder}")
            return

        self._go_btn.configure(state="disabled", text="Working...", bg=BORDER)
        self._log_msg("Starting...")

        def do_work():
            try:
                # Step 1: Activate if code provided and not yet licensed
                if code and not self._licensed:
                    self.after(0, lambda: self._log_msg(f"Activating: {code}"))
                    from signal_provenance.license import activate
                    lic = activate(code)
                    self._licensed = True
                    self.after(0, lambda: self._set_status(
                        f"Licensed: {lic.cid} ({lic.tier})", GREEN
                    ))
                    self.after(0, lambda: self._log_msg(f"Activated: {lic.cid}"))

                # Step 2: Init + harvest
                from signal_provenance.db import get_connection, init_db
                from signal_provenance.harvest import harvest, auto_report
                from signal_provenance.providers.local import LocalProvider

                target = self._target
                prov_dir = target / ".signal-provenance"
                prov_dir.mkdir(parents=True, exist_ok=True)
                conn = get_connection(target)
                init_db(conn)

                self.after(0, lambda: self._log_msg("Harvesting files..."))
                provider = LocalProvider(target)
                summary = harvest(conn, target, provider=provider)
                self.after(0, lambda: self._log_msg(
                    f"Harvested: {summary['files_total']} files "
                    f"({summary['files_new']} new, "
                    f"{summary['files_updated']} updated) "
                    f"in {summary['duration_ms']}ms"
                ))

                # Step 3: Verify
                from signal_provenance.db import verify_chain
                result = verify_chain(target)
                valid = result.get("valid", False)
                entries = result.get("entries", 0)
                self.after(0, lambda: self._log_msg(
                    f"Chain: {'VALID' if valid else 'BROKEN'} ({entries} entries)"
                ))

                # Step 4: Reports
                reports = auto_report(conn, target)
                for r in reports:
                    self.after(0, lambda r=r: self._log_msg(f"Report: {r}"))

                conn.close()

                # Step 5: Start dashboard and open browser
                self.after(0, self._start_dashboard_and_open)

            except Exception as e:
                self.after(0, lambda: self._on_error(str(e)))

        threading.Thread(target=do_work, daemon=True).start()

    def _start_dashboard_and_open(self):
        self._go_btn.configure(text="Running", bg=GREEN, state="disabled")
        self._log_msg("Starting dashboard...")

        def run_server():
            try:
                from signal_provenance.dashboard import serve_dashboard
                from signal_provenance.db import get_connection
                conn = get_connection(self._target)
                serve_dashboard(conn, self._target, port=9111, open_browser=False)
            except Exception as e:
                self.after(0, lambda: self._log_msg(f"Dashboard error: {e}"))

        self._server_thread = threading.Thread(target=run_server, daemon=True)
        self._server_thread.start()

        # Wait for server to be ready, then open browser
        def try_open(attempts=0):
            if attempts > 20:
                self._log_msg("Dashboard failed to start.")
                return
            try:
                import urllib.request
                urllib.request.urlopen("http://localhost:9111", timeout=1)
                self._set_status("Dashboard running on localhost:9111", GREEN)
                self._log_msg("Dashboard ready. Opening browser...")
                webbrowser.open("http://localhost:9111")
            except Exception:
                self.after(250, lambda: try_open(attempts + 1))

        self.after(500, try_open)

    def _on_error(self, msg: str):
        self._go_btn.configure(state="normal", text="Start", bg=GREEN)
        self._log_msg(f"Error: {msg}")
        messagebox.showerror("Error", msg)

    def destroy(self):
        super().destroy()


def main():
    app = App()
    app.mainloop()


if __name__ == "__main__":
    main()
