"""Signal Provenance desktop app -- no terminal required."""

import os
import sys
import threading
import webbrowser
import tkinter as tk
from tkinter import filedialog, messagebox
from pathlib import Path


# -- Colors (dark theme matching dashboard) --
BG = "#0d1117"
SURFACE = "#161b22"
BORDER = "#30363d"
TEXT = "#e6edf3"
TEXT_MUTED = "#8b949e"
ACCENT = "#58a6ff"
GREEN = "#3fb950"
RED = "#f85149"


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Signal Provenance")
        self.configure(bg=BG)
        self.geometry("520x580")
        self.resizable(False, False)

        self._server_thread = None
        self._watching = False
        self._target = None

        self._build_ui()
        self._check_license()

    def _build_ui(self):
        # Header
        header = tk.Frame(self, bg=BG)
        header.pack(fill="x", padx=24, pady=(24, 0))
        tk.Label(
            header, text="Signal Provenance", font=("Helvetica", 20, "bold"),
            fg=TEXT, bg=BG,
        ).pack(anchor="w")
        tk.Label(
            header, text="Hash-chained file provenance. Prove what happened.",
            font=("Helvetica", 11), fg=TEXT_MUTED, bg=BG,
        ).pack(anchor="w", pady=(2, 0))

        # Status bar
        self._status_frame = tk.Frame(self, bg=SURFACE, highlightbackground=BORDER,
                                       highlightthickness=1)
        self._status_frame.pack(fill="x", padx=24, pady=(16, 0), ipady=8)
        self._status_label = tk.Label(
            self._status_frame, text="Checking license...",
            font=("Helvetica", 11), fg=TEXT_MUTED, bg=SURFACE,
        )
        self._status_label.pack(padx=12)

        # Activation section
        act_frame = tk.LabelFrame(
            self, text="  Activate  ", font=("Helvetica", 11),
            fg=TEXT_MUTED, bg=BG, bd=1, relief="groove",
            highlightbackground=BORDER, highlightcolor=BORDER,
        )
        act_frame.pack(fill="x", padx=24, pady=(16, 0))

        code_row = tk.Frame(act_frame, bg=BG)
        code_row.pack(fill="x", padx=12, pady=(8, 4))
        tk.Label(
            code_row, text="Activation Code:", font=("Helvetica", 11),
            fg=TEXT, bg=BG,
        ).pack(side="left")

        self._code_var = tk.StringVar()
        self._code_entry = tk.Entry(
            code_row, textvariable=self._code_var,
            font=("JetBrains Mono", 13), fg=TEXT, bg=SURFACE,
            insertbackground=TEXT, relief="flat", bd=0,
            highlightbackground=BORDER, highlightthickness=1, width=20,
        )
        self._code_entry.pack(side="left", padx=(8, 0), ipady=4)

        self._activate_btn = tk.Button(
            act_frame, text="Activate", font=("Helvetica", 11, "bold"),
            fg=BG, bg=ACCENT, activebackground="#4090e0", activeforeground=BG,
            relief="flat", bd=0, padx=16, pady=4,
            command=self._activate,
        )
        self._activate_btn.pack(padx=12, pady=(4, 12))

        # Watch section
        watch_frame = tk.LabelFrame(
            self, text="  Watch  ", font=("Helvetica", 11),
            fg=TEXT_MUTED, bg=BG, bd=1, relief="groove",
            highlightbackground=BORDER, highlightcolor=BORDER,
        )
        watch_frame.pack(fill="x", padx=24, pady=(16, 0))

        folder_row = tk.Frame(watch_frame, bg=BG)
        folder_row.pack(fill="x", padx=12, pady=(8, 4))

        self._folder_var = tk.StringVar(value="No folder selected")
        tk.Label(
            folder_row, textvariable=self._folder_var,
            font=("Helvetica", 10), fg=TEXT_MUTED, bg=BG,
            anchor="w", wraplength=350,
        ).pack(side="left", fill="x", expand=True)

        tk.Button(
            folder_row, text="Browse", font=("Helvetica", 10),
            fg=TEXT, bg=SURFACE, activebackground=BORDER,
            relief="flat", bd=0, padx=12, pady=2,
            highlightbackground=BORDER, highlightthickness=1,
            command=self._browse,
        ).pack(side="right")

        btn_row = tk.Frame(watch_frame, bg=BG)
        btn_row.pack(fill="x", padx=12, pady=(4, 12))

        self._start_btn = tk.Button(
            btn_row, text="Start Watching", font=("Helvetica", 12, "bold"),
            fg=BG, bg=GREEN, activebackground="#2ea043", activeforeground=BG,
            relief="flat", bd=0, padx=20, pady=6,
            command=self._start_watch, state="disabled",
        )
        self._start_btn.pack(side="left")

        self._dashboard_btn = tk.Button(
            btn_row, text="Open Dashboard", font=("Helvetica", 11),
            fg=TEXT, bg=SURFACE, activebackground=BORDER,
            relief="flat", bd=0, padx=16, pady=6,
            highlightbackground=BORDER, highlightthickness=1,
            command=self._open_dashboard, state="disabled",
        )
        self._dashboard_btn.pack(side="left", padx=(8, 0))

        # Log area
        log_frame = tk.Frame(self, bg=BG)
        log_frame.pack(fill="both", expand=True, padx=24, pady=(16, 24))

        self._log = tk.Text(
            log_frame, font=("JetBrains Mono", 10), fg=TEXT_MUTED, bg=SURFACE,
            relief="flat", bd=0, highlightbackground=BORDER,
            highlightthickness=1, wrap="word", height=8,
        )
        self._log.pack(fill="both", expand=True)
        self._log.configure(state="disabled")

    def _log_msg(self, msg: str):
        self._log.configure(state="normal")
        self._log.insert("end", msg + "\n")
        self._log.see("end")
        self._log.configure(state="disabled")

    def _set_status(self, text: str, color: str = TEXT_MUTED):
        self._status_label.configure(text=text, fg=color)

    def _check_license(self):
        try:
            from signal_provenance.license import check_license
            lic = check_license()
            if lic:
                self._set_status(
                    f"Licensed: {lic.cid} ({lic.tier}) -- expires {lic.expires}",
                    GREEN,
                )
                self._log_msg(f"License valid: {lic.cid}")
            else:
                self._set_status("No license -- enter activation code above", TEXT_MUTED)
        except Exception as e:
            self._set_status(f"License check failed: {e}", RED)

    def _activate(self):
        code = self._code_var.get().strip()
        if not code:
            messagebox.showwarning("Activation", "Enter your activation code.")
            return

        self._activate_btn.configure(state="disabled", text="Activating...")
        self._log_msg(f"Activating: {code}")

        def do_activate():
            try:
                from signal_provenance.license import activate
                lic = activate(code)
                self.after(0, lambda: self._on_activated(lic))
            except Exception as e:
                self.after(0, lambda: self._on_activate_error(str(e)))

        threading.Thread(target=do_activate, daemon=True).start()

    def _on_activated(self, lic):
        self._activate_btn.configure(state="normal", text="Activate")
        self._set_status(
            f"Licensed: {lic.cid} ({lic.tier}) -- expires {lic.expires}",
            GREEN,
        )
        self._log_msg(f"Activated: {lic.cid} ({lic.email})")
        self._code_entry.delete(0, "end")

    def _on_activate_error(self, msg: str):
        self._activate_btn.configure(state="normal", text="Activate")
        self._set_status(f"Activation failed", RED)
        self._log_msg(f"Error: {msg}")
        messagebox.showerror("Activation Failed", msg)

    def _browse(self):
        folder = filedialog.askdirectory(title="Select folder to watch")
        if folder:
            self._target = Path(folder)
            self._folder_var.set(str(self._target))
            self._start_btn.configure(state="normal")
            self._log_msg(f"Selected: {folder}")

    def _start_watch(self):
        if not self._target:
            return

        self._start_btn.configure(state="disabled", text="Starting...")
        self._log_msg(f"Initializing provenance for {self._target}...")

        def do_watch():
            try:
                from signal_provenance.db import get_connection, init_db
                from signal_provenance.harvest import harvest, auto_report
                from signal_provenance.providers.local import LocalProvider

                target = self._target

                # Init
                prov_dir = target / ".signal-provenance"
                prov_dir.mkdir(parents=True, exist_ok=True)
                conn = get_connection(target)
                init_db(conn)

                # Harvest
                provider = LocalProvider(target)
                summary = harvest(conn, target, provider=provider)
                self.after(0, lambda: self._log_msg(
                    f"Harvested: {summary['files_total']} files "
                    f"({summary['files_new']} new, "
                    f"{summary['files_updated']} updated) "
                    f"in {summary['duration_ms']}ms"
                ))

                # Verify
                from signal_provenance.db import verify_chain
                result = verify_chain(target)
                valid = result.get("valid", False)
                entries = result.get("entries", 0)
                self.after(0, lambda: self._log_msg(
                    f"Chain: {'VALID' if valid else 'BROKEN'} ({entries} entries)"
                ))

                # Auto-report
                reports = auto_report(conn, target)
                for r in reports:
                    self.after(0, lambda r=r: self._log_msg(f"Report: {r}"))

                conn.close()

                # Start dashboard server in background
                self.after(0, self._start_dashboard_server)

            except Exception as e:
                self.after(0, lambda: self._on_watch_error(str(e)))

        threading.Thread(target=do_watch, daemon=True).start()

    def _start_dashboard_server(self):
        self._start_btn.configure(text="Watching", bg=BORDER)
        self._dashboard_btn.configure(state="normal")
        self._log_msg("Starting dashboard server on port 9111...")

        def run_server():
            try:
                from signal_provenance.dashboard import serve_dashboard
                from signal_provenance.db import get_connection
                conn = get_connection(self._target)
                serve_dashboard(conn, self._target, port=9111, open_browser=False)
            except Exception as e:
                self.after(0, lambda: self._log_msg(f"Dashboard error: {e}"))

        self._server_thread = threading.Thread(target=run_server, daemon=True)
        self._server_thread.start()

        # Auto-open browser after brief delay
        self.after(1000, self._open_dashboard)
        self._set_status("Watching -- dashboard running on port 9111", GREEN)

    def _on_watch_error(self, msg: str):
        self._start_btn.configure(state="normal", text="Start Watching", bg=GREEN)
        self._log_msg(f"Error: {msg}")
        messagebox.showerror("Watch Failed", msg)

    def _open_dashboard(self):
        webbrowser.open("http://localhost:9111")

    def destroy(self):
        super().destroy()


def main():
    app = App()
    app.mainloop()


if __name__ == "__main__":
    main()
