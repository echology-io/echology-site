"""Database layer for Signal Provenance.

SQLite schema, hash-chained witness ledger, and query functions.
All stdlib -- no external dependencies.
"""

import hashlib
import json
import logging
import platform
import socket
import sqlite3
import uuid
from datetime import datetime, timezone
from pathlib import Path

log = logging.getLogger("signal_provenance.db")

ALETHEIA_GENESIS_HASH = hashlib.sha256(b"ALETHEIA_GENESIS_v1").hexdigest()

_SENTINEL = object()


# -- Schema ----------------------------------------------------------------

PROVENANCE_SCHEMA = """
CREATE TABLE IF NOT EXISTS file_metadata (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    file_path       TEXT    UNIQUE NOT NULL,
    content_hash    TEXT,
    size_bytes      INTEGER,
    extension       TEXT,
    role            TEXT,
    first_seen      TEXT,
    last_modified   TEXT,
    last_accessed   TEXT,
    lines_of_code   INTEGER,
    edit_frequency_1d  INTEGER DEFAULT 0,
    edit_frequency_7d  INTEGER DEFAULT 0,
    edit_frequency_14d INTEGER DEFAULT 0,
    edit_frequency_21d INTEGER DEFAULT 0,
    edit_frequency_30d INTEGER DEFAULT 0,
    edit_frequency_90d INTEGER DEFAULT 0,
    harvested_at    TEXT
);
CREATE INDEX IF NOT EXISTS idx_fm_path ON file_metadata(file_path);
CREATE INDEX IF NOT EXISTS idx_fm_ext ON file_metadata(extension);

CREATE TABLE IF NOT EXISTS artifact_snapshots (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    file_id         INTEGER NOT NULL REFERENCES file_metadata(id),
    harvest_id      INTEGER,
    content_hash    TEXT,
    size_bytes      INTEGER,
    lines_of_code   INTEGER,
    last_accessed   TEXT,
    change_type     TEXT    NOT NULL DEFAULT 'created',
    prior_hash      TEXT,
    change_actor    TEXT,
    change_reason   TEXT,
    perceived_at    TEXT    NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_as_file ON artifact_snapshots(file_id);
CREATE INDEX IF NOT EXISTS idx_as_harvest ON artifact_snapshots(harvest_id);
CREATE INDEX IF NOT EXISTS idx_as_time ON artifact_snapshots(perceived_at);

CREATE TABLE IF NOT EXISTS metadata_harvests (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    repo_root       TEXT    NOT NULL,
    files_total     INTEGER NOT NULL DEFAULT 0,
    files_new       INTEGER NOT NULL DEFAULT 0,
    files_updated   INTEGER NOT NULL DEFAULT 0,
    files_deleted   INTEGER NOT NULL DEFAULT 0,
    files_skipped   INTEGER NOT NULL DEFAULT 0,
    duration_ms     INTEGER NOT NULL DEFAULT 0,
    host            TEXT,
    harvested_at    TEXT    NOT NULL DEFAULT (datetime('now'))
);
"""

LEDGER_SCHEMA = """
CREATE TABLE IF NOT EXISTS ledger (
    seq          INTEGER PRIMARY KEY AUTOINCREMENT,
    entry_id     TEXT    UNIQUE NOT NULL,
    timestamp    TEXT    NOT NULL,
    event_type   TEXT    NOT NULL,
    source       TEXT,
    content_hash TEXT,
    result_hash  TEXT    NOT NULL,
    prev_hash    TEXT    NOT NULL,
    chain_hash   TEXT    UNIQUE NOT NULL,
    summary      TEXT,
    workstation  TEXT,
    CONSTRAINT valid_event CHECK (event_type IN (
        'file_created', 'file_modified', 'file_deleted',
        'harvest_started', 'harvest_completed',
        'chain_verified', 'chain_broken'
    ))
);
CREATE INDEX IF NOT EXISTS idx_ledger_source ON ledger(source);
CREATE INDEX IF NOT EXISTS idx_ledger_event ON ledger(event_type);
CREATE INDEX IF NOT EXISTS idx_ledger_time ON ledger(timestamp);
"""


# -- Connection ------------------------------------------------------------

def get_provenance_dir(target_dir: Path) -> Path:
    """Return the .signal-provenance directory for a target directory."""
    return target_dir / ".signal-provenance"


def get_connection(target_dir: Path) -> sqlite3.Connection:
    """Open or create the provenance database for a directory."""
    prov_dir = get_provenance_dir(target_dir)
    prov_dir.mkdir(parents=True, exist_ok=True)
    db_path = prov_dir / "provenance.db"
    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def init_db(conn: sqlite3.Connection) -> None:
    """Create tables if they do not exist."""
    conn.executescript(PROVENANCE_SCHEMA)


def get_ledger_path(target_dir: Path) -> Path:
    """Return the ledger database path for a target directory."""
    return get_provenance_dir(target_dir) / "ledger.db"


def get_ledger_connection(target_dir: Path) -> sqlite3.Connection:
    """Open or create the ledger database."""
    ledger_path = get_ledger_path(target_dir)
    ledger_path.parent.mkdir(parents=True, exist_ok=True)
    lconn = sqlite3.connect(str(ledger_path))
    lconn.row_factory = sqlite3.Row
    lconn.executescript(LEDGER_SCHEMA)
    return lconn


# -- Witness (hash-chained ledger) -----------------------------------------

def witness(target_dir: Path, event_type: str, source: str,
            payload: dict) -> None:
    """Append a hash-chained witness entry to the Aletheia ledger.

    Never raises -- ledger failure must not block operational writes.
    """
    try:
        lconn = get_ledger_connection(target_dir)

        last = lconn.execute(
            "SELECT chain_hash FROM ledger ORDER BY seq DESC LIMIT 1"
        ).fetchone()
        prev_hash = last["chain_hash"] if last else ALETHEIA_GENESIS_HASH

        now = datetime.now(timezone.utc).isoformat()
        entry_id = uuid.uuid4().hex[:24]
        summary = json.dumps(payload, default=str)
        content_hash = hashlib.sha256(summary.encode()).hexdigest()
        result_hash = hashlib.sha256(
            f"{event_type}:{now}".encode()
        ).hexdigest()
        chain_hash = hashlib.sha256(
            f"{entry_id}|{now}|{event_type}|{content_hash}"
            f"|{result_hash}|{prev_hash}".encode()
        ).hexdigest()

        lconn.execute(
            "INSERT INTO ledger (entry_id, timestamp, event_type, source, "
            "content_hash, result_hash, prev_hash, chain_hash, summary, "
            "workstation) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (entry_id, now, event_type, source, content_hash, result_hash,
             prev_hash, chain_hash, summary, socket.gethostname()),
        )
        lconn.commit()
        lconn.close()
    except Exception as exc:
        log.warning("Witness failed: %s", exc)


# -- File metadata ---------------------------------------------------------

def upsert_file_metadata(conn: sqlite3.Connection, *, commit: bool = True,
                         _existing_id: int | None = _SENTINEL,
                         **kwargs) -> int:
    """Insert or update a file_metadata row, keyed on file_path."""
    file_path = kwargs["file_path"]
    if _existing_id is _SENTINEL:
        row = conn.execute(
            "SELECT id FROM file_metadata WHERE file_path = ?",
            (file_path,),
        ).fetchone()
        existing_id = row[0] if row else None
    else:
        existing_id = _existing_id

    if existing_id is not None:
        sets = ", ".join(f"{k} = ?" for k in kwargs if k != "file_path")
        vals = [v for k, v in kwargs.items() if k != "file_path"]
        vals.append(file_path)
        conn.execute(
            f"UPDATE file_metadata SET {sets}, harvested_at = datetime('now') "
            f"WHERE file_path = ?",
            vals,
        )
        if commit:
            conn.commit()
        return existing_id

    cols = list(kwargs.keys()) + ["harvested_at"]
    placeholders = ", ".join(["?"] * len(kwargs)) + ", datetime('now')"
    cur = conn.execute(
        f"INSERT INTO file_metadata ({', '.join(cols)}) "
        f"VALUES ({placeholders})",
        list(kwargs.values()),
    )
    if commit:
        conn.commit()
    return cur.lastrowid


def get_all_file_ids(conn: sqlite3.Connection) -> dict[str, int]:
    """Return {file_path: id} for all file_metadata rows."""
    return {
        row[0]: row[1]
        for row in conn.execute(
            "SELECT file_path, id FROM file_metadata"
        ).fetchall()
    }


def get_latest_snapshot_hashes(
    conn: sqlite3.Connection,
) -> dict[int, str]:
    """Return {file_id: content_hash} for the most recent snapshot of each file."""
    return {
        row[0]: row[1]
        for row in conn.execute(
            "SELECT file_id, content_hash FROM artifact_snapshots "
            "WHERE id IN (SELECT MAX(id) FROM artifact_snapshots GROUP BY file_id)"
        ).fetchall()
    }


# -- Artifact snapshots ----------------------------------------------------

def record_artifact_snapshot(
    conn: sqlite3.Connection,
    target_dir: Path,
    file_path: str,
    content_hash: str,
    *,
    size_bytes: int | None = None,
    lines_of_code: int | None = None,
    last_accessed: str | None = None,
    harvest_id: int | None = None,
    change_actor: str | None = None,
    change_reason: str | None = None,
    commit: bool = True,
    _file_id: int | None = _SENTINEL,
    _prior_hash: str | None = _SENTINEL,
) -> int:
    """Record a perceived snapshot of a file. Detects change_type by comparing
    to prior hash. Creates/modifications are Aletheia-witnessed."""
    if _file_id is _SENTINEL:
        row = conn.execute(
            "SELECT id FROM file_metadata WHERE file_path = ?",
            (file_path,),
        ).fetchone()
        file_id = row[0] if row else upsert_file_metadata(
            conn, file_path=file_path
        )
    else:
        file_id = _file_id

    if _prior_hash is _SENTINEL:
        prior = conn.execute(
            "SELECT content_hash FROM artifact_snapshots "
            "WHERE file_id = ? ORDER BY perceived_at DESC LIMIT 1",
            (file_id,),
        ).fetchone()
        prior_hash = prior[0] if prior else None
    else:
        prior_hash = _prior_hash

    if prior_hash is None:
        change_type = "created"
    elif prior_hash == content_hash:
        change_type = "unchanged"
    else:
        change_type = "modified"

    cur = conn.execute(
        "INSERT INTO artifact_snapshots "
        "(file_id, harvest_id, content_hash, size_bytes, lines_of_code, "
        "last_accessed, change_type, prior_hash, change_actor, change_reason) "
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        (file_id, harvest_id, content_hash, size_bytes, lines_of_code,
         last_accessed, change_type, prior_hash, change_actor, change_reason),
    )
    if commit:
        conn.commit()

    if change_type in ("created", "modified"):
        witness(target_dir, f"file_{change_type}", "provenance.harvest", {
            "file_path": file_path,
            "content_hash": content_hash[:12],
            "prior_hash": prior_hash[:12] if prior_hash else None,
            "change_actor": change_actor,
            "harvest_id": harvest_id,
        })

    return cur.lastrowid


def record_artifact_deletion(
    conn: sqlite3.Connection,
    target_dir: Path,
    file_path: str,
    harvest_id: int | None = None,
) -> int | None:
    """Record that a file was perceived as deleted (no longer on disk)."""
    row = conn.execute(
        "SELECT id FROM file_metadata WHERE file_path = ?",
        (file_path,),
    ).fetchone()
    if not row:
        return None
    prior = conn.execute(
        "SELECT content_hash FROM artifact_snapshots "
        "WHERE file_id = ? ORDER BY perceived_at DESC LIMIT 1",
        (row[0],),
    ).fetchone()
    cur = conn.execute(
        "INSERT INTO artifact_snapshots "
        "(file_id, harvest_id, content_hash, change_type, prior_hash) "
        "VALUES (?, ?, '', 'deleted', ?)",
        (row[0], harvest_id, prior[0] if prior else None),
    )
    conn.commit()
    witness(target_dir, "file_deleted", "provenance.harvest", {
        "file_path": file_path,
        "prior_hash": prior[0][:12] if prior and prior[0] else None,
        "harvest_id": harvest_id,
    })
    return cur.lastrowid


def witness_file_output(
    conn: sqlite3.Connection,
    target_dir: Path,
    file_path: str,
    actor: str,
    reason: str | None = None,
) -> int | None:
    """Witness a file that was just created or modified.

    Computes hash from disk, records snapshot with actor provenance,
    and witnesses in Aletheia. Call after writing a file.
    """
    p = Path(file_path)
    if not p.exists():
        return None
    content_hash = hashlib.sha256(p.read_bytes()).hexdigest()
    stat = p.stat()
    return record_artifact_snapshot(
        conn, target_dir, file_path, content_hash,
        size_bytes=stat.st_size,
        change_actor=actor,
        change_reason=reason,
    )


# -- Harvest tracking ------------------------------------------------------

def log_metadata_harvest(
    conn: sqlite3.Connection,
    repo_root: str,
    files_total: int,
    files_new: int,
    files_updated: int,
    files_deleted: int,
    duration_ms: int,
    host: str | None = None,
) -> int:
    """Record a metadata harvest run."""
    host = host or platform.node()
    cur = conn.execute(
        "INSERT INTO metadata_harvests "
        "(repo_root, files_total, files_new, files_updated, files_deleted, "
        "duration_ms, host, harvested_at) "
        "VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'))",
        (repo_root, files_total, files_new, files_updated, files_deleted,
         duration_ms, host),
    )
    conn.commit()
    return cur.lastrowid


# -- Query functions -------------------------------------------------------

def get_file_history(conn: sqlite3.Connection, file_path: str) -> list[dict]:
    """Get perceived state history for a file, newest first."""
    rows = conn.execute(
        "SELECT s.*, fm.file_path FROM artifact_snapshots s "
        "JOIN file_metadata fm ON s.file_id = fm.id "
        "WHERE fm.file_path = ? ORDER BY s.perceived_at DESC",
        (file_path,),
    ).fetchall()
    return [dict(r) for r in rows]


def get_file_at_time(
    conn: sqlite3.Connection, file_path: str, at: str
) -> dict | None:
    """Get perceived state of a file at a given timestamp."""
    row = conn.execute(
        "SELECT s.*, fm.file_path FROM artifact_snapshots s "
        "JOIN file_metadata fm ON s.file_id = fm.id "
        "WHERE fm.file_path = ? AND s.perceived_at <= ? "
        "ORDER BY s.perceived_at DESC LIMIT 1",
        (file_path, at),
    ).fetchone()
    return dict(row) if row else None


def get_environment_at_time(
    conn: sqlite3.Connection, at: str
) -> list[dict]:
    """Reconstruct the full file environment at a point in time.

    Returns the latest snapshot for each file as of the given timestamp,
    excluding files whose last snapshot was 'deleted'.
    """
    query = (
        "SELECT fm.file_path, fm.role, s.content_hash, "
        "s.size_bytes, s.lines_of_code, s.change_type, s.perceived_at "
        "FROM artifact_snapshots s "
        "JOIN file_metadata fm ON s.file_id = fm.id "
        "WHERE s.perceived_at <= ? "
        "AND s.id = ("
        "  SELECT id FROM artifact_snapshots s2 "
        "  WHERE s2.file_id = s.file_id AND s2.perceived_at <= ? "
        "  ORDER BY s2.perceived_at DESC LIMIT 1"
        ") AND s.change_type != 'deleted' "
        "ORDER BY fm.file_path"
    )
    rows = conn.execute(query, [at, at]).fetchall()
    return [dict(r) for r in rows]


# -- Ledger verification ---------------------------------------------------

def verify_chain(target_dir: Path) -> dict:
    """Verify the Aletheia ledger chain integrity.

    Returns dict with keys: valid, entries, breaks, first, last.
    """
    ledger_path = get_ledger_path(target_dir)
    if not ledger_path.exists():
        return {"valid": None, "entries": 0, "error": "No ledger found"}

    lconn = sqlite3.connect(str(ledger_path))
    lconn.row_factory = sqlite3.Row

    rows = lconn.execute(
        "SELECT seq, entry_id, timestamp, event_type, content_hash, "
        "result_hash, prev_hash, chain_hash FROM ledger ORDER BY seq"
    ).fetchall()
    lconn.close()

    if not rows:
        return {"valid": None, "entries": 0, "error": "Ledger empty"}

    prev = ALETHEIA_GENESIS_HASH
    breaks = []
    for r in rows:
        if r["prev_hash"] != prev:
            breaks.append(r["seq"])
        prev = r["chain_hash"]

    return {
        "valid": len(breaks) == 0,
        "entries": len(rows),
        "breaks": breaks,
        "first": {"seq": rows[0]["seq"], "timestamp": rows[0]["timestamp"]},
        "last": {"seq": rows[-1]["seq"], "timestamp": rows[-1]["timestamp"]},
    }


def get_ledger_stats(target_dir: Path) -> dict | None:
    """Get ledger statistics."""
    ledger_path = get_ledger_path(target_dir)
    if not ledger_path.exists():
        return None

    lconn = sqlite3.connect(str(ledger_path))
    lconn.row_factory = sqlite3.Row

    total = lconn.execute("SELECT COUNT(*) FROM ledger").fetchone()[0]
    events = lconn.execute(
        "SELECT event_type, COUNT(*) as cnt FROM ledger "
        "GROUP BY event_type ORDER BY cnt DESC"
    ).fetchall()
    first = lconn.execute(
        "SELECT timestamp FROM ledger ORDER BY seq ASC LIMIT 1"
    ).fetchone()
    last = lconn.execute(
        "SELECT timestamp FROM ledger ORDER BY seq DESC LIMIT 1"
    ).fetchone()
    lconn.close()

    return {
        "total": total,
        "events": {r["event_type"]: r["cnt"] for r in events},
        "first": first[0] if first else None,
        "last": last[0] if last else None,
    }


def get_ledger_history(target_dir: Path, limit: int = 20) -> list[dict]:
    """Get recent ledger entries."""
    ledger_path = get_ledger_path(target_dir)
    if not ledger_path.exists():
        return []

    lconn = sqlite3.connect(str(ledger_path))
    lconn.row_factory = sqlite3.Row

    rows = lconn.execute(
        "SELECT seq, timestamp, event_type, source, summary "
        "FROM ledger ORDER BY seq DESC LIMIT ?",
        (limit,),
    ).fetchall()
    lconn.close()

    result = []
    for r in rows:
        summary = json.loads(r["summary"]) if r["summary"] else {}
        result.append({
            "seq": r["seq"],
            "timestamp": r["timestamp"],
            "event_type": r["event_type"],
            "source": r["source"],
            "summary": summary,
        })
    return result
