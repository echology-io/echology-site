"""AWS S3 storage provider.

Requires: pip install signal-provenance[s3]
Auth: standard AWS credentials chain (env vars, ~/.aws/credentials, IAM role).
"""

from __future__ import annotations

import hashlib
import os
from typing import Iterator

from . import FileEntry, LOC_EXTENSIONS, count_lines, should_skip


class S3Provider:
    """Walk an S3 bucket/prefix and yield FileEntry for each non-skipped object."""

    def __init__(self, bucket: str, prefix: str = "") -> None:
        try:
            import boto3
        except ImportError:
            raise ImportError(
                "boto3 is required for S3 support. "
                "Install with: pip install signal-provenance[s3]"
            )
        self.bucket = bucket
        self.prefix = prefix.lstrip("/")
        self.client = boto3.client("s3")

    @classmethod
    def from_uri(cls, uri: str) -> S3Provider:
        """Parse s3://bucket/prefix into an S3Provider."""
        path = uri.removeprefix("s3://")
        parts = path.split("/", 1)
        bucket = parts[0]
        prefix = parts[1] if len(parts) > 1 else ""
        return cls(bucket, prefix)

    def list_files(self) -> Iterator[FileEntry]:
        """Yield FileEntry for each non-skipped object in the bucket/prefix."""
        paginator = self.client.get_paginator("list_objects_v2")
        pages = paginator.paginate(Bucket=self.bucket, Prefix=self.prefix)

        for page in pages:
            for obj in page.get("Contents", []):
                key = obj["Key"]

                # Skip "directory" markers
                if key.endswith("/"):
                    continue

                # Compute relative path from prefix
                rel_path = key[len(self.prefix):].lstrip("/") if self.prefix else key
                if not rel_path:
                    continue

                parts = tuple(rel_path.split("/"))
                ext_idx = rel_path.rfind(".")
                ext = rel_path[ext_idx:].lower() if ext_idx >= 0 else ""

                if should_skip(parts, ext):
                    continue

                mtime = obj["LastModified"].isoformat()
                size = obj["Size"]

                # Stream content for hashing (chunked, memory-safe)
                content_hash, content_bytes = self._hash_object(key)
                if content_hash is None:
                    continue

                loc = None
                if ext in LOC_EXTENSIONS and content_bytes is not None:
                    loc = count_lines(content_bytes, ext)

                yield FileEntry(
                    path=rel_path,
                    content_hash=content_hash,
                    size=size,
                    mtime=mtime,
                    atime=mtime,  # S3 has no atime
                    extension=ext,
                    lines_of_code=loc,
                )

    def detect_deletions(self, known_paths: set[str]) -> list[str]:
        """Return paths from known_paths that no longer exist in S3."""
        current = set()
        paginator = self.client.get_paginator("list_objects_v2")
        pages = paginator.paginate(Bucket=self.bucket, Prefix=self.prefix)
        for page in pages:
            for obj in page.get("Contents", []):
                key = obj["Key"]
                if key.endswith("/"):
                    continue
                rel = key[len(self.prefix):].lstrip("/") if self.prefix else key
                if rel:
                    current.add(rel)
        return sorted(known_paths - current)

    def _hash_object(self, key: str) -> tuple[str | None, bytes | None]:
        """Stream-hash an S3 object. Returns (hex_digest, raw_bytes).

        For files under 10MB, keeps bytes in memory for LOC counting.
        For larger files, streams and discards -- returns (hash, None).
        """
        try:
            response = self.client.get_object(Bucket=self.bucket, Key=key)
            body = response["Body"]
            size = response.get("ContentLength", 0)

            h = hashlib.sha256()
            keep_bytes = size <= 10 * 1024 * 1024  # 10MB threshold
            chunks = []

            for chunk in body.iter_chunks(8192):
                h.update(chunk)
                if keep_bytes:
                    chunks.append(chunk)

            content_bytes = b"".join(chunks) if keep_bytes else None
            return h.hexdigest(), content_bytes
        except Exception:
            return None, None
