"""Google Drive storage provider.

Requires: pip install signal-provenance[gdrive]
Auth: Service account or OAuth2.
  GOOGLE_APPLICATION_CREDENTIALS -- path to service account JSON key file
"""

from __future__ import annotations

import hashlib
import io
import os
from typing import Iterator

from . import FileEntry, LOC_EXTENSIONS, count_lines, should_skip


class GoogleDriveProvider:
    """Walk a Google Drive folder and yield FileEntry for each non-skipped file."""

    def __init__(self, folder_id: str) -> None:
        creds_path = os.environ.get("GOOGLE_APPLICATION_CREDENTIALS")
        if not creds_path:
            raise EnvironmentError(
                "Google Drive requires GOOGLE_APPLICATION_CREDENTIALS "
                "environment variable pointing to a service account JSON key."
            )

        try:
            from google.oauth2 import service_account
            from googleapiclient.discovery import build
            from googleapiclient.http import MediaIoBaseDownload
        except ImportError:
            raise ImportError(
                "google-api-python-client and google-auth are required for "
                "Google Drive support. "
                "Install with: pip install signal-provenance[gdrive]"
            )

        self.folder_id = folder_id
        self._MediaIoBaseDownload = MediaIoBaseDownload

        credentials = service_account.Credentials.from_service_account_file(
            creds_path,
            scopes=["https://www.googleapis.com/auth/drive.readonly"],
        )
        self._service = build("drive", "v3", credentials=credentials)

    @classmethod
    def from_uri(cls, uri: str) -> GoogleDriveProvider:
        """Parse gdrive://folder-id into a GoogleDriveProvider."""
        folder_id = uri.removeprefix("gdrive://").strip("/")
        return cls(folder_id)

    def list_files(self) -> Iterator[FileEntry]:
        """Yield FileEntry for each non-skipped file in the folder tree."""
        yield from self._walk_folder(self.folder_id, "")

    def _walk_folder(self, folder_id: str, prefix: str) -> Iterator[FileEntry]:
        """Recursively walk a Drive folder."""
        page_token = None

        while True:
            response = self._service.files().list(
                q=f"'{folder_id}' in parents and trashed = false",
                fields="nextPageToken, files(id, name, mimeType, size, modifiedTime)",
                pageSize=1000,
                pageToken=page_token,
            ).execute()

            for item in response.get("files", []):
                name = item["name"]
                rel_path = f"{prefix}/{name}" if prefix else name

                # Recurse into subfolders
                if item["mimeType"] == "application/vnd.google-apps.folder":
                    yield from self._walk_folder(item["id"], rel_path)
                    continue

                # Skip Google Workspace native formats (Docs, Sheets, etc.)
                if item["mimeType"].startswith("application/vnd.google-apps."):
                    continue

                parts = tuple(rel_path.split("/"))
                ext_idx = name.rfind(".")
                ext = name[ext_idx:].lower() if ext_idx >= 0 else ""

                if should_skip(parts, ext):
                    continue

                size = int(item.get("size", 0))
                mtime = item.get("modifiedTime", "")

                content_hash, content_bytes = self._hash_file(item["id"], size)
                if content_hash is None:
                    continue

                loc = None
                if ext in LOC_EXTENSIONS and content_bytes is not None:
                    loc = count_lines(content_bytes, ext)

                yield FileEntry(
                    path=rel_path,
                    content_hash=content_hash,
                    size=size,
                    mtime=mtime,
                    atime=mtime,  # Drive has no atime
                    extension=ext,
                    lines_of_code=loc,
                )

            page_token = response.get("nextPageToken")
            if not page_token:
                break

    def detect_deletions(self, known_paths: set[str]) -> list[str]:
        """Return paths from known_paths that no longer exist in Drive."""
        current = {entry["path"] for entry in self.list_files()}
        return sorted(known_paths - current)

    def _hash_file(self, file_id: str, size: int) -> tuple[str | None, bytes | None]:
        """Download and hash a file from Google Drive."""
        try:
            request = self._service.files().get_media(fileId=file_id)
            buffer = io.BytesIO()
            downloader = self._MediaIoBaseDownload(buffer, request)

            done = False
            while not done:
                _, done = downloader.next_chunk()

            data = buffer.getvalue()
            content_hash = hashlib.sha256(data).hexdigest()

            keep_bytes = size <= 10 * 1024 * 1024
            return content_hash, data if keep_bytes else None
        except Exception:
            return None, None
