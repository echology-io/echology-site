"""Local filesystem storage provider.

Extracted from harvest.py. Same logic, same skip filters, same mtime
optimization. Now behind the StorageProvider protocol so harvest.py
can consume any backend identically.
"""

from __future__ import annotations

import hashlib
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterator

from . import (
    FileEntry,
    LOC_EXTENSIONS,
    classify_role,
    count_lines,
    should_skip,
)


class LocalProvider:
    """Walk a local directory and yield FileEntry for each non-skipped file."""

    def __init__(self, root: Path, exclude: list[str] | None = None,
                 include: list[str] | None = None) -> None:
        self.root = root
        self.exclude = set(exclude) if exclude else None
        self.include = set(include) if include else None

    def list_files(self) -> Iterator[FileEntry]:
        """Yield FileEntry for each file under root, sorted by path."""
        paths = []
        for item in self.root.rglob("*"):
            if not item.is_file():
                continue
            rel_parts = item.relative_to(self.root).parts
            ext = item.suffix.lower()
            if should_skip(rel_parts, ext, self.exclude, self.include):
                continue
            paths.append(item)
        paths.sort()

        for file_path in paths:
            rel = str(file_path.relative_to(self.root))
            ext = file_path.suffix.lower()
            try:
                stat = file_path.stat()
            except (OSError, PermissionError):
                continue

            content_hash = self._sha256(file_path)
            if content_hash is None:
                continue

            loc = None
            if ext in LOC_EXTENSIONS:
                try:
                    data = file_path.read_bytes()
                    loc = count_lines(data, ext)
                except (OSError, PermissionError):
                    pass

            mtime = datetime.fromtimestamp(
                stat.st_mtime, tz=timezone.utc
            ).isoformat()
            atime = datetime.fromtimestamp(
                stat.st_atime, tz=timezone.utc
            ).isoformat()

            yield FileEntry(
                path=rel,
                content_hash=content_hash,
                size=stat.st_size,
                mtime=mtime,
                atime=atime,
                extension=ext,
                lines_of_code=loc,
            )

    def detect_deletions(self, known_paths: set[str]) -> list[str]:
        """Return paths from known_paths that no longer exist on disk."""
        current = set()
        for item in self.root.rglob("*"):
            if not item.is_file():
                continue
            rel_parts = item.relative_to(self.root).parts
            ext = item.suffix.lower()
            if should_skip(rel_parts, ext, self.exclude, self.include):
                continue
            current.add(str(item.relative_to(self.root)))
        return sorted(known_paths - current)

    @staticmethod
    def _sha256(file_path: Path) -> str | None:
        """Compute SHA-256 hash of file contents, streaming 8KB chunks."""
        try:
            h = hashlib.sha256()
            with open(file_path, "rb") as f:
                for chunk in iter(lambda: f.read(8192), b""):
                    h.update(chunk)
            return h.hexdigest()
        except (OSError, PermissionError):
            return None
