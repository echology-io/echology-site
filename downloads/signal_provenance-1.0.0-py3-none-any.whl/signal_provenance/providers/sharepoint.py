"""SharePoint / OneDrive for Business storage provider (MS Graph API).

Requires: pip install signal-provenance[sharepoint]
Auth: MSAL client credentials flow.
  SP_TENANT_ID  -- Azure AD tenant ID
  SP_CLIENT_ID  -- App registration client ID
  SP_CLIENT_SECRET -- App registration client secret
"""

from __future__ import annotations

import hashlib
import os
from typing import Iterator

from . import FileEntry, LOC_EXTENSIONS, count_lines, should_skip

GRAPH_BASE = "https://graph.microsoft.com/v1.0"


class SharePointProvider:
    """Walk a SharePoint document library via MS Graph and yield FileEntry."""

    def __init__(self, site_name: str, library: str = "Documents") -> None:
        tenant_id = os.environ.get("SP_TENANT_ID")
        client_id = os.environ.get("SP_CLIENT_ID")
        client_secret = os.environ.get("SP_CLIENT_SECRET")

        if not all([tenant_id, client_id, client_secret]):
            raise EnvironmentError(
                "SharePoint requires SP_TENANT_ID, SP_CLIENT_ID, and "
                "SP_CLIENT_SECRET environment variables."
            )

        try:
            import msal
            import requests
        except ImportError:
            raise ImportError(
                "msal and requests are required for SharePoint support. "
                "Install with: pip install signal-provenance[sharepoint]"
            )

        self.site_name = site_name
        self.library = library
        self._requests = requests

        # Acquire token via client credentials
        app = msal.ConfidentialClientApplication(
            client_id,
            authority=f"https://login.microsoftonline.com/{tenant_id}",
            client_credential=client_secret,
        )
        result = app.acquire_token_for_client(
            scopes=["https://graph.microsoft.com/.default"]
        )
        if "access_token" not in result:
            raise EnvironmentError(
                f"Failed to acquire Graph API token: {result.get('error_description', 'unknown error')}"
            )
        self._token = result["access_token"]
        self._headers = {"Authorization": f"Bearer {self._token}"}

        # Resolve site and drive IDs
        self._site_id = self._resolve_site()
        self._drive_id = self._resolve_drive()

    @classmethod
    def from_uri(cls, uri: str) -> SharePointProvider:
        """Parse sharepoint://SiteName/Library into a SharePointProvider."""
        path = uri.removeprefix("sharepoint://")
        parts = path.split("/", 1)
        site = parts[0]
        library = parts[1] if len(parts) > 1 else "Documents"
        return cls(site, library)

    def _resolve_site(self) -> str:
        """Look up the SharePoint site ID by name."""
        # Try hostname search first (works for most tenants)
        resp = self._requests.get(
            f"{GRAPH_BASE}/sites?search={self.site_name}",
            headers=self._headers,
        )
        resp.raise_for_status()
        sites = resp.json().get("value", [])
        if not sites:
            raise ValueError(f"SharePoint site not found: {self.site_name}")
        return sites[0]["id"]

    def _resolve_drive(self) -> str:
        """Look up the drive ID for the target document library."""
        resp = self._requests.get(
            f"{GRAPH_BASE}/sites/{self._site_id}/drives",
            headers=self._headers,
        )
        resp.raise_for_status()
        for drive in resp.json().get("value", []):
            if drive["name"] == self.library:
                return drive["id"]
        raise ValueError(
            f"Document library not found: {self.library} "
            f"on site {self.site_name}"
        )

    def list_files(self) -> Iterator[FileEntry]:
        """Yield FileEntry for each non-skipped file in the document library."""
        yield from self._walk_folder("root")

    def _walk_folder(self, item_id: str, prefix: str = "") -> Iterator[FileEntry]:
        """Recursively walk a folder in the drive."""
        url = f"{GRAPH_BASE}/drives/{self._drive_id}/items/{item_id}/children"

        while url:
            resp = self._requests.get(url, headers=self._headers)
            resp.raise_for_status()
            data = resp.json()

            for item in data.get("value", []):
                name = item["name"]
                rel_path = f"{prefix}{name}" if not prefix else f"{prefix}/{name}"

                if "folder" in item:
                    # Recurse into subfolder
                    yield from self._walk_folder(item["id"], rel_path)
                    continue

                if "file" not in item:
                    continue

                parts = tuple(rel_path.split("/"))
                ext_idx = name.rfind(".")
                ext = name[ext_idx:].lower() if ext_idx >= 0 else ""

                if should_skip(parts, ext):
                    continue

                size = item.get("size", 0)
                mtime = item.get("lastModifiedDateTime", "")

                content_hash, content_bytes = self._hash_item(item["id"], size)
                if content_hash is None:
                    continue

                loc = None
                if ext in LOC_EXTENSIONS and content_bytes is not None:
                    loc = count_lines(content_bytes, ext)

                yield FileEntry(
                    path=rel_path,
                    content_hash=content_hash,
                    size=size,
                    mtime=mtime,
                    atime=mtime,  # Graph API has no atime
                    extension=ext,
                    lines_of_code=loc,
                )

            # Pagination
            url = data.get("@odata.nextLink")

    def detect_deletions(self, known_paths: set[str]) -> list[str]:
        """Return paths from known_paths that no longer exist in SharePoint."""
        current = {entry["path"] for entry in self.list_files()}
        return sorted(known_paths - current)

    def _hash_item(self, item_id: str, size: int) -> tuple[str | None, bytes | None]:
        """Download and hash a file from SharePoint."""
        try:
            resp = self._requests.get(
                f"{GRAPH_BASE}/drives/{self._drive_id}/items/{item_id}/content",
                headers=self._headers,
                stream=True,
            )
            resp.raise_for_status()

            h = hashlib.sha256()
            keep_bytes = size <= 10 * 1024 * 1024
            chunks = []

            for chunk in resp.iter_content(8192):
                h.update(chunk)
                if keep_bytes:
                    chunks.append(chunk)

            content_bytes = b"".join(chunks) if keep_bytes else None
            return h.hexdigest(), content_bytes
        except Exception:
            return None, None
