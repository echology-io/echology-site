"""Storage providers for Signal Provenance.

Abstracts filesystem access so harvest can witness files in S3, SharePoint,
Google Drive, or any mounted directory. The chain doesn't care where bytes
come from -- only that they hash consistently.

Each provider implements the same protocol: list files, read content, detect
deletions. harvest.py consumes the protocol. db.py never touches it.
"""

from __future__ import annotations

import hashlib
from typing import Iterator, Protocol, TypedDict


class FileEntry(TypedDict):
    """Normalized file metadata from any storage provider."""
    path: str           # relative path (provider-normalized, forward slashes)
    content_hash: str   # SHA-256 hex digest
    size: int           # bytes
    mtime: str          # ISO-8601 UTC
    atime: str          # ISO-8601 UTC (best effort, may equal mtime)
    extension: str      # lowercase, e.g. ".py"
    lines_of_code: int | None  # for source files, else None


class StorageProvider(Protocol):
    """Protocol for storage backends. Implement list_files and detect_deletions."""

    def list_files(self) -> Iterator[FileEntry]:
        """Yield FileEntry for every non-skipped file in the target."""
        ...

    def detect_deletions(self, known_paths: set[str]) -> list[str]:
        """Return paths from known_paths that no longer exist in storage."""
        ...


# -- Skip filters (shared across all providers) ----------------------------

SKIP_DIRS = {
    "__pycache__", ".git", ".hg", ".svn", "node_modules", ".tox", ".mypy_cache",
    ".pytest_cache", ".ruff_cache", ".venv", "venv", "env", ".eggs", "dist",
    "build", "*.egg-info", ".signal-provenance",
}

SKIP_EXTENSIONS = {
    ".pyc", ".pyo", ".so", ".dll", ".dylib", ".o", ".a", ".lib",
    ".exe", ".bin", ".class", ".jar", ".war",
    ".woff", ".woff2", ".ttf", ".eot",
    ".png", ".jpg", ".jpeg", ".gif", ".ico", ".svg", ".webp", ".bmp", ".tiff",
    ".mp3", ".mp4", ".wav", ".avi", ".mov", ".mkv", ".flac",
    ".zip", ".gz", ".bz2", ".xz", ".tar", ".7z", ".rar",
    ".db", ".sqlite", ".sqlite3",
    ".DS_Store",
}

LOC_EXTENSIONS = {
    ".py", ".js", ".ts", ".tsx", ".jsx", ".go", ".rs",
    ".java", ".sql", ".sh", ".html", ".css", ".rb", ".php",
}

ROLE_MAP = {
    ".py": "code", ".js": "code", ".ts": "code", ".tsx": "code",
    ".jsx": "code", ".go": "code", ".rs": "code", ".java": "code",
    ".c": "code", ".cpp": "code", ".h": "code", ".hpp": "code",
    ".rb": "code", ".php": "code", ".swift": "code", ".kt": "code",
    ".sh": "code", ".bash": "code", ".zsh": "code", ".fish": "code",
    ".sql": "code", ".r": "code",
    ".md": "doc", ".txt": "doc", ".rst": "doc", ".adoc": "doc",
    ".html": "template", ".css": "style",
    ".json": "config", ".yaml": "config", ".yml": "config",
    ".toml": "config", ".ini": "config", ".cfg": "config",
    ".env": "config", ".env.example": "config",
    ".gitignore": "config", ".dockerignore": "config",
    ".csv": "data", ".tsv": "data", ".xlsx": "data", ".xls": "data",
    ".pdf": "document",
}


def should_skip(rel_parts: tuple[str, ...], extension: str,
                exclude: set[str] | None = None,
                include: set[str] | None = None) -> bool:
    """Return True if this file should be excluded from harvesting.

    Built-in skip rules always apply (hidden files, SKIP_DIRS, SKIP_EXTENSIONS).
    User exclude patterns add to the skip list (match directory or file names).
    User include patterns (if set) require at least one match to pass.
    """
    # Built-in rules
    if any(p.startswith(".") and p not in (".env.example", ".github")
           for p in rel_parts):
        return True
    if any(p in SKIP_DIRS for p in rel_parts):
        return True
    if extension.lower() in SKIP_EXTENSIONS:
        return True

    # User exclude: match directory names or file name
    if exclude:
        filename = rel_parts[-1] if rel_parts else ""
        for pattern in exclude:
            pat = pattern.rstrip("/")
            # Directory name match
            if pat in rel_parts:
                return True
            # Glob-style extension match (e.g. *.log)
            if pat.startswith("*") and filename.endswith(pat[1:]):
                return True
            # Exact filename match
            if filename == pat:
                return True

    # User include: if set, file must match at least one pattern
    if include:
        filename = rel_parts[-1] if rel_parts else ""
        rel_path = "/".join(rel_parts)
        matched = False
        for pattern in include:
            pat = pattern.rstrip("/")
            if pat in rel_parts:
                matched = True
                break
            if pat.startswith("*") and filename.endswith(pat[1:]):
                matched = True
                break
            if filename == pat:
                matched = True
                break
            # Path prefix match
            if rel_path.startswith(pat):
                matched = True
                break
        if not matched:
            return True

    return False


def classify_role(rel_path: str, ext: str) -> str:
    """Determine the structural role of a file."""
    parts = rel_path.lower().split("/")
    if any(p.startswith("test") for p in parts) or "test_" in parts[-1]:
        return "test"
    if ext in ROLE_MAP:
        return ROLE_MAP[ext]
    return "other"


def sha256_bytes(data: bytes) -> str:
    """SHA-256 hex digest of raw bytes."""
    return hashlib.sha256(data).hexdigest()


def sha256_stream(chunks: Iterator[bytes]) -> str:
    """SHA-256 hex digest from an iterator of byte chunks."""
    h = hashlib.sha256()
    for chunk in chunks:
        h.update(chunk)
    return h.hexdigest()


def count_lines(content: bytes, ext: str) -> int | None:
    """Count non-blank lines for source files."""
    if ext not in LOC_EXTENSIONS:
        return None
    try:
        text = content.decode("utf-8", errors="ignore")
        return sum(1 for line in text.splitlines() if line.strip())
    except Exception:
        return None


def get_provider(target: str, exclude: list[str] | None = None,
                 include: list[str] | None = None) -> StorageProvider:
    """Resolve a storage provider from a target URI.

    Local paths, s3://, sharepoint://, gdrive:// supported.
    Cloud providers are lazy-imported to avoid requiring SDKs
    when only local filesystem is used.
    """
    if target.startswith("s3://"):
        from .s3 import S3Provider
        return S3Provider.from_uri(target)
    elif target.startswith("sharepoint://"):
        from .sharepoint import SharePointProvider
        return SharePointProvider.from_uri(target)
    elif target.startswith("gdrive://"):
        from .gdrive import GoogleDriveProvider
        return GoogleDriveProvider.from_uri(target)
    else:
        from .local import LocalProvider
        from pathlib import Path
        return LocalProvider(Path(target).expanduser().resolve(),
                             exclude=exclude, include=include)
