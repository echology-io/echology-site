"""Signal Provenance CLI -- hash-chained file provenance from the terminal.

Usage:
    signal-provenance init [path]
    signal-provenance harvest [path] [-v]
    signal-provenance verify [path]
    signal-provenance history <file> [path]
    signal-provenance snapshot <timestamp> [path]
    signal-provenance stats [path]
    signal-provenance log [path] [-n LIMIT]
"""

import argparse
import json
import sys
from pathlib import Path

from signal_provenance import __version__


def _resolve_target(path_arg: str | None) -> Path:
    """Resolve the target directory from a CLI argument or cwd."""
    if path_arg:
        return Path(path_arg).expanduser().resolve()
    return Path.cwd()


def cmd_init(args):
    """Initialize provenance tracking for a directory."""
    from signal_provenance.db import get_connection, init_db, witness

    target = _resolve_target(args.path)
    if not target.is_dir():
        print(f"Not a directory: {target}")
        sys.exit(1)

    prov_dir = target / ".signal-provenance"
    existed = prov_dir.exists()

    conn = get_connection(target)
    init_db(conn)
    conn.close()

    if existed:
        print(f"Provenance already initialized: {prov_dir}")
    else:
        witness(target, "harvest_started", "provenance.init", {
            "action": "initialized",
            "target": str(target),
        })
        print(f"Provenance initialized: {prov_dir}")
        print(f"  Database: {prov_dir / 'provenance.db'}")
        print(f"  Ledger:   {prov_dir / 'ledger.db'}")
        print(f"\nRun 'signal-provenance harvest' to start witnessing.")


def cmd_harvest(args):
    """Harvest filesystem metadata and record provenance."""
    from signal_provenance.db import get_connection, init_db
    from signal_provenance.harvest import harvest

    target = _resolve_target(args.path)
    if not target.is_dir():
        print(f"Not a directory: {target}")
        sys.exit(1)

    prov_dir = target / ".signal-provenance"
    if not prov_dir.exists():
        print(f"Not initialized. Run: signal-provenance init {target}")
        sys.exit(1)

    print(f"Harvesting: {target}")
    conn = get_connection(target)
    init_db(conn)
    summary = harvest(conn, target, verbose=args.verbose)
    conn.close()

    print(f"\n  {summary['files_total']} files "
          f"({summary['files_new']} new, "
          f"{summary['files_updated']} updated, "
          f"{summary['files_skipped']} unchanged, "
          f"{summary['files_deleted']} deleted) "
          f"in {summary['duration_ms']}ms")


def cmd_verify(args):
    """Verify the Aletheia ledger chain integrity."""
    from signal_provenance.db import verify_chain

    target = _resolve_target(args.path)
    result = verify_chain(target)

    if result.get("error"):
        print(f"Verify: {result['error']}")
        sys.exit(1)

    print(f"Ledger: {target}")
    print(f"  Entries: {result['entries']}")
    print(f"  First:   seq={result['first']['seq']} "
          f"{result['first']['timestamp']}")
    print(f"  Last:    seq={result['last']['seq']} "
          f"{result['last']['timestamp']}")
    if result["valid"]:
        print(f"  Chain:   VALID (all {result['entries']} entries linked)")
    else:
        print(f"  CHAIN BREAKS: {len(result['breaks'])} "
              f"at seq {result['breaks'][:10]}")
        sys.exit(1)


def cmd_history(args):
    """Show change history for a specific file."""
    from signal_provenance.db import get_connection, get_file_history

    target = _resolve_target(args.path)
    conn = get_connection(target)
    history = get_file_history(conn, args.file)
    conn.close()

    if not history:
        print(f"No history for: {args.file}")
        sys.exit(1)

    print(f"History for {args.file} ({len(history)} snapshots):\n")
    for h in history:
        actor = f"  by {h['change_actor']}" if h.get("change_actor") else ""
        reason = f"  ({h['change_reason']})" if h.get("change_reason") else ""
        print(f"  {h['perceived_at']}  {h['change_type']:<10s}  "
              f"hash={h['content_hash'][:16]}  "
              f"{h.get('size_bytes', '?')}B{actor}{reason}")


def cmd_snapshot(args):
    """Reconstruct the file environment at a point in time."""
    from signal_provenance.db import get_connection, get_environment_at_time

    target = _resolve_target(args.path)
    conn = get_connection(target)
    files = get_environment_at_time(conn, args.timestamp)
    conn.close()

    if not files:
        print(f"No files at {args.timestamp}")
        sys.exit(1)

    print(f"Environment at {args.timestamp}: {len(files)} files\n")
    for f in files:
        marker = {
            "created": "+", "modified": "~",
            "unchanged": " ", "deleted": "-",
        }.get(f["change_type"], "?")
        print(f"  {marker} {f['file_path']:<60s} "
              f"{f.get('content_hash', '')[:16]}")


def cmd_stats(args):
    """Show ledger and provenance statistics."""
    from signal_provenance.db import get_connection, get_ledger_stats

    target = _resolve_target(args.path)

    # Database stats
    conn = get_connection(target)
    files = conn.execute("SELECT count(*) FROM file_metadata").fetchone()[0]
    snapshots = conn.execute(
        "SELECT count(*) FROM artifact_snapshots"
    ).fetchone()[0]
    created = conn.execute(
        "SELECT count(*) FROM artifact_snapshots "
        "WHERE change_type = 'created'"
    ).fetchone()[0]
    modified = conn.execute(
        "SELECT count(*) FROM artifact_snapshots "
        "WHERE change_type = 'modified'"
    ).fetchone()[0]
    deleted = conn.execute(
        "SELECT count(*) FROM artifact_snapshots "
        "WHERE change_type = 'deleted'"
    ).fetchone()[0]
    harvests = conn.execute(
        "SELECT count(*) FROM metadata_harvests"
    ).fetchone()[0]
    conn.close()

    print(f"Provenance: {target}\n")
    print(f"  Files tracked:    {files}")
    print(f"  Total snapshots:  {snapshots}")
    print(f"    created:        {created}")
    print(f"    modified:       {modified}")
    print(f"    deleted:        {deleted}")
    print(f"  Harvests:         {harvests}")

    # Ledger stats
    lstats = get_ledger_stats(target)
    if lstats:
        print(f"\n  Ledger entries:   {lstats['total']}")
        if lstats["first"]:
            print(f"  First entry:      {lstats['first']}")
        if lstats["last"]:
            print(f"  Last entry:       {lstats['last']}")
        if lstats["events"]:
            print(f"\n  By event type:")
            for etype, count in lstats["events"].items():
                print(f"    {etype:<30s} {count:>5d}")


def cmd_log(args):
    """Show recent ledger entries."""
    from signal_provenance.db import get_ledger_history

    target = _resolve_target(args.path)
    entries = get_ledger_history(target, limit=args.limit)

    if not entries:
        print("No ledger entries.")
        sys.exit(1)

    print(f"Ledger (last {len(entries)} entries):\n")
    for e in entries:
        action = e["summary"].get("action", e["event_type"])
        fp = e["summary"].get("file_path", "")
        detail = f"  {fp}" if fp else ""
        print(f"  [{e['seq']:>4d}] {e['timestamp'][:19]} "
              f"{e['event_type']:<20s}{detail}")


def cmd_export(args):
    """Export compliance report (JSON or PDF)."""
    from signal_provenance.license import require_license
    from signal_provenance.db import get_connection

    require_license()

    target = _resolve_target(args.path)
    prov_dir = target / ".signal-provenance"
    if not prov_dir.exists():
        print(f"Not initialized. Run: signal-provenance init {target}")
        sys.exit(1)

    conn = get_connection(target)

    fmt = args.format
    if args.output:
        output = Path(args.output)
    else:
        suffix = ".json" if fmt == "json" else ".pdf"
        output = Path(f"provenance-report{suffix}")

    if fmt == "json":
        from signal_provenance.export import export_json
        export_json(conn, target, output, start=args.start, end=args.end)
    else:
        from signal_provenance.export import export_pdf
        export_pdf(conn, target, output, start=args.start, end=args.end)

    conn.close()
    print(f"Report exported: {output}")


def cmd_activate(args):
    """Activate a license file."""
    from signal_provenance.license import activate, LicenseError

    try:
        lic = activate(args.license_file)
        print(f"License activated.")
        print(f"  Customer: {lic.cid} ({lic.email})")
        print(f"  Tier:     {lic.tier}")
        print(f"  Expires:  {lic.expires}")
    except LicenseError as e:
        print(f"Activation failed: {e}")
        sys.exit(1)


def cmd_license_status(args):
    """Show current license status."""
    from signal_provenance.license import check_license, LICENSE_FILE

    lic = check_license()
    if lic is None:
        print("No valid license found.")
        print(f"  Expected: {LICENSE_FILE}")
        print("\nFree tier: init, harvest, verify, history, stats, log")
        print("Pro tier:  + export, snapshot, continuous monitoring")
        print("\nPurchase: https://echology.io/provenance")
    else:
        print(f"License: VALID")
        print(f"  Customer: {lic.cid} ({lic.email})")
        print(f"  Tier:     {lic.tier}")
        print(f"  Issued:   {lic.issued}")
        print(f"  Expires:  {lic.expires}")


def main():
    parser = argparse.ArgumentParser(
        prog="signal-provenance",
        description="Hash-chained file provenance. Prove what happened.",
    )
    parser.add_argument(
        "--version", action="version",
        version=f"signal-provenance {__version__}",
    )
    sub = parser.add_subparsers(dest="command")

    # init
    p = sub.add_parser("init", help="Initialize provenance tracking")
    p.add_argument("path", nargs="?", help="Directory to track (default: cwd)")

    # harvest
    p = sub.add_parser("harvest", help="Harvest filesystem state")
    p.add_argument("path", nargs="?", help="Directory to harvest (default: cwd)")
    p.add_argument("-v", "--verbose", action="store_true")

    # verify
    p = sub.add_parser("verify", help="Verify ledger chain integrity")
    p.add_argument("path", nargs="?", help="Directory (default: cwd)")

    # history
    p = sub.add_parser("history", help="File change history")
    p.add_argument("file", help="Relative file path")
    p.add_argument("path", nargs="?", help="Directory (default: cwd)")

    # snapshot
    p = sub.add_parser("snapshot", help="Reconstruct environment at time")
    p.add_argument("timestamp", help="ISO-8601 timestamp")
    p.add_argument("path", nargs="?", help="Directory (default: cwd)")

    # stats
    p = sub.add_parser("stats", help="Show provenance statistics")
    p.add_argument("path", nargs="?", help="Directory (default: cwd)")

    # log
    p = sub.add_parser("log", help="Show recent ledger entries")
    p.add_argument("path", nargs="?", help="Directory (default: cwd)")
    p.add_argument("-n", "--limit", type=int, default=20,
                   help="Number of entries (default: 20)")

    # export (pro)
    p = sub.add_parser("export", help="Export compliance report (pro)")
    p.add_argument("--format", "-f", choices=["json", "pdf"], default="json",
                   help="Output format (default: json)")
    p.add_argument("--output", "-o", help="Output file path")
    p.add_argument("--start", help="Period start (ISO-8601)")
    p.add_argument("--end", help="Period end (ISO-8601)")
    p.add_argument("path", nargs="?", help="Directory (default: cwd)")

    # activate
    p = sub.add_parser("activate", help="Activate a license file")
    p.add_argument("license_file", help="Path to .lic file")

    # license
    sub.add_parser("license", help="Show license status")

    args = parser.parse_args()
    if not args.command:
        parser.print_help()
        sys.exit(1)

    commands = {
        "init": cmd_init,
        "harvest": cmd_harvest,
        "verify": cmd_verify,
        "history": cmd_history,
        "snapshot": cmd_snapshot,
        "stats": cmd_stats,
        "log": cmd_log,
        "export": cmd_export,
        "activate": cmd_activate,
        "license": cmd_license_status,
    }
    commands[args.command](args)


if __name__ == "__main__":
    main()
