"""Signal Provenance -- hash-chained file provenance for any directory."""

__version__ = "0.1.0"
