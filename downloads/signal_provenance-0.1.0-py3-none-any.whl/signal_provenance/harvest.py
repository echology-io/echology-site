"""Filesystem perception -- harvest file metadata from a directory.

Deterministic, filesystem-first. No git required. No external dependencies.
"""

import hashlib
import json
import sqlite3
import time
import platform
from datetime import datetime, timezone
from pathlib import Path

from signal_provenance.db import (
    get_all_file_ids,
    get_latest_snapshot_hashes,
    log_metadata_harvest,
    record_artifact_deletion,
    record_artifact_snapshot,
    upsert_file_metadata,
    witness,
)


# -- Skip lists ------------------------------------------------------------

SKIP_DIRS = {
    "__pycache__", ".git", ".hg", ".svn", "node_modules", ".tox", ".mypy_cache",
    ".pytest_cache", ".ruff_cache", ".venv", "venv", "env", ".eggs", "dist",
    "build", "*.egg-info", ".signal-provenance",
}

SKIP_EXTENSIONS = {
    ".pyc", ".pyo", ".so", ".dll", ".dylib", ".o", ".a", ".lib",
    ".exe", ".bin", ".class", ".jar", ".war",
    ".woff", ".woff2", ".ttf", ".eot",
    ".png", ".jpg", ".jpeg", ".gif", ".ico", ".svg", ".webp", ".bmp", ".tiff",
    ".mp3", ".mp4", ".wav", ".avi", ".mov", ".mkv", ".flac",
    ".zip", ".gz", ".bz2", ".xz", ".tar", ".7z", ".rar",
    ".db", ".sqlite", ".sqlite3",
    ".DS_Store",
}

ROLE_MAP = {
    ".py": "code", ".js": "code", ".ts": "code", ".tsx": "code",
    ".jsx": "code", ".go": "code", ".rs": "code", ".java": "code",
    ".c": "code", ".cpp": "code", ".h": "code", ".hpp": "code",
    ".rb": "code", ".php": "code", ".swift": "code", ".kt": "code",
    ".sh": "code", ".bash": "code", ".zsh": "code", ".fish": "code",
    ".sql": "code", ".r": "code",
    ".md": "doc", ".txt": "doc", ".rst": "doc", ".adoc": "doc",
    ".html": "template", ".css": "style",
    ".json": "config", ".yaml": "config", ".yml": "config",
    ".toml": "config", ".ini": "config", ".cfg": "config",
    ".env": "config", ".env.example": "config",
    ".gitignore": "config", ".dockerignore": "config",
    ".csv": "data", ".tsv": "data", ".xlsx": "data", ".xls": "data",
    ".pdf": "document",
}


# -- Helpers ---------------------------------------------------------------

def _sha256(file_path: Path) -> str | None:
    """Compute SHA-256 hash of file contents. Full hash (not truncated)."""
    try:
        h = hashlib.sha256()
        with open(file_path, "rb") as f:
            for chunk in iter(lambda: f.read(8192), b""):
                h.update(chunk)
        return h.hexdigest()
    except (OSError, PermissionError):
        return None


def _count_lines(file_path: Path, ext: str) -> int | None:
    """Count non-blank lines for source files."""
    if ext not in {".py", ".js", ".ts", ".tsx", ".jsx", ".go", ".rs",
                   ".java", ".sql", ".sh", ".html", ".css", ".rb", ".php"}:
        return None
    try:
        with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
            return sum(1 for line in f if line.strip())
    except (OSError, PermissionError):
        return None


def _classify_role(rel_path: str, ext: str) -> str:
    """Determine the structural role of a file."""
    parts = rel_path.lower().split("/")
    if any(p.startswith("test") for p in parts) or "test_" in parts[-1]:
        return "test"
    if ext in ROLE_MAP:
        return ROLE_MAP[ext]
    return "other"


def _collect_files(root: Path) -> list[Path]:
    """Walk the directory and collect all non-skipped files."""
    files = []
    for item in root.rglob("*"):
        if not item.is_file():
            continue
        rel_parts = item.relative_to(root).parts
        # Skip hidden files (except .env.example, .github)
        if any(
            p.startswith(".") and p not in (".env.example", ".github")
            for p in rel_parts
        ):
            continue
        # Skip directories
        if any(p in SKIP_DIRS for p in rel_parts):
            continue
        # Skip binary extensions
        if item.suffix.lower() in SKIP_EXTENSIONS:
            continue
        files.append(item)
    return sorted(files)


# -- Main harvest ----------------------------------------------------------

def harvest(conn: sqlite3.Connection, target_dir: Path,
            verbose: bool = False) -> dict:
    """Harvest metadata from a directory into the provenance database.

    Perception is filesystem-first: content hashes, timestamps, structure.
    All deterministic. No git required.

    Returns summary dict with counts and timing.
    """
    start = time.monotonic()
    target_dir = target_dir.expanduser().resolve()
    host = platform.node()

    files = _collect_files(target_dir)

    # Bulk pre-loads
    existing_ids = get_all_file_ids(conn)
    prior_hashes = get_latest_snapshot_hashes(conn)

    # Edit frequencies -- 6 windows form the velocity vector per file
    _freq_windows = [
        ("1d", "-1 days"), ("7d", "-7 days"), ("14d", "-14 days"),
        ("21d", "-21 days"), ("30d", "-30 days"), ("90d", "-90 days"),
    ]
    edit_freqs: dict[str, dict[str, int]] = {}
    for label, offset in _freq_windows:
        for row in conn.execute(
            "SELECT f.file_path, count(*) as cnt FROM artifact_snapshots a "
            "JOIN file_metadata f ON a.file_id = f.id "
            "WHERE a.change_type IN ('created', 'modified') "
            "AND a.perceived_at >= datetime('now', ?) "
            "GROUP BY f.file_path", (offset,)
        ).fetchall():
            edit_freqs.setdefault(row[0], {})[label] = row[1]

    # Pre-load existing state for mtime-based skip
    existing_state: dict[str, tuple] = {}
    for row in conn.execute(
        "SELECT file_path, first_seen, last_modified, content_hash, "
        "lines_of_code FROM file_metadata"
    ).fetchall():
        existing_state[row[0]] = (row[1], row[2], row[3], row[4])

    # Create harvest record
    harvest_id = log_metadata_harvest(
        conn,
        repo_root=str(target_dir),
        files_total=len(files),
        files_new=0, files_updated=0, files_deleted=0, duration_ms=0,
    )

    new_count = 0
    updated_count = 0
    skipped_count = 0

    for file_path in files:
        rel_path = str(file_path.relative_to(target_dir))
        ext = file_path.suffix.lower()
        stat = file_path.stat()
        size = stat.st_size

        last_modified = datetime.fromtimestamp(
            stat.st_mtime, tz=timezone.utc
        ).isoformat()
        last_accessed = datetime.fromtimestamp(
            stat.st_atime, tz=timezone.utc
        ).isoformat()

        known_id = existing_ids.get(rel_path)
        prior = existing_state.get(rel_path)

        # mtime-based skip: if mtime unchanged, content is identical (OS guarantee)
        if prior and prior[1] == last_modified:
            skipped_count += 1
            first_seen = prior[0]
            content_hash = prior[2]
            loc = prior[3]
            if verbose:
                print(f"  [skip] {rel_path}")
        else:
            # File is new or modified -- read content
            content_hash = _sha256(file_path)
            loc = _count_lines(file_path, ext)
            first_seen = datetime.fromtimestamp(
                stat.st_ctime, tz=timezone.utc
            ).isoformat()
            if prior:
                first_seen = prior[0]  # preserve original observation
            if verbose:
                status = "new" if known_id is None else "mod"
                print(f"  [{status}] {rel_path}")

        role = _classify_role(rel_path, ext)
        fv = edit_freqs.get(rel_path, {})

        if known_id is not None:
            updated_count += 1
        else:
            new_count += 1

        file_id = upsert_file_metadata(
            conn,
            commit=False,
            _existing_id=known_id,
            file_path=rel_path,
            content_hash=content_hash,
            size_bytes=size,
            extension=ext,
            role=role,
            first_seen=first_seen,
            last_modified=last_modified,
            last_accessed=last_accessed,
            edit_frequency_1d=fv.get("1d", 0),
            edit_frequency_7d=fv.get("7d", 0),
            edit_frequency_14d=fv.get("14d", 0),
            edit_frequency_21d=fv.get("21d", 0),
            edit_frequency_30d=fv.get("30d", 0),
            edit_frequency_90d=fv.get("90d", 0),
            lines_of_code=loc,
        )

        if known_id is None:
            existing_ids[rel_path] = file_id

        # Record artifact snapshot
        if content_hash:
            prior_hash = prior_hashes.get(file_id)
            record_artifact_snapshot(
                conn, target_dir, rel_path, content_hash,
                size_bytes=size, lines_of_code=loc,
                last_accessed=last_accessed,
                harvest_id=harvest_id,
                change_actor="harvest",
                commit=False,
                _file_id=file_id,
                _prior_hash=prior_hash,
            )

    conn.commit()

    # Perceive deleted files
    current_paths = {str(f.relative_to(target_dir)) for f in files}
    deleted = set(existing_ids.keys()) - current_paths
    deleted_count = len(deleted)
    if deleted:
        for dp in deleted:
            record_artifact_deletion(conn, target_dir, dp,
                                     harvest_id=harvest_id)
        conn.commit()

    duration_ms = int((time.monotonic() - start) * 1000)

    conn.execute(
        "UPDATE metadata_harvests SET files_new = ?, files_updated = ?, "
        "files_deleted = ?, files_skipped = ?, duration_ms = ? WHERE id = ?",
        (new_count, updated_count, deleted_count, skipped_count,
         duration_ms, harvest_id),
    )
    conn.commit()

    # Witness harvest completion
    witness(target_dir, "harvest_completed", "provenance.harvest", {
        "harvest_id": harvest_id,
        "files_total": len(files),
        "files_new": new_count,
        "files_updated": updated_count,
        "files_deleted": deleted_count,
        "files_skipped": skipped_count,
        "duration_ms": duration_ms,
        "host": host,
    })

    return {
        "harvest_id": harvest_id,
        "files_total": len(files),
        "files_new": new_count,
        "files_updated": updated_count,
        "files_deleted": deleted_count,
        "files_skipped": skipped_count,
        "duration_ms": duration_ms,
    }
